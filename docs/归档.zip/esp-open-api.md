# 8BitGo 开放平台 · 嵌入式（ESP）接入速查

> 面向**设备端**（ESP32 / ESP8266 之类）的接口速查。
> 协议设计与取舍见 `docs/open-platform.md`；这一份只回答一件事：
> **固件里要发什么请求、会收到什么、出错了怎么认。**
>
> 每条数字和字段都标了源码出处。和设计稿冲突的地方**以源码为准**，
> 并在正文里显式标出来（见 §7 的限流一节）。
>
> 核对基线：`server/src/routes/open.js` + `server/src/open/*`，2026-09-16。

---

## 0. 先说清楚：哪些今天能用

| 你要做的 | 状态 | 说明 |
|---|---|---|
| 拉游戏列表 / 详情 | ✅ **可用，且不需要 AppID** | 2026-09-13 起整个目录公开匿名可读，连令牌都不用取。固件里可以直接 GET |
| 下载 ROM 到设备 | ✅ **可用** | 未审核应用申请 `games.rom` 后，每个已配置机型可下载一款站长选定的测试游戏；完整游戏库需审核。另见下面的 ⚠️ |
| 云存档**读取** | ✅ **可用**（2026-09-12 加的） | `saves.read`，用户级 scope。要先走**设备码流程**拿一枚用户级令牌，见 §6.5 |
| 收藏 / 最近在玩 | ✅ **可用**（2026-09-12 加的） | `library.read`，同上 |
| 云存档**写入** | ❌ 还没有 | `saves.write` 在 `scopes.js` 里标着 sensitive，这一轮只做了只读。写入要连着配额、覆盖保护、删除审计一起想清楚 |
| 上报真实开玩 | ✅ **可用** | `POST /v1/games/:slug/play`，要用户级 `library.write`；跨设备按账号去重，并同步最近在玩 |
| 直播 / P2P 联机房间发现 | ✅ **可用** | 两套公开列表与详情接口；直播条目带观看地址，按游戏查联机房时带加入地址 |
| Linux / 外部客户端开播 | ✅ **可用** | 用户级 `live.write` 换专用发布凭证，再连 Socket.IO `/live` 用 WebRTC 推流；完整协议见 `docs/live-publisher-api.md` |

云存档写入为什么暂未开放，见 §10；游玩上报见 §7。

> 📌 **2026-09-12 之前，云存档那两行是 ❌。** 当时的状况是：`scopes.js` 里声明了
> `library.read` / `saves.read`，而 `routes/open.js` 里**连路由都没有**；
> 更要命的是就算有也没人调得到 —— 用户级令牌的签发函数 `issueUserToken`
> 当时**一个调用方都没有**。现在两边都补上了：路由在 §7，取令牌的路在 §6.5。

⚠️ ROM 那条还有一个必须知道的前提：`assets.8bitgo.com` 目前是**公开可读**的。
签名凭据这一层现在只是「我们不主动给地址」，**不是访问控制** ——
任何人打开一次游戏、从浏览器网络面板抄走 ROM 地址就能无限下载。
源码里对此有明确注释（`server/src/open/sign.js` 文件头、`open.js` 的 `/v1/games/:slug/rom`）。
这不影响你的固件怎么写，但影响你怎么对外描述这个功能。

---

## 0.5 端点清单（全量速查）

所有路由都挂在 Base URL `https://8bitgo.com/api/open/v1` 下。「需要 scope」一栏为「无 / —」表示只要令牌有效即可（不卡具体 scope）。

「鉴权」一栏三种取值：

- **公开** —— 不带 `Authorization` 头就能调。**带了就必须是有效的**，见下面那条 ⚠️。
- **要令牌** —— 任何有效的开放平台令牌都行，不卡具体 scope。
- **`<scope>`** —— 要一枚带这个 scope 的令牌。

| 方法 | 路径 | 鉴权 | 用途 |
|---|---|---|---|
| `POST` | `/v1/token` | — | 换应用级 / 用户级令牌（`client_credentials` 或 `device_code`） |
| `POST` | `/v1/device/code` | — | 设备码流程：拿 `user_code` / `device_code` |
| `GET` | `/v1/health` | **公开** | 健康检查：服务存活 + 数据库连通（规格见 `/.well-known/openapi.json`） |

另外两条**不在** `/v1` 下（它们按惯例挂在站点根）：

| 方法 | 路径 | 鉴权 | 用途 |
|---|---|---|---|
| `GET` | `/.well-known/oauth-authorization-server` | **公开** | RFC 8414 元数据：端点地址、支持的 grant type 和 scope。现成的 OAuth 库会自己读 |
| `GET` | `/.well-known/jwks.json` | **公开** | access token 的验签公钥。设备端**用不上**（你不需要验我们签的令牌，直接带上就行）；这是给要自己验签的服务端接入方的 |

> ⚠️ **没有 `/.well-known/openid-configuration`，这是故意的。** 这套是 OAuth 2.0 不是 OIDC：
> 只签 `access_token`，没有 `id_token` / `userinfo` / `refresh_token` / revoke。
> 给出一份 OIDC 发现文档会让你的库去要那些不存在的东西，然后在一个和真正原因无关的地方失败。
> RFC 8414 那份里有 `x-not-supported` 明说缺哪四样。
| `GET` | `/v1/games` | **公开** | 游戏列表（分页 / 筛选） |
| `GET` | `/v1/games/:slug` | **公开** | 游戏详情 |
| `GET` | `/v1/platforms` | **公开** | 平台目录：`runtime` / `core` / `romExtensions` / `native` 建议 / `enabled`，本地客户端挑模拟器用（见 §12） |
| `GET` | `/v1/genres` | **公开** | 游戏类型枚举（客户端画筛选器用） |
| `GET` | `/v1/languages` | **公开** | 游戏语言枚举（客户端画筛选器用） |
| `GET` | `/v1/live/capacity` | **公开** | 开播前查看全站直播房间是否还有空位；不预留席位 |
| `GET` | `/v1/live/rooms` | **公开** | 在播直播房间列表（`?game=<slug>` 可筛某一款） |
| `GET` | `/v1/live/rooms/:roomId` | **公开** | 单个直播房间快照（已脱敏，无 IP / token） |
| `POST` | `/v1/live/publish-token` | `live.write` | 给 Linux、掌机等外部设备签发用途单一的开播凭证 |
| `GET` | `/v1/netplay/rooms` | **公开** | P2P 联机房间列表；`?game=<slug>` 可筛选并取得 `joinUrl` |
| `GET` | `/v1/netplay/rooms/:roomId` | **公开** | 单个 P2P 房间快照；房主迁移后旧 roomId 仍可查 |
| `GET` | `/v1/collections` | **公开** | 公开合集列表（分页） |
| `GET` | `/v1/collections/:id` | **公开** | 单个合集 + 里面的游戏（游戏走白名单映射） |
| `GET` | `/v1/games/:slug/rom` | `games.rom` | 换 ROM 短期下载凭据（两步式第一步） |
| `GET` | `/v1/rom/:grant` | — | 兑现 ROM 凭据（两步式第二步，302 不带 `Authorization`） |
| `GET` | `/v1/rom-plain/:grant` | — | 服务端转码后的**明文** ROM（中间件：服务端自己解密 + 解压再发给设备，给没自解码能力的低端设备） |
| `GET` | `/v1/rom-samples` | 公开 | 查看沙箱允许下载的逐机型测试游戏 |
| `GET` | `/v1/games/:slug/embed` | `games.read` | 换带签名、会过期的嵌入播放器地址 |
| `GET` | `/v1/me` | 要令牌 | 自查令牌的 `client_id` / `scope` / `expires_at` |
| `GET` | `/v1/library` | `library.read` | 用户收藏 / 最近在玩（用户级令牌） |
| `POST` | `/v1/games/:slug/play` | `library.write` | 游戏真正可玩后上报；跨设备按账号去重，同时刷新最近在玩 |
| `GET` | `/v1/saves` | `saves.read` | 用户存档清单（用户级令牌） |
| `GET` | `/v1/saves/:runtime/:slug` | `saves.read` | 取一份存档（用户级令牌） |

> ### ⚠️ 「公开」的准确含义：可以不带令牌，但不能带错的
>
> **不带 `Authorization` 头 = 匿名，正常返回。
> 带了这个头但令牌无效 / 已过期 = `401 invalid_token`，不会降级成匿名。**
>
> 这一条是专门写给固件作者的，因为反过来的设计会坑死人：坏令牌要是被当成匿名放行，
> 你的设备在令牌过期之后**列表照常刷新**，一切看起来正常，直到某天用户点下载 ——
> 那时报的错指向 ROM 权限，而真正的原因是两小时前令牌就过期了。
>
> 所以固件里的写法是：**要么完全不带这个头，要么保证带的是新鲜的令牌。**
> 别在取令牌失败的时候把旧的那枚接着用。
>
> 另外，`games.read` 这个 scope 现在只剩 `/v1/games/:slug/embed` 在用。
> 光要拉列表的应用**不需要申请任何 scope，也不需要创建应用**。

> 全部路由的响应错误体一致（见 §8）；`/v1/rom/:grant` 和上面标「公开」的那些
> 都可以不带 `Authorization` 调。
>
> 🤖 **机器可读规格**：完整的 OpenAPI 3.1 挂在 `/.well-known/openapi.json`（公开、匿名、CORS 放开），agents / 代码生成器可直接消费，对应源文件 `server/openapi.json`。

## 1. 前提与环境

| 项 | 值 |
|---|---|
| Base URL | `https://8bitgo.com/api/open/v1` |
| 拿 AppID / key | 站点页脚 → **`/open`** 开发者控制台（⚠️ 不是 `/developers`，那是站内的「开发商」浏览页） |
| 客户端类型 | 必须选 **`confidential`**（有 key）。`public` 客户端**不能**用 `client_credentials`，会被 400 `unauthorized_client` 挡掉 |
| AppID 形状 | `app_` + 24 位十六进制 |
| key | 32 字节随机、Base64URL，**只在创建/轮换时显示一次** |
| CORS | `/api/open/*` 放开到任意 Origin，且**不带 cookie**。设备端用不上，但说明这套接口不依赖任何浏览器状态 |

**服务端没配密钥的话会怎样**（2026-09-13 起分成两半）：

| | 没配 `OPEN_JWT_PRIVATE_KEY` 时 |
|---|---|
| 公开目录（`/v1/games*` 的 GET、`/v1/platforms`、`/v1/genres`、`/v1/languages`、`/v1/live/rooms*`、`/v1/netplay/rooms*`、`/v1/collections*`、`/v1/health`） | **照常可用**。它们只读公开数据，一把密钥都用不上 |
| `/v1/token`、`/v1/device/code`、`/v1/me`、`/v1/library`、`/v1/saves*` | `501 temporarily_unavailable` |
| `/v1/games/:slug/rom`、`/v1/rom/:grant`、`/v1/rom-plain/:grant` | `501`（另外没配 `OPEN_ROM_SECRET` 时也单独 501） |
| `/v1/games/:slug/embed` | `501`（另外要 `OPEN_EMBED_SECRET`） |

> 📌 **以前是「没配密钥就整套 501」。** 那会让「游戏列表公开」依赖一个和它完全无关的
> 环境变量 —— 目录根本不签也不验任何东西。2026-09-13 拆开了。

接线之前先各探一条：

```bash
# 公开目录：不带任何令牌，应该直接回 200 + 一页游戏
curl -i 'https://8bitgo.com/api/open/v1/games?page_size=1'

# 要令牌的那半：501 就是部署上还没配密钥，不是你的请求写错了
curl -i -X POST https://8bitgo.com/api/open/v1/token \
  -H 'Content-Type: application/json' \
  -d '{"grant_type":"client_credentials","client_id":"app_...","client_secret":"..."}'
```

### ⚠️ 把 client_secret 烧进固件这件事

`client_credentials` 的整个安全模型建立在「secret 只在服务端」上。
烧进 ESP 之后，**拿到一块板子 = 拿到你的 key**（Flash 可以直接 dump，
除非开了 Flash 加密 + Secure Boot，而那会改变你的量产流程）。

现实一点的三条路，按代价排：

1. **自己架一层中转**：ESP 只认自己的服务端，secret 留在服务端。
   多一跳，但也顺带解决了限流、ROM 缓存、和「换 key 不用重刷固件」。
2. **一台设备一把 key**：一把泄露只废一把。但开放平台**每个账号最多 10 个应用**，
   量产这条走不通。
3. **接受风险 + 可吊销**：key 烧进去，出事了在 `/open` 控制台撤销那把密钥。
   支持同时有两把有效密钥（轮换期），所以换 key 不会让所有设备同时挂 ——
   但仍然要能给设备推新 key，否则撤销就等于砖化。

自用几台，第 3 条够了；要卖出去，走第 1 条。

---

## 2. 取令牌 `POST /v1/token`

### 两种写法都收

| Content-Type | 说明 |
|---|---|
| `application/x-www-form-urlencoded` | **RFC 6749 §4.1.3 规定的那种**。现成的 OAuth 客户端库默认发这个 |
| `application/json` | 非标准的扩展写法，设备端手写 HTTP 时更省事 |

两种取到的东西完全一样（scope、`expires_in` 都一致，有测试钉住）。
请求体上限 **16 KB**，超了回 `413 invalid_request`。

> 📌 **2026-09-11 之前这里是坏的**：服务端全局只挂了 `express.json`，
> form-encoded 发过去 `req.body` 是空的 → `grant_type` 读不到 →
> 回一句 `400 unsupported_grant_type`，而那句话完全看不出真正的原因
> （它说「不支持这个 grant_type」，可你明明传了 `client_credentials`）。
> 现成的 OAuth 库一律接不上。已在 `routes/open.js` 的 token 路由上单独补了解析器。
> 如果你对着的是旧版本服务端，**发 JSON**。

### 请求（JSON 写法）

```http
POST /api/open/v1/token HTTP/1.1
Host: 8bitgo.com
Content-Type: application/json

{"grant_type":"client_credentials","client_id":"app_xxxx","client_secret":"yyyy"}
```

### 请求（form 写法）

```http
POST /api/open/v1/token HTTP/1.1
Host: 8bitgo.com
Content-Type: application/x-www-form-urlencoded

grant_type=client_credentials&client_id=app_xxxx&client_secret=yyyy
```

带凭据有两种写法，二选一：

| 写法 | 怎么发 |
|---|---|
| **放 body**（推荐，ESP 上最省事） | `client_id` / `client_secret` 两个字段写在 JSON 里 |
| **HTTP Basic** | `Authorization: Basic base64(client_id + ":" + client_secret)`，body 里只留 `grant_type`。⚠️ 两段按 RFC 6749 §2.3.1 要先做 URL 编码 |

`scope` 字段**可以不传**：不传就给当前可用的应用级权限。
未审核应用若在申请里选择了 `games.rom`，也能取到这个 scope，但只能下载
`GET /v1/rom-samples` 列出的游戏。传入的 scope 必须是当前可用权限的子集 —— **不会静默降级**，少一个就整个请求 400，
错误信息里会写明差哪个。

### 响应 `200`

```json
{
  "access_token": "eyJ...",
  "token_type": "Bearer",
  "expires_in": 900,
  "scope": "games.read games.rom",
  "rom_access": "samples"
}
```

`expires_in` = **900 秒**（`open/tokens.js` 的 `OPEN_ACCESS_TTL_SEC`）。
`rom_access` 对应用级令牌是 `none`、`samples` 或 `full`；审核通过并获批 `games.rom` 后为 `full`。

### 设备端缓存策略

令牌只有 15 分钟，但**取令牌本身是有限流的**（见 §7），所以不能每次请求都去换一次。

```
if (now - tokenIssuedAt > (expires_in - 60) * 1000) refreshToken();
```

- 提前 60 秒续期，别卡着过期边界。
- ⚠️ **不需要 NTP 对时**：`expires_in` 是相对秒数，用 `millis()` 算就够了。
  设备没有 RTC、开机时钟从 0 开始，照样能正确判断过期。
  （只有校验 JWT 里的 `exp` 才需要真实时间，而设备端**不需要**自己校验令牌 ——
  那是服务端的事。）
- 收到 `401 invalid_token` 就立刻续一次再重试一遍，**只重试一次**。

---

## 3. 用令牌 + 自检 `GET /v1/me`

之后所有请求都带：

```http
Authorization: Bearer eyJ...
```

排错第一站，接线时先打这一条：

```json
{
  "client_id": "app_xxxx",
  "kind": "app",
  "scope": "games.read",
  "expires_at": "2026-09-11T12:34:56.000Z"
}
```

`GET /v1/me` **不要求任何 scope**，只要令牌有效就回。
「为什么我调那个接口 403」——先看这里的 `scope` 里有没有那一个。

---

## 4. 游戏列表 `GET /v1/games`

公开可读，不需要令牌。带令牌时仍会校验；无效令牌返回 401。

### 查询参数

| 参数 | 说明 |
|---|---|
| `page` | 从 1 开始，默认 1 |
| `page_size` | 默认 24，**上限 50**（超了按 50 截断，不报错） |
| `platform` | 机型 id，如 `nes` / `gba`；可选值见 `GET /v1/platforms` |
| `requires_windows` | `false` 排除需要 Windows 3.x / 95 / 98 客体的 DOS 游戏；`true` 只看这类游戏。不传则都包含 |
| `genre` | 类型 id，如 `action` / `rpg`；可选值见 `GET /v1/genres` |
| `q` | 关键词。传了 `q` 且没显式指定 `sort` 时按相关度排 |
| `sort` | `popular`（默认）/ `newest` / `name` / `rating` / `home` |
| `lang` | 见 §8。不传默认 **`en`** ⚠️ |

⚠️ `lang` 默认是 `en` 而不是 `zh-Hans`，这是**刻意**的（`open/i18n.js` 的
`OPEN_DEFAULT_LANG`）：开放接口的调用方是第三方，默认给中文会让人以为整库都是中文。
要中文界面就**每次都显式传 `lang=zh-Hans`**。

`platform` 和 `genre` 可以分别传，也可以同时传；同时传时只返回同时属于该机型和类型的游戏。
筛选在分页和计算 `total` 之前完成。例如：

```text
GET /api/open/v1/games?platform=nes
GET /api/open/v1/games?genre=action
GET /api/open/v1/games?platform=nes&genre=action&page_size=10&page=1
GET /api/open/v1/games?platform=dos&requires_windows=false
```

后台「Windows 3.x / 95 / 98（DOSBox-X）」复选框决定这个标记。低性能设备建议在每次拉列表时传
`requires_windows=false`；筛选发生在分页和 `total` 计算之前，避免一页里出现无法运行的游戏。

⚠️ 开放平台**没有**站内那种 facets 聚合端点（`/api/games/facets` 是站内的）。
但平台目录有专门的只读端点 `GET /v1/platforms`（见 §12）：它返回每个平台的
`runtime` / `core` / `romExtensions` 和 `native` 建议，本地客户端挑模拟器就靠它。
类型目录 `GET /v1/genres` 返回可用于 `genre` 的 id。

⚠️ 成人内容（`adult=1`）**整体排除**，下架的游戏对外也不存在。

### 响应

```json
{
  "items": [ /* 见下 */ ],
  "page": 1,
  "page_size": 24,
  "total": 1234,
  "total_pages": 52
}
```

### 单个游戏对象（白名单，`open/mapper.js`）

| 字段 | 类型 | 说明 |
|---|---|---|
| `slug` | string | **对外唯一标识**，所有别的端点都用它。没有数字 id |
| `title` | string | 已按 `lang` 取好的单语言字符串 |
| `description` | string | 同上 |
| `lang_requested` | string | 你要的那门 |
| `lang_actual` | `{title, description}` | 这两段文字**实际**是哪一门。`und` = 原名，没有语言可言 |
| `platform` | string | |
| `requires_windows` | bool | `true` = 这款 DOS 游戏需要 Windows 3.x / 95 / 98 客体与 DOSBox-X；其它游戏为 `false` |
| `genres` | string[] | |
| `tags` | string[] | |
| `year` | number | 0 = 没填 |
| `developer` | string | |
| `players` | number | |
| `multiplayer` | bool | |
| `icon` | string | emoji，没封面时的兜底 |
| `cover` | string \| **null** | 绝对地址。给不出来时是 `null`，**不会给一个必然 404 的 URL** |
| `rating` | number | 一位小数，0 = 还没人评 |
| `rating_count` | number | |
| `plays` | number | |
| `added_at` | `YYYY-MM-DD` \| null | |
| `updated_at` | ISO 8601 \| null | |
| `adult` | bool | 列表里恒为 false（整体已排除） |
| `rom_langs` | string[] | 这款有哪些 ROM 语言可选，`*` = 通用件。**只报语言码，绝不报存储 key**。没有 `games.rom` 权限也看得到 |

**绝不会出现的字段**（`mapper.js` 的 `FORBIDDEN_OUT_KEYS`，有测试逐个断言）：
`id`、`rom` / `roms` / `object_key`、`hidden`、`core`、`dos_*`、`arcade_romdata`、
`coin_reward`、`home_rank`、`video`、以及各种内部多语言列。
**别在固件里依赖这些名字**。

### ESP 侧的三条建议

1. **`page_size` 开小**。默认 24 条带简介的 JSON 轻松上 20–40 KB，
   ESP32 上一次性 `String` 接完很容易碰到堆上限。翻页拉 `page_size=5`，一次几 KB。
2. **流式解析**，别整包读进内存。`ArduinoJson` 可以直接吃 `WiFiClient` 流，
   配 `JsonDocument` 的 filter 只留你要的字段（`slug` / `title` / `cover` / `rom_langs`），
   能把内存占用压掉一个数量级。
3. **只认 `slug`**。这是唯一承诺稳定的标识。

---

## 5. 游戏详情 `GET /v1/games/:slug`

公开可读。参数只有 `lang`。返回体**就是上面那个游戏对象**（不是包一层）。

下架 / 成人 / 不存在，对外一律同一个 `404 not_found` ——
区分开就成了「这游戏是不是被下架了」的查询器。

### 5.5 直播与 P2P 联机房间

下面五条都是公开接口，不需要令牌：

```text
GET /api/open/v1/live/capacity
GET /api/open/v1/live/rooms?game=contra
GET /api/open/v1/live/rooms/<roomId>
GET /api/open/v1/netplay/rooms?game=contra
GET /api/open/v1/netplay/rooms/<roomId>?game=contra
```

- 容量接口返回 `{used,max,remaining,available}`。`used` 包含已经从大厅隐藏、但仍未关闭的房间，
  所以不要用直播列表长度自己推算容量。
- 容量是瞬时快照，不会预留席位。`available:true` 之后仍可能有别人先抢到最后一席，
  客户端必须继续处理 `go-live` 回调中的 `server is full`。
- 自动开播看到 `available:false` 时应直接跳过本局开播，不必启动采集、取 ICE 或连接信令；
  游戏本身照常运行。查询失败时可以继续尝试 `go-live`，让服务端作最终裁决。
- 直播条目带 `watchUrl`，直接打开就是 8BitGo 的观看页。
- P2P 列表传 `game=<slug>` 后会附 `gameSlug` 与 `joinUrl`，设备能显示二维码或交给手机打开。
- P2P 不传 `game` 时返回协议原生的数值 `gameId`；它是 slug 的 FNV-1a 32 位散列。
- 这些 REST 接口只负责“有哪些房间、多少玩家”。直播画面与联机输入仍走 WebRTC，
  握手由 Socket.IO 的 `/live` / `/netplay` 命名空间转发，不会把音视频压到 REST 响应里。
- 房间秒级变化，调用方不要长期缓存；不存在统一回 `404 not_found`。

### 5.6 Linux / 外部客户端开播

开播不是把视频 POST 给 REST。设备先用设备码流程拿到带 `live.write` 的用户 access token，
再换一枚最长一场直播使用的专用发布凭证：

```http
POST /api/open/v1/live/publish-token HTTP/1.1
Authorization: Bearer <用户 access token>
Content-Length: 0
```

响应给出 `publisher_token`、`signaling_url`、`socket_path`、`namespace`、`capacity_url` 和 `ice_url`。
设备把 `publisher_token` 放在 Socket.IO 握手的 `auth.publisherToken`，连接 `/live` 后发送
`go-live`；每来一位观众，就建立一条 WebRTC PeerConnection 并通过 `signal` 转发 SDP / ICE。

这里故意不让 Socket.IO 长期携带 OAuth access token：它能访问用户授权的数据且只有 15 分钟；
专用发布凭证默认 12 小时，只能开播，拿去调用 REST 会被令牌类型检查拒绝。
事件、重连、Linux 采集源与最小客户端骨架见 [外部设备直播发布协议](./live-publisher-api.md)。

---

## 6. ROM：两步式短期凭据

需要 `games.rom`。未审核应用在创建或编辑时申请该 scope，即可下载
`GET /v1/rom-samples` 中站长为每个机型选定的一款测试游戏；申请其他游戏会收到
`403 sandbox_resource_only`。完整游戏库须通过人工审核。某机型尚未配置合法样本时，目录里不会出现该机型。
样本由站长全站统一选定，开发者不能自行指定，以免反复创建应用逐款下载整个游戏库。

### 第一步：换凭据 `GET /v1/games/:slug/rom?lang=ja`

```json
{
  "url": "https://8bitgo.com/api/open/v1/rom/eyJ...xxx.yyy",
  "expires_in": 300,
  "lang_requested": "ja",
  "lang_actual": "*",
  "filename": "zeekthegeek.zip"
}
```

- `expires_in` = **300 秒**（`open/sign.js` 的 `ROM_GRANT_TTL_SEC`）。
- 凭据绑死 **app + slug + 这一个文件 + 过期时间**，URL 里**没有**存储 key ——
  抄走也只能下这一款、这几分钟。
- **ROM 语言回退**：精确语言 → 通用件（`*`）。**不做跨语言回退** ——
  要日文版给不了，就给通用件或者干脆没有，**绝不悄悄发一份别的语言的 ROM**。
  所以 `lang_actual` 必须看：它可能是 `*` 而不是你要的那门。
- 这款没有可下载的 ROM → `404 rom_unavailable`。

### 第二步：兑现 `GET /v1/rom/:grant`

**这一条不要求 `Authorization` 头** —— 凭据本身就是授权。

响应是 **`302` 重定向**到对象存储的真实地址，外加 `Cache-Control: private, no-store`。

### ⚠️ 设备端三个坑

1. **必须跟随 302，而且目标是另一个主机**（`assets.8bitgo.com`）。
   `HTTPClient` 要么开 `setFollowRedirects(HTTPC_FORCE_FOLLOW_REDIRECTS)`，
   要么自己读 `Location` 再发一次。
   ⚠️ 换主机意味着**换一张 TLS 证书**：如果你在 `WiFiClientSecure` 上钉了
   `8bitgo.com` 的叶子证书或公钥，第二跳会直接握手失败。
   设备端请钉**根 CA**（两个主机同一家 CA 签的话一张就够），别钉叶子证书 ——
   叶子证书 90 天一换，钉了等于给自己埋了个定时炸弹。
2. **五分钟窗口是给「开始下载」的**。ROM 动辄几十 MB，ESP 走 WiFi 下几分钟很正常；
   拿到凭据就立刻发起下载，别先去做别的事。窗口过了是 `410 grant_expired`，
   重新走第一步换一张就行（不用重新取令牌）。
3. **没有断点续传的承诺**。第二跳是对象存储，通常支持 `Range`，但这是它的行为、
   不是这套接口的承诺。要断点续传就自己在第二跳的地址上试 `Range`，
   失败了退回整包重下 —— 别把它当成协议的一部分。

---

### 6.1 服务端转码（`/v1/rom-plain/:grant`）：给没有自解码能力的低端设备

站点里的 ROM 是 **8BG 容器**：先 zstd 压缩、再 AES-256-GCM 加密。浏览器的 Worker 在本地做
「解密 + 解压」；但 ESP32 这类低端设备没这个能力 —— 它拿到 8BG 字节也解不开。

所以加了一条**中间件**端点。它和 `/v1/rom/:grant` 用**同一张凭据**（也是两步式、也是 302 那张票），
但**不 302**：服务端取回 8BG 对象、逐块解密解压、把**原生 ROM 的明文**流式吐给设备。
设备这一侧只要会收字节、会写文件就行，完全不用碰 zstd / AES。

**请求**（和 §6 完全一样，只是 URL 换成 `rom-plain`）：

```http
GET /api/open/v1/rom-plain/<grant> HTTP/1.1
```

**设备实际调用顺序**：先用 AppID / key 换应用令牌，再用带 `games.rom` 的令牌领一次 ROM 凭据，最后把返回 URL 中的 `/rom/` 改成 `/rom-plain/`。第二个下载请求**不带 Bearer**，短期凭据本身就是授权。下面是可直接改成固件逻辑的 `curl` 示例（需要 `jq`）：

```bash
BASE='https://8bitgo.com/api/open/v1'
APP_ID='app_替换成你的AppID'
APP_SECRET='替换成你的AppKey'
SLUG='替换成游戏slug'

TOKEN=$(curl --fail-with-body --silent --show-error -X POST "$BASE/token" \
  -H 'Content-Type: application/json' \
  -d "$(jq -n --arg id "$APP_ID" --arg secret "$APP_SECRET" \
    '{grant_type:"client_credentials",client_id:$id,client_secret:$secret}')" | jq -r '.access_token')

GRANT=$(curl --fail-with-body --silent --show-error \
  -H "Authorization: Bearer $TOKEN" "$BASE/games/$SLUG/rom")
ROM_URL=$(printf '%s' "$GRANT" | jq -r '.url')
FILENAME=$(printf '%s' "$GRANT" | jq -r '.filename')
PLAIN_URL=$(printf '%s' "$ROM_URL" | sed 's#/rom/#/rom-plain/#')
OUTPUT=${FILENAME%.8bg}

# 设备保存为原生扩展名，例如 game.nes.8bg → game.nes
curl --fail-with-body --silent --show-error "$PLAIN_URL" --output "$OUTPUT"
```

ESP 固件照这个顺序实现即可：

1. `POST /token`，解析 `access_token`；App 需要有 `games.rom` 权限。
2. `GET /games/<slug>/rom` 带 `Authorization: Bearer <access_token>`，解析响应里的 `url` 和 `filename`。
3. 把 `url` 路径中的 `/rom/` 换成 `/rom-plain/` 后 GET；**此请求不要再附加 Bearer**。
4. 按 HTTP `Content-Length` 收满正文后再把临时文件改成最终名。最终名可用上一步的 `filename` 去掉末尾 `.8bg` 得到；例如 `game.nes.8bg` → `game.nes`。不要把 JSON 错误体写进 ROM 文件：先检查状态码是 `200` 或 `206`，其余状态读取 `error` / `error_description`。

同一张 ROM 凭据最多兑现 **10 次**，包括 `HEAD`、整包下载和 Range 重试；五分钟过期。收到 `429` 后重新调用 `/games/<slug>/rom` 领新凭据，再走明文下载端点。AppKey 不要烧进公开发布的固件：设备固件可被读取，建议由你自己的服务端保管 AppKey 并代领短期凭据。

下载中断时可用 `Range: bytes=<已写入字节数>-` 从断点续传；只有收到 `206` 且 `Content-Range` 起点等于本地文件长度时才追加。若服务端回 `200`，应清空临时文件并从头写；若带 `If-Range`，值使用响应中的 `ETag`。请求 `HEAD` 可先取文件名、总长度与 ETag，不会占解码并发槽，也不传输 ROM 正文。

**响应**：

- 成功：`200`，`Content-Type: application/octet-stream`，`Content-Disposition: attachment; filename=<原始文件名>`，
  正文是解密解压后的明文 ROM。
- 成功（带 `Range`）：`206`，`Content-Range: bytes <start>-<end>/<total>`，正文是那一段明文。
- `HEAD`：返回相同文件元信息但没有正文；8BG 只读取容器头，不启动解码。
- `ETag`：8BG 明文文件按容器 `packageId` 返回稳定标签；带匹配的 `If-Range` 可安全续传，不匹配时会回完整文件 `200`。
- 非 8BG 对象（明文 ROM）：直接透传，行为和 `/v1/rom/:grant` 等价（只是流而非 302）。
- 凭据问题：与 `/v1/rom/:grant` 同（失效 `410`、非法 `403`、超额 `429`）。
- 未启用：`501 temporarily_unavailable`（部署未开启 ROM 服务或缺 `OPEN_ROM_SECRET`）。
- 太大：`413 payload_too_large`（单 ROM 明文超过 `ROM_TRANSCODE_MAX_BYTES`，默认 512MB）。
- 压缩算法当前仅支持 `store` 和 `zstd`；其它算法返回 `415 unsupported_codec`。
- 服务繁忙：`503 server_busy`（并发解压数超过 `ROM_TRANSCODE_CONCURRENCY`，默认 2；超额拒服务，不是排队）。
- 上游或转码超时：`504 upstream_timeout`，设备可退避后重试。
- 取回或转码失败：`502 bad_gateway`。

**断点续传**：支持。8BG 每个分块独立压缩+加密，所以服务端按字节范围映射出需要的分块、
只解密解压那几块，WiFi 断了能从断点续 —— 几十上百 MB 的 ROM 重来一遍等于白烧服务端 CPU。
设备照常发 `Range: bytes=<start>-<end>`，拿到 `206 + Content-Range` 即可。

**代价谁来挡**（解压是 CPU + 带宽开销，必须挡住放大面）：

- 不落盘 —— 当前打包器每块 8MB 原文，服务端逐块拉取、解密、解压并写回；内存按并发数和单块大小封顶，不随 ROM 总大小增长。
- 每块都校验 sha256 与声明的 sourceSize，zip-bomb 级别的恶意包在单块边界就被挡下。
- 密钥不落库：直接复用 ROM 打包那套 `deriveRomPackKey`（由 `ROM_PACK_SECRET` 派生）。
- 单 ROM 大小上限、全局并发闸、按 AppID/IP 限流（同 §6 那两道），超额拒服务。

> 这套接口的「安全模型」见 §1 方案 1：自己架一层中转，ESP 只认自己的服务端，secret 留在服务端。
> 多一跳，但也顺带解决了限流、ROM 缓存、和「换 key 不用重刷固件」。

---

### 6.5 设备码流程：怎么拿到**用户级**令牌

`client_credentials` 换来的令牌**背后没有用户**，所以它永远拿不到 `library.*` /
`saves.*`。要读某个玩家的收藏和存档，得让**那个玩家**授权一次。

而设备上没有浏览器 —— 弹不出授权页，也接不住回调地址。所以走的是 RFC 8628
设备码流程：设备显示一串码，人在手机上输进去点同意，设备这边一直轮询。

```
1. POST /v1/device/code          ← 设备要一串码（带 AppID + key）
   └─ 拿到 user_code（给人看）、device_code（给机器用）、interval

2. 屏幕上显示 user_code + verification_uri
   （能画二维码的话直接编 verification_uri_complete，用户不用手打）

3. POST /v1/token 反复轮询       ← grant_type=urn:ietf:params:oauth:grant-type:device_code
   ├─ 400 authorization_pending  → 还没人确认，按 interval 接着等
   ├─ 400 slow_down              → 轮太快了，把间隔加大
   ├─ 400 access_denied          → 用户点了拒绝，停
   ├─ 400 expired_token          → 码过期了，回第 1 步
   └─ 200 {access_token,…}       → 成了，这是一枚用户级令牌
```

#### `POST /v1/device/code`

请求（JSON 或 form，和 token 端点一样）：

```json
{"client_id":"app_xxxx","client_secret":"yyyy","scope":"library.read saves.read"}
```

`scope` 可以不传（= 已获批的全部）；传了就必须是子集，**不静默降级**。

响应：

```json
{
  "device_code": "…",
  "user_code": "BCDF-GHJK",
  "verification_uri": "https://8bitgo.com/open/device",
  "verification_uri_complete": "https://8bitgo.com/open/device?code=BCDF-GHJK",
  "expires_in": 900,
  "interval": 5
}
```

`user_code` 的字母表刻意去掉了元音和 `0/O`、`1/I/L` —— 用户是照着你的小屏幕
一个字符一个字符念出来手打的。显示时**保留中间那道横线**，比对时横线会被忽略。

#### 轮询

```json
{"grant_type":"urn:ietf:params:oauth:grant-type:device_code",
 "client_id":"app_xxxx","client_secret":"yyyy","device_code":"…"}
```

⚠️ **`authorization_pending` 和 `slow_down` 不是失败。** 它们的 HTTP 状态是 400
（协议规定的），但意思是「接着等」。把 400 一律当错误退出的固件，会在用户
明明已经点了同意的时候放弃 —— 这是接入这套流程最常见的一个错。

⚠️ 一串 `device_code` **只能兑现一次**。拿到令牌之后那条记录就没了，
再轮询回 `invalid_grant`。令牌自己存好（15 分钟，到期要重新走一遍流程）。

⚠️ 沙箱应用只能授权给**开发者本人和登记过的测试账号**。别人输码会看到一句
「这个应用还在沙箱阶段」，点不了同意。上产之后才对所有人开放。

## 7. 用户数据与游玩上报（要用户级令牌）

需要走完 §6.5 拿到的那枚令牌，请求头照旧 `Authorization: Bearer …`。

### `GET /v1/library` —— 收藏与最近在玩

需要 `library.read`。

```json
{
  "favorites": [ /* 和 /v1/games 的元素同一个形状 */ ],
  "recent": [ /* 同上，最多 12 条 */ ],
  "favorites_total": 37
}
```

回的是**完整的游戏对象**而不是一串 slug：否则你拿到十个 slug 之后还得再发十次请求
去换标题和封面。收藏一次最多给 100 条，`favorites_total` 告诉你有没有被截断。

### `POST /v1/games/:slug/play` —— 其它设备上报一次真实开玩

需要用户级 `library.write`。调用时机必须是**模拟器已经进入可玩状态**，不要在用户只打开详情、
ROM 仍在下载或引擎启动失败时调用：

```http
POST /api/open/v1/games/contra/play HTTP/1.1
Authorization: Bearer <设备码换来的用户令牌>
Content-Length: 0
```

```json
{"ok":true,"counted":true}
```

- `counted:true`：这个账号第一次玩这款，公开游戏对象里的 `plays` 会加 1。
- `counted:false`：这个账号之前已经在网页、电视或另一台掌机上玩过；请求仍然成功，只是不重复加。
- 接口同时刷新账号的“最近在玩”，所以其它设备的 `/v1/library` 会看到这款。
- 网络超时可以放心重试；数据库主键 `(game_id, kind, identity)` 会挡住并发与重复上报。
- **这里统计的是去重玩家数，不是启动会话数。** 同一账号每天玩十次仍只算 1；如果以后要统计
  会话量，应另建事件表，不能把这张去重表改成可重复插入。

为什么必须用用户级令牌：应用级令牌背后没有用户；允许客户端自报 `device_id` 等于允许它每次
换个字符串刷数。设备码授权把网页和其它设备都归到同一账号，正好与现有统计口径一致。

### `GET /v1/saves` —— 存档清单

需要 `saves.read`。**只给元信息，不带内容**（一份 DOS 变更包几百 KB）。

```json
{"items":[{"runtime":"jsdos","game_slug":"contra","slot":0,
           "size":8,"created_at":"…","updated_at":"…"}]}
```

### `GET /v1/saves/:runtime/:slug?slot=0` —— 取一份存档

需要 `saves.read`。回的是 `application/octet-stream` 原始字节，
外加 `x-save-updated-at`（毫秒时间戳）和 `Cache-Control: private, no-store`。

- `runtime` 白名单：`emulatorjs` `jsdos` `cloudgame` `jsnes` `ruffle` `webretro` `j2me`
- `slot` 0–9，DOS 只用 0
- 没有这一份 → `404 not_found`；引擎名或档位不合法 → `400 invalid_request`

⚠️ 写入（`saves.write`）**还没有**，见 §9。

## 8. 限流与错误

### 实际的限流数字

全部来自 `open.js` 里的 `take(key, limit, windowMs)` 调用：

| 桶 | 上限 | 窗口 | 位置 |
|---|---|---|---|
| 取令牌 · 按 IP | 120 | 1 小时 | `open:token:ip:<ip>` |
| 取令牌 · 按 AppID | 60 | 1 小时 | `open:token:<client_id>` |
| 设备码 · 按 IP / AppID | 60 | 1 小时 | `open:device:ip:<ip>` / `open:device:<client_id>` |
| **带令牌**的接口 · 按 AppID | **3600** | 1 小时 | `open:api:<app_id>` |
| **匿名**（公开接口）· 按 IP | **300** | 1 分钟 | `open:pub:ip:<ip>` |
| **匿名** · 全站兜底 | **3000** | 1 分钟 | `open:pub:global` |
| ROM 换凭据 · 沙箱按 AppID | **10** | 1 小时 | `open:rom:sandbox:<app_id>` |
| ROM 换凭据 · 上产按 AppID | **600** | 1 小时 | `open:rom:<app_id>` |
| ROM **兑现** · 按票 | 10 | 5 分钟（= 票的寿命） | `open:romdl:<grant>` |
| ROM **兑现** · 按 IP | 60 | 1 分钟 | `open:romdl:ip:<ip>` |

> 📌 **匿名那两档是 2026-09-13 随公开化一起加的。** 在那之前每一条接口背后都有一个
> AppID 可以计数；公开之后没有了，只剩 IP。而 IP 这个维度本身不可靠 ——
> 反代没把真实访客地址透传下来时所有人会塌缩成同一个值，
> 那种情况下代码会**跳过按 IP 那一道**（宁可放宽也不误伤真实用户），
> 全站那一道就成了唯一的下限。所以两档缺一不可。
>
> 📌 **一张 ROM 凭据最多兑 10 次。** 上面的 10/小时或 600/小时限的是**领票**，不是**兑票** ——
> 领一张之后在它活着的五分钟里兑多少次，2026-09-13 之前完全不设限。
> 正常一次就够，10 次是留给断点续传和失败重试的余量。
>
> 📌 **带令牌反而比匿名宽松**（3600/小时 ≈ 1 QPS，独享；匿名 300/分钟但要和所有人
> 共享全站那 3000/分钟）。设备量大的话还是建议创建应用、带令牌调。

> ⚠️ **和 `docs/open-platform.md` §1.3 不一致**。那张表写的是
> 「沙箱 QPS 5 / 日 10 000，生产 QPS 50 / 日 200 000，按 tier 可调」，
> 而代码里是**不分 tier 的固定小时桶**：`rate_tier` 字段查出来了
> （`open/apps.js` 的 `authenticateApp`），但没有任何地方用它。
> 按代码写固件：**平均 1 QPS，沙箱 ROM 一小时 10 张凭据，上产一小时 600 张**。

平均下来普通接口约 1 QPS。设备端正常轮询（几分钟一次）离这个上限很远，
但**开机时连续翻页**很容易短时间打满 —— 列表拉完就缓存在 Flash/NVS 里，别每次开机重拉。

### `429` 长什么样

```json
{ "error": "rate_limited", "error_description": "请求过于频繁", "retry_after": 1800 }
```

同时带 `Retry-After:` 响应头（秒）。**照着它退避**，别写死重试间隔。

### 错误体（OAuth 风格，所有端点一致）

```json
{
  "error": "insufficient_scope",
  "error_description": "需要 games.rom",
  "error_uri": "https://8bitgo.com/developers/docs/errors#insufficient_scope",
  "scope": "games.rom"
}
```

⚠️ `error_description` 是**中文**的，别在固件里做英文匹配 —— **认 `error` 字段**。
（`error_uri` 指向的那个文档页现在还不存在，忽略它。）

| HTTP | `error` | 什么意思 / 怎么办 |
|---|---|---|
| 400 | `invalid_request` | 请求体解析不了（畸形 JSON / 畸形表单）。413 也是这个码，表示**请求体超过 16 KB** |
| 400 | `unsupported_grant_type` | 只支持 `client_credentials` |
| 400 | `unauthorized_client` | 这个应用是 `public` 类型，不能用 `client_credentials` |
| 400 | `invalid_scope` | 不认识的 scope / 要了用户级 scope / 应用没获批。描述里写了差哪个 |
| 401 | `invalid_client` | AppID 或 key 不对。⚠️ 两种失败**回同一句话**（防 AppID 枚举），别指望从这里区分 |
| 401 | `invalid_token` | 令牌无效或过期 → 续一次，重试一次 |
| 403 | `insufficient_scope` | 令牌没这个权限。响应里带 `scope` 字段告诉你差哪个 |
| 403 | `sandbox_resource_only` | 沙箱申请了 `games.rom`，但这款不在测试样本目录；或站长已撤换样本 |
| 403 | `app_not_authorized` | 应用已停用，或当前 ROM 权限已被撤销 |
| 403 | `invalid_grant` | ROM 凭据签名不对 |
| 404 | `not_found` | 没这款游戏（下架 / 成人 / 真不存在，对外不区分） |
| 404 | `rom_unavailable` | 这款游戏没有可下载的 ROM |
| 410 | `grant_expired` | ROM 凭据过期 → 回第一步再换一张 |
| 429 | `rate_limited` | 看 `Retry-After` |
| 413 | `invalid_request` | 请求体超过 16 KB |
| 500 | `server_error` | 服务端自己的问题。**不会带任何内部信息**，重试或者联系我们 |
| 501 | `temporarily_unavailable` | 服务端没配密钥，整套或 ROM 那部分没启用。**你改不了，去看部署** |

---

## 9. 语言码

`lang` 只认这八个（`shared/site-languages.js`）：

```
zh-Hans  zh-Hant  en  es  fr  it  de  ja
```

- 认不出来的**不报错**，一律退到默认值 `en`。
- 宽松匹配一层：`zh-hans` / `ZH_HANT` / `en-US` 这类写法认得出来。
- ⚠️ 库里的译文是**残缺的**。标题在非中文界面下**刻意用原名**（`lang_actual: "und"`）；
  简介 es / fr 目前基本是空的，会退到英文、再退到中文。
  所以设备上要显示「暂无译文」之类的提示，**靠 `lang_actual`，别靠 `lang_requested`**。

---

## 10. 还做不到的事

### 云存档的**写入**

读取已经能用了（§7）。写入（`saves.write`）还没做 —— 它在 `scopes.js` 里标着
sensitive，而且要连着三件事一起想清楚才能上：单份 4 MB / 每人 200 份 / 总共 64 MB
的配额怎么在第三方这条路上算、覆盖别人正在用的档位怎么防、删除要不要留审计。
只读那条路错了最多是读到旧数据，写错了是**把玩家的进度盖掉**。

在那之前，设备端能做的是「读云端的档 + 写本地」，或者把存档导出成文件
（DOS 那一路见站内工具栏的「导出存档文件」）。

⚠️ **不要**为了绕开这一点去用站内的 `/api/saves/*`：那套认的是**站内登录令牌**，
而那枚令牌是全权限的 —— 能改邮箱、能删号。在一台可以被 dump Flash 的设备上放它，
比放 client_secret 严重得多。

游玩上报已经可以走 §7 的 `POST /v1/games/:slug/play`。它不是常驻心跳：游戏进入可玩状态
上报一次即可，后续重试与换设备由服务端按账号去重。

---

## 11. 一条能跑通的最小链路

```
1. POST /v1/token                      ← JSON 或 form，两种都行
   └─ 存 access_token + millis() + expires_in

2. GET  /v1/me                          ← 接线时打一次，确认 scope 对
                                           Authorization: Bearer <token>

3. GET  /v1/games?page_size=5&page=1&lang=zh-Hans
   └─ 流式解析，只留 slug / title / cover / rom_langs，写进 NVS

4. GET  /v1/games/<slug>/rom?lang=*     ← 需要 games.rom
   └─ 拿到 url，5 分钟内用掉

5. GET  <那个 url>                       ← 不带 Authorization
   └─ 跟随 302 → assets 主机 → 写进 SD / SPIFFS

要读玩家自己的收藏和存档，在第 1 步之前再插一段（见 §6.5）：

```
0a. POST /v1/device/code                ← 拿 user_code + device_code
0b. 屏幕显示 user_code 和 8bitgo.com/open/device
0c. POST /v1/token 每 interval 秒轮一次  ← grant_type=…:device_code
    （authorization_pending / slow_down 都是「接着等」，不是失败）
0d. 拿到用户级令牌 → GET /v1/library、GET /v1/saves
0e. 游戏真正可玩后 → POST /v1/games/<slug>/play（需要 library.write）
```

每一步的失败都认 `error` 字段，不认 `error_description`。
`401 invalid_token` 回第 1 步一次；`410 grant_expired` 回第 4 步一次；
`429` 按 `Retry-After` 退避。其余的错误直接报给用户看，别自动重试。

---

## 12. 本地 / Linux 客户端：下载 ROM 后用本机模拟器跑

这套接口对「能联网的本地机器（Linux 小主机、x86 PC、单板机）」完全够用：
机器经 WiFi 拿 AppID + Key 换令牌，拉游戏列表，取 ROM 签名地址，下载 ROM，
再交给本机模拟器运行。和 ESP 嵌入式的区别是：机器有完整的 CPU / 存储 / 文件系统，
不用在固件里抠内存，所以**整套接口都能直接用**，没有 ESP 那边的流式解析约束。

### 12.1 先拉平台目录，决定能不能跑、用什么跑

```
GET /v1/platforms          ← 只要令牌有效就回，不限 scope
```

返回 `items`，每个平台带：

| 字段 | 含义 |
|---|---|
| `runtime` | 站内用的运行环境：`emulatorjs` / `jsdos` / `ruffle` / `html5` / `play` / `j2me` |
| `core` | emulatorjs 的核心名（`nes` / `snes` / `arcade` …），本地客户端据此选模拟器 |
| `romExtensions` | 这个平台 ROM 的扩展名，下载后按它判断怎么喂给模拟器 |
| `native.runnable` | **能不能拿这个平台的 ROM 在本机模拟器上跑**（见下面 12.2 的三档） |
| `native.emulator` | runnable 时推荐的 Linux 原生模拟器项目名 |
| `native.note` | 格式上的坑，或者 runnable=false 的原因。**这一句是写给用户看的**，客户端可以直接显示 |
| `enabled` | 这个平台在站上开着没有。`false` = 前台 404、列表里查不到东西，客户端应当整个隐藏 |

`game.platform` 字段就是这里的 `id`。客户端拿 `id` 查这张表即可，
**别把平台映射硬编码进客户端**——站上加平台时旧客户端就认不出了。

### 12.2 哪些平台「下载即跑」，哪些不是

- ✅ **下载即跑**：`runtime=emulatorjs` 那 23 个（nes / snes / gba / gb / gbc / n64 /
  nds / psx / segaMD / segaMS / segaGG / segaCD / sega32x / pce / ngp / atari2600 /
  atari5200 / atari7800 / lynx / c64 / amiga / ws / arcade）+ `java`
  （`runtime=j2me`，FreeJ2ME），一共 24 个。
  ROM 是单个文件（`.nes` / `.sfc` / `.zip` romset / `.jar` …），`filename` 字段直接
  告诉你文件名，按 `romExtensions` 交给对应模拟器。

  > ⚠️ **这些平台里有几个站上是关着的。** 每一行都带 `enabled`，它跟着站点的平台
  > 白名单走：`enabled:false` 的平台在前台是 404，`/v1/games?platform=<id>` 也查不到东西。
  > **客户端要按 `enabled` 过滤**，别照着这份名单给用户列出永远没有内容的分类。
  > 这个名单是会变的（NDS 就是后来才补进去的），所以别在代码里写死「有哪几个」。
- ⚠️ **能跑但要处理格式**：
  - `dos`：ROM 是 **jsdos 包**（Web 专用格式）。本地 DOSBox 要先解包、把内部目录结构
    整理成裸 DOS 游戏目录才能跑，不是直接喂 zip。
  - `flash`：`.swf` 用 **Ruffle**（有 Linux 原生构建）跑。
- ❌ **本地跑不了**：
  - `html5`：根本不是 ROM，是一个网页，没有可下载的执行文件。
  - `ps2`：**不是「没有模拟器」，是「拿不到盘」。** PS2 是 DVD，一张 1~4.7GB，
    站上根本不提供整份下载 —— 浏览器里那个实验性的 Play! 走 HTTP Range 只读游戏
    真正读到的扇区。所以 `/v1/games/:slug/rom` 这条路对 PS2 不成立。
    （Linux 上 PCSX2 很成熟，但盘得你自己准备。）

  客户端应当把这两个平台整个隐藏，别让用户点进去下载一堆用不了的东西。

### 12.3 一个游戏的完整本地流程

```
1. GET  /v1/platforms                              ← 缓存整张表（很少变）
2. POST /v1/token  (client_credentials)             ← 拿应用级令牌
3. GET  /v1/games?platform=arcade&lang=zh-Hans      ← 列表
4. GET  /v1/games/:slug                             ← 详情，拿到 platform
5. GET  /v1/games/:slug/rom?lang=*                  ← 需要 games.rom
    └─ 回 { url, filename, lang_actual }，5 分钟内用掉
6. GET  <url>   （不带 Authorization，跟随 302）      ← 下载 ROM 到本地
7. 查 /v1/platforms 里 platform 的 native.emulator   ← 选模拟器
8. 用对应模拟器打开下载下来的 filename               ← 开玩
```

ROM 那一步（`/v1/rom/:grant`）是 302 到 `assets.8bitgo.com`，下载工具要**跟随重定向且接受换主机**
（TLS 钉根 CA，别钉叶子证书——见 §6 的设备端三个坑，对本地客户端同样成立）。

要读玩家自己的收藏和存档、做到「续上云端进度」：走 §6.5 设备码流程拿用户级令牌，
再 `GET /v1/library`、`GET /v1/saves/:runtime/:slug`。⚠️ **写回**（`saves.write`）还没有，
本地进度暂时不能推回云端——只读能续，写入要等这一轮补齐。

### 12.4 AppKey 别烧死在分发的客户端里

§1 说的「secret 只能留服务端」对分发的 Linux 客户端同样是硬约束：把 AppKey 编译进
要给别人装的包，等于任何人拿到一份就能用你的配额、还能在 `/open` 控制台撤销那把 key 砖化所有设备。
自用几台无所谓；要做成产品，走「自己架一层中转、secret 留服务端」那一条。
