import { HomeIntro } from '@/components/home/HomeIntro'
import { HomeBanner } from '@/components/home/HomeBanner'
import { FeaturedCarousel } from '@/components/home/FeaturedCarousel'
import {
  FaqSection,
  GenreGridSection,
  LatestSection,
  PlatformsSection,
  PopularSection,
  ToolsSection,
  TogetherSection,
  TopRatedSection,
} from '@/components/home/sections'
import { useDocumentTitle } from '@/lib/useDocumentTitle'

export function HomePage() {
  useDocumentTitle()
  return (
    <div className="space-y-10 py-8">
      <HomeIntro />
      <HomeBanner />
      <PopularSection />
      <PlatformsSection />
      <LatestSection />
      <TogetherSection />
      <TopRatedSection />
      <GenreGridSection />
      <FeaturedCarousel />
      <ToolsSection />
      <FaqSection />
    </div>
  )
}
