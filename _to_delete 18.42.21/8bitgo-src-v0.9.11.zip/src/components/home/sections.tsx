import { Link } from 'react-router-dom'
import { SectionHeader } from '@/components/ui/SectionHeader'
import { HScroll } from '@/components/ui/HScroll'
import { Accordion } from '@/components/ui/Accordion'
import { Button } from '@/components/ui/Button'
import { GameCard } from '@/components/game/GameCard'
import { GameCardWide } from '@/components/game/GameCardWide'
import { PlatformCard } from '@/components/game/PlatformCard'
import { StreamCard } from '@/components/game/StreamCard'
import { GameCover } from '@/components/game/GameCover'
import {
  getCoinGames,
  getGamesByGenre,
  getGenres,
  getLiveStreams,
  getMultiplayerGames,
  getNewestGames,
  getPlatforms,
  getPopularGames,
  getTopRatedGames,
} from '@/services/games'
import { genreMap } from '@/data/genres'
import { platformMap } from '@/data/platforms'
import { gradientFor } from '@/lib/gradients'
import { faq } from '@/data/faq'
import type { GenreId } from '@/types'

/* ---------------- 直播 ---------------- */
export function LiveSection() {
  const streams = getLiveStreams()
  return (
    <section className="container-x">
      <SectionHeader
        id="live"
        title="直播"
        subtitle={`${streams.length} 位主播正在直播复古游戏`}
        icon={<span className="inline-block h-2.5 w-2.5 rounded-full bg-live animate-blink" />}
        moreTo="/#live"
        moreLabel="全部直播"
      />
      <HScroll itemClassName="w-72 sm:w-80">
        {streams.map((s) => (
          <StreamCard key={s.id} stream={s} />
        ))}
      </HScroll>
    </section>
  )
}

/* ---------------- 最多人玩 ---------------- */
export function PopularSection() {
  const games = getPopularGames(12)
  return (
    <section className="container-x">
      <SectionHeader
        title="最多人玩的模拟器游戏"
        subtitle="按累计游玩次数排序"
        icon="🔥"
        moreTo="/games?sort=popular"
      />
      <HScroll>
        {games.map((g, i) => (
          <GameCard key={g.slug} game={g} rank={i + 1} />
        ))}
      </HScroll>
    </section>
  )
}

/* ---------------- 按平台 ---------------- */
export function PlatformsSection() {
  const platforms = getPlatforms().slice(0, 8)
  return (
    <section className="container-x">
      <SectionHeader title="按平台玩复古游戏" subtitle="从掌机到街机，挑一台你的童年主机" icon="🎮" moreTo="/platforms" />
      <HScroll itemClassName="w-52 sm:w-56">
        {platforms.map((p) => (
          <PlatformCard key={p.id} platform={p} className="h-full" />
        ))}
      </HScroll>
    </section>
  )
}

/* ---------------- 最新上线 ---------------- */
export function LatestSection() {
  const games = getNewestGames(10)
  return (
    <section className="container-x">
      <SectionHeader title="最新在线复古游戏" subtitle="每周持续更新" icon="✨" moreTo="/games?sort=newest" />
      <HScroll itemClassName="w-64 sm:w-72">
        {games.map((g, i) => (
          <GameCardWide key={g.slug} game={g} isNew={i < 3} />
        ))}
      </HScroll>
    </section>
  )
}

/* ---------------- 一起玩 ---------------- */
export function TogetherSection() {
  const games = getMultiplayerGames(12)
  return (
    <section className="container-x">
      <SectionHeader
        title="一起玩"
        subtitle="支持本地双人或在线联机的游戏，邀请好友加入房间"
        icon="👥"
        moreTo="/games?multiplayer=1"
      />
      <HScroll>
        {games.map((g) => (
          <GameCard key={g.slug} game={g} />
        ))}
      </HScroll>
    </section>
  )
}

/* ---------------- 赢取 G 币 ---------------- */
export function CoinSection() {
  const games = getCoinGames(12)
  return (
    <section className="container-x">
      <div className="rounded-3xl border border-coin/25 bg-gradient-to-br from-coin/10 via-transparent to-transparent p-5 sm:p-6">
        <SectionHeader
          title="通过游戏赢取 G 币"
          subtitle="通关、刷新纪录或完成每日任务即可获得 G 币，用于兑换主题与会员权益"
          icon="🪙"
          moreTo="/games?coin=1"
        />
        <HScroll bleed={false}>
          {games.map((g) => (
            <GameCard key={g.slug} game={g} />
          ))}
        </HScroll>
      </div>
    </section>
  )
}

/* ---------------- 评分最高 ---------------- */
export function TopRatedSection() {
  const games = getTopRatedGames(12)
  return (
    <section className="container-x">
      <SectionHeader title="评分最高的经典游戏" subtitle="来自玩家的真实评分" icon="⭐" moreTo="/games?sort=rating" />
      <HScroll>
        {games.map((g, i) => (
          <GameCard key={g.slug} game={g} rank={i + 1} />
        ))}
      </HScroll>
    </section>
  )
}

/* ---------------- 分类网格 ---------------- */
/** 每个类型一套固定渐变，色相各不相同，让大卡片彼此区分 */
const GENRE_GRADIENTS: Record<GenreId, string> = {
  action: 'linear-gradient(135deg, #ef4444 0%, #991b1b 100%)',
  fighting: 'linear-gradient(135deg, #fb923c 0%, #c2410c 100%)',
  shooter: 'linear-gradient(135deg, #22d3ee 0%, #0e7490 100%)',
  platformer: 'linear-gradient(135deg, #ec4899 0%, #9d174d 100%)',
  adventure: 'linear-gradient(135deg, #fbbf24 0%, #d97706 100%)',
  rpg: 'linear-gradient(135deg, #a78bfa 0%, #6d28d9 100%)',
  strategy: 'linear-gradient(135deg, #818cf8 0%, #3730a3 100%)',
  racing: 'linear-gradient(135deg, #60a5fa 0%, #1d4ed8 100%)',
  sports: 'linear-gradient(135deg, #4ade80 0%, #15803d 100%)',
  music: 'linear-gradient(135deg, #e879f9 0%, #a21caf 100%)',
  puzzle: 'linear-gradient(135deg, #2dd4bf 0%, #0f766e 100%)',
  card: 'linear-gradient(135deg, #fb7185 0%, #be123c 100%)',
}

/** 下方分栏里展示的类型（各挑 4 款游戏）——取游戏数量较多的几个，保证列表填满 */
const GENRE_COLUMNS: GenreId[] = ['action', 'adventure', 'rpg', 'puzzle']

export function GenreGridSection() {
  const genres = getGenres().filter((g) => g.count > 0)
  const columns = GENRE_COLUMNS.map((id) => ({ genre: genreMap[id], games: getGamesByGenre(id, 4) })).filter((c) => c.games.length > 0)

  return (
    <section className="container-x">
      <SectionHeader title="按类型探索" subtitle="选一种口味，从热门开始玩" icon="🧭" moreTo="/genres" />

      {/* 大类型卡片：横向滑动 */}
      <HScroll itemClassName="w-64 sm:w-72">
        {genres.map((g) => (
          <Link
            key={g.id}
            to={`/games?genre=${g.id}`}
            className="card-hover relative flex h-36 flex-col justify-end overflow-hidden rounded-card p-5"
            style={{ background: GENRE_GRADIENTS[g.id] ?? gradientFor(g.id) }}
          >
            <span className="pixel-grid absolute inset-0 opacity-25" aria-hidden />
            <span
              className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[6.5rem] leading-none opacity-25 mix-blend-soft-light select-none"
              aria-hidden
            >
              {g.icon}
            </span>
            <span className="relative text-2xl font-extrabold tracking-tight text-white drop-shadow-[0_2px_6px_rgba(0,0,0,0.35)]">
              {g.name}
            </span>
            <span className="relative mt-0.5 text-xs font-medium text-white/85">{g.count} 款游戏</span>
          </Link>
        ))}
      </HScroll>

      {/* 分栏：每个类型列出几款样例（缩略图 + 标题 + 平台 + 查看） */}
      <div className="mt-8 grid gap-x-8 gap-y-6 sm:grid-cols-2 xl:grid-cols-4">
        {columns.map(({ genre, games }) => (
          <div key={genre.id}>
            <div className="mb-2 flex items-center justify-between">
              <h3 className="flex items-center gap-1.5 text-base font-bold">
                <span aria-hidden>{genre.icon}</span>
                {genre.name}
              </h3>
              <Link to={`/games?genre=${genre.id}`} className="text-xs text-muted transition hover:text-brand-hover">
                更多 →
              </Link>
            </div>
            <ul className="space-y-1">
              {games.map((g) => (
                <li key={g.slug}>
                  <Link to={`/games/${g.slug}`} className="group flex items-center gap-3 rounded-xl p-1.5 transition hover:bg-black/[0.04]">
                    <GameCover game={g} ratio="square" showTitle={false} showBadge={false} iconSize="sm" className="h-11 w-11 shrink-0 rounded-lg" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold leading-tight">{g.titleZh ?? g.title}</span>
                      <span className="block text-xs text-muted">{platformMap[g.platform]?.shortName}</span>
                    </span>
                    <span className="shrink-0 rounded-full bg-surface-2 px-3 py-1 text-xs font-semibold text-muted transition group-hover:bg-brand group-hover:text-white">
                      查看
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  )
}

/* ---------------- 工具与扩展 ---------------- */
const TOOLS = [
  {
    icon: '🤸',
    tag: 'Pose Control',
    title: '体感控制器',
    desc: '打开摄像头，用挥手、跳跃、下蹲代替按键。无需任何外设，在客厅里就能全身投入。',
    to: '/apps',
    cta: '了解体感玩法',
  },
  {
    icon: '🎙️',
    tag: 'Voice Control',
    title: '语音控制器',
    desc: '说出「跳」「开火」「暂停」即可操作游戏，适合无障碍场景，也适合解放双手的懒人模式。',
    to: '/apps',
    cta: '试试语音操作',
  },
  {
    icon: '🎬',
    tag: 'AI Video',
    title: 'AI 视频剪辑',
    desc: '一键录制游戏过程，AI 自动挑出高光时刻剪成短视频，配好字幕直接分享到社交平台。',
    to: '/apps',
    cta: '录制我的高光',
  },
]

export function ToolsSection() {
  return (
    <section className="container-x">
      <SectionHeader title="工具与扩展" subtitle="不只是模拟器：让复古游戏玩出新花样" icon="🧰" />
      <div className="grid gap-4 md:grid-cols-3">
        {TOOLS.map((t) => (
          <article
            key={t.title}
            className="group relative overflow-hidden rounded-card border border-line bg-surface p-6 transition hover:border-brand/60"
          >
            <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-brand/15 blur-3xl transition group-hover:bg-brand/30" aria-hidden />
            <div className="relative">
              <span className="text-pixel text-[10px] text-brand-hover">{t.tag}</span>
              <div className="mt-3 flex items-center gap-3">
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-brand-soft text-2xl" aria-hidden>
                  {t.icon}
                </span>
                <h3 className="text-lg font-bold">{t.title}</h3>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-muted">{t.desc}</p>
              <Button to={t.to} variant="secondary" size="sm" className="mt-5">
                {t.cta} →
              </Button>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}

/* ---------------- FAQ ---------------- */
export function FaqSection() {
  return (
    <section className="container-x">
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-4">
          <SectionHeader title="在线模拟器游戏常见问题" subtitle="关于付费、下载、平台与存档" icon="❓" />
          <p className="text-sm leading-relaxed text-muted">
            没找到答案？加入我们的 Discord 社区，或者在博客中查看更详细的教程。
          </p>
          <div className="mt-4 flex gap-2">
            <Button to="/blog" variant="secondary" size="sm">
              阅读博客
            </Button>
            <Button to="/about" variant="ghost" size="sm">
              关于我们
            </Button>
          </div>
        </div>
        <div className="lg:col-span-8">
          <Accordion items={faq} />
        </div>
      </div>
    </section>
  )
}
