import { Link } from 'react-router-dom'
import { getGenres } from '@/services/games'

/** 首页顶部：标题 + 一句话说明 + 类型快捷入口 */
export function HomeIntro() {
  const genres = getGenres().filter((g) => g.count > 0)

  return (
    <section className="container-x">
      <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">
        免费在线玩
        <span className="bg-gradient-to-r from-brand-hover via-sky-400 to-cyan-300 bg-clip-text text-transparent">
          经典模拟器游戏
        </span>
      </h1>
      <p className="mt-3 max-w-3xl text-base leading-relaxed text-muted">
        红白机、超任、GBA、PS1、N64、街机……上百款童年经典，支持即时存档、手柄与联机同乐。
      </p>

      <nav className="mt-5 flex flex-wrap gap-2" aria-label="按类型浏览">
        {genres.map((g) => (
          <Link
            key={g.id}
            to={`/games?genre=${g.id}`}
            className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-line bg-surface px-3 text-sm font-medium text-fg transition hover:border-brand/60 hover:bg-brand-soft"
          >
            <span aria-hidden>{g.icon}</span>
            {g.name}
          </Link>
        ))}
      </nav>
    </section>
  )
}
