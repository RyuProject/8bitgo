/** 侧边栏 / 抽屉共用的导航配置 */

export interface NavLinkItem {
  label: string
  to: string
  icon: string
  /** 精确匹配 pathname + search；不设置时按 pathname 前缀匹配 */
  exact?: boolean
  external?: boolean
  badge?: string
}

export interface NavGroup {
  title: string
  items: NavLinkItem[]
}

export const mainNav: NavLinkItem[] = [
  { label: '发现', to: '/', icon: '🏠', exact: true },
  { label: '联机玩', to: '/games?multiplayer=1', icon: '👥', exact: true },
  { label: '直播', to: '/#live', icon: '📺', badge: 'LIVE' },
  { label: '博客', to: '/blog', icon: '📝' },
]

export const libraryNav: NavLinkItem[] = [
  { label: '全部游戏', to: '/games', icon: '📚', exact: true },
  { label: '游戏平台', to: '/platforms', icon: '🎮' },
  { label: '游戏类型', to: '/genres', icon: '🧭' },
  { label: '开发商', to: '/developers', icon: '🏢' },
]

/** 侧边栏底部「我们的社区」：全部为外部链接，替换成你自己的社群地址即可 */
export const communityNav: NavLinkItem[] = [
  { label: 'Discord', to: 'https://discord.com', icon: '💬', external: true },
  { label: 'X / Twitter', to: 'https://x.com', icon: '🐦', external: true },
  { label: 'YouTube', to: 'https://youtube.com', icon: '▶️', external: true },
  { label: 'Instagram', to: 'https://instagram.com', icon: '📷', external: true },
  { label: 'Facebook', to: 'https://facebook.com', icon: '📘', external: true },
]

export const footerLinks = [
  { label: '关于我们', to: '/about' },
  { label: '服务条款', to: '/terms' },
  { label: '隐私政策', to: '/privacy' },
  { label: '应用与扩展', to: '/apps' },
  { label: '8BitGo TV', to: '/tv' },
  { label: '玩本地 ROM', to: '/play-local' },
]
