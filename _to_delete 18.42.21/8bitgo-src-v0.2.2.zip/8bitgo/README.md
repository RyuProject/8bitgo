# 8BitGo — 在线复古模拟器游戏站

基于 **Vite + React 19 + TypeScript + Tailwind CSS v4 + React Router 7** 搭建的复古游戏网站，
内置 **EmulatorJS** 集成，可以在浏览器中直接运行本地 ROM。

## 快速开始

```bash
npm install        # 安装依赖
npm run dev        # 启动开发服务器 http://localhost:5173
npm run build      # 类型检查 + 生产构建，输出到 dist/
npm run preview    # 本地预览构建结果
```

## 布局：仪表盘式应用壳

- **左侧固定侧边栏**（`src/components/layout/Sidebar.tsx`）：导航 / 游戏库两组，
  底部是「我们的社区」（社群外链，在 `nav.ts` 里改地址）与用户区。桌面端可折叠为 72px 图标栏（状态记在 localStorage），
  折叠后悬停显示提示；移动端变为抽屉。
- **顶栏**（`Topbar.tsx`）：搜索、玩本地 ROM、G 币余额、通知、登录；页脚链接里也有「玩本地 ROM」入口；移动端有菜单按钮和可展开的搜索行。
- **沉浸模式**：游戏详情页点「沉浸模式」会隐藏侧边栏和顶栏，只保留游戏画面，`Esc` 或右上角按钮退出；
  切换路由自动退出。状态由 `ShellContext.tsx` 统一管理（`useShell()`）。
- **首页**：顶部 KPI 行（在线玩家 / 今日游玩 / 游戏总数 / 正在直播，带迷你趋势线），
  横幅 + 每日任务小组件，其余区块保持紧凑排列。KPI 的模拟数据在 `services/games.ts` 的
  `getDashboardMetrics()`，接入后端时替换即可。

## 页面一览

| 路由 | 说明 |
| --- | --- |
| `/` | 首页：KPI 统计行、横幅 + 每日任务、直播、最多人玩、按平台、最新上线、一起玩、赢取 G 币、评分最高、按类型探索、精选轮播、工具与扩展、FAQ |
| `/games` | 游戏库：平台 / 类型 / 特性筛选、搜索、排序、分页（所有条件都保存在 URL 参数中） |
| `/games/:slug` | 游戏详情：模拟器播放器、简介、操作说明、相关推荐 |
| `/play-local` | 玩本地 ROM：选择平台 → 拖入文件 → 直接运行 |
| `/platforms` `/genres` `/developers` | 按平台 / 类型 / 开发商浏览 |
| `/blog` `/login` `/apps` … | 占位页（Coming Soon），后续可替换为真实功能 |

## 目录结构

```
src/
├── data/            模拟数据：platforms / genres / games / streams / faq
├── services/        数据访问层（games.ts）。接入后端时只改这里，页面无需变动
├── lib/             工具：emulator.ts（EmulatorJS 集成）、format.ts、gradients.ts
├── components/
│   ├── layout/      Sidebar / Topbar / Layout / ShellContext / Footer / Logo / nav（导航配置）
│   ├── ui/          Button / Badge / Rating / HScroll / Accordion / Pagination / SectionHeader
│   ├── game/        GameCard / GameCardWide / GameCover / PlatformCard / StreamCard
│   ├── home/        首页各区块（StatsRow / DashboardHero / sections / FeaturedCarousel）
│   └── player/      EmulatorPlayer（ROM 选择、拖拽、全屏、状态栏）
├── pages/           路由页面
├── types.ts         类型定义
└── index.css        Tailwind 主题令牌（颜色、字体、动画）与自定义工具类
```

## EmulatorJS 集成说明

- 默认从官方 CDN（`https://cdn.emulatorjs.org/stable/data/`）加载模拟器，**需要联网**。
- 模拟器运行在一个同源的 `srcdoc` iframe 中（见 `src/lib/emulator.ts`），
  切换游戏或离开页面时直接销毁 iframe，不会残留全局变量、声音或 WebAssembly 内存。
- ROM 文件通过 `blob:` URL 交给模拟器，**只在浏览器本地读取，不会上传**。
- 平台与核心的映射在 `src/data/platforms.ts` 的 `core` 字段中：
  `nes / snes / gba / gb / n64 / psx / nds / segaMD / arcade / dos / ws`。
  `core: null` 的平台（Flash、Java）会显示「暂不支持在线运行」。
- 若需要自托管资源（内网 / 国内访问更快）：
  1. 从 [EmulatorJS Releases](https://github.com/EmulatorJS/EmulatorJS/releases) 下载发行包；
  2. 把其中的 `data/` 目录放到 `public/emulatorjs/`；
  3. 复制 `.env.example` 为 `.env`，设置 `VITE_EJS_PATH=/emulatorjs/`。

## 替换为真实数据

- 游戏数据在 `src/data/games.ts`，字段说明见 `src/types.ts` 中的 `Game` 接口。
  给某款游戏填写 `cover` 字段即可使用真实封面图，留空则使用程序生成的渐变封面。
- 所有页面都通过 `src/services/games.ts` 取数（`queryGames`、`getGame`、`getPlatforms` …）。
  接入后端时把这些函数改成 `fetch` 即可（建议同时把返回值改为 `Promise` 并在页面中配合
  `useEffect` / React Query 使用）。
- 站点名称可通过 `.env` 中的 `VITE_SITE_NAME` 修改。

## 版权提示

本项目不包含、也不分发任何受版权保护的游戏 ROM。请只运行你拥有合法备份权利的游戏，
或自制 / 开源 ROM。站内展示的游戏名称、平台、年份与开发商均为公开信息，简介为原创文案。
