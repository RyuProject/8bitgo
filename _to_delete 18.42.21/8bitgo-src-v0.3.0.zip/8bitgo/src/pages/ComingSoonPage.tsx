import { useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/Button'
import { useDocumentTitle } from '@/lib/useDocumentTitle'

const FEATURES: Record<string, { icon: string; title: string; desc: string }> = {
  '/blog': {
    icon: '📝',
    title: '博客',
    desc: '模拟器教程、复古游戏考古与站点更新日志。',
  },
  '/login': {
    icon: '👤',
    title: '登录 / 注册',
    desc: '登录后可以云端存档、收藏游戏并累积 G 币。账号系统正在接入中。',
  },
  '/apps': {
    icon: '🧩',
    title: '应用与扩展',
    desc: '体感控制器、语音控制器与 AI 视频剪辑等扩展功能，正在陆续开放。',
  },
  '/about': { icon: '🕹️', title: '关于我们', desc: '8BitGo 由一群热爱复古游戏的开发者创建，目标是让经典游戏在浏览器里重获新生。' },
  '/terms': { icon: '📄', title: '服务条款', desc: '服务条款内容整理中。' },
  '/privacy': { icon: '🔒', title: '隐私政策', desc: '隐私政策内容整理中。我们承诺：本地 ROM 只在浏览器内读取，不会上传。' },
  '/tv': { icon: '📺', title: '8BitGo TV', desc: '24 小时不间断的复古游戏直播频道。' },
}

export function ComingSoonPage() {
  const { pathname } = useLocation()
  const feature = FEATURES[pathname] ?? { icon: '🚧', title: '即将上线', desc: '该功能正在开发中。' }
  useDocumentTitle(feature.title)

  return (
    <div className="container-x flex min-h-[60vh] flex-col items-center justify-center py-20 text-center">
      <span className="grid h-20 w-20 place-items-center rounded-3xl bg-brand-soft text-4xl" aria-hidden>
        {feature.icon}
      </span>
      <span className="text-pixel mt-6 text-[11px] text-coin">COMING SOON</span>
      <h1 className="mt-3 text-3xl font-extrabold tracking-tight">{feature.title}</h1>
      <p className="mt-3 max-w-md leading-relaxed text-muted">{feature.desc}</p>
      <div className="mt-8 flex gap-3">
        <Button to="/games">先去玩游戏</Button>
        <Button to="/" variant="secondary">
          回到首页
        </Button>
      </div>
    </div>
  )
}
