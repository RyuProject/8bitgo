import { useEffect, useState } from 'react'
import { Link, useLocation, useParams } from 'react-router-dom'
import { recordRecent, toggleFavorite, useCurrentUser } from '@/services/auth'
import { useRomUrl } from '@/services/roms'
import { resolveRuntime } from '@/runtimes/registry'
import { getGame, getRelatedGames } from '@/services/games'
import { platformMap } from '@/data/platforms'
import { genreMap } from '@/data/genres'
import { defaultKeymap } from '@/lib/emulator'
import { formatCount, formatPlayers } from '@/lib/format'
import { useDocumentTitle } from '@/lib/useDocumentTitle'
import { EmulatorPlayer } from '@/components/player/EmulatorPlayer'
import { GameCover } from '@/components/game/GameCover'
import { GameCard } from '@/components/game/GameCard'
import { SectionHeader } from '@/components/ui/SectionHeader'
import { RatingLine } from '@/components/ui/Rating'
import { Badge, CoinBadge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { NotFoundPage } from './NotFoundPage'
import { useShell } from '@/components/layout/ShellContext'
import { cx } from '@/lib/format'

export function GameDetailPage() {
  const { slug = '' } = useParams<{ slug: string }>()
  const game = getGame(slug)
  const { immersive } = useShell()
  const user = useCurrentUser()
  const location = useLocation()
  const [copied, setCopied] = useState(false)
  const isFav = Boolean(user?.favorites.includes(slug))
  const rom = useRomUrl(game)

  // 记录最近浏览
  useEffect(() => {
    if (game) recordRecent(game.slug)
  }, [game])

  useEffect(() => {
    if (!copied) return
    const t = window.setTimeout(() => setCopied(false), 2000)
    return () => window.clearTimeout(t)
  }, [copied])

  useDocumentTitle(game ? `${game.titleZh ?? game.title} 在线玩` : '未找到游戏')

  if (!game) return <NotFoundPage message="没有找到这款游戏，可能已经下架或链接有误。" />

  const platform = platformMap[game.platform]
  const runtime = resolveRuntime(platform.id)
  const related = getRelatedGames(game, 8)

  return (
    <div className="container-x py-6 sm:py-8">
      {/* 面包屑 */}
      <nav className="mb-4 text-xs text-muted" aria-label="面包屑">
        <Link to="/" className="hover:text-fg">
          首页
        </Link>
        <span className="mx-1.5">/</span>
        <Link to="/games" className="hover:text-fg">
          游戏库
        </Link>
        <span className="mx-1.5">/</span>
        <Link to={`/games?platform=${platform.id}`} className="hover:text-fg">
          {platform.name}
        </Link>
        <span className="mx-1.5">/</span>
        <span className="text-fg">{game.titleZh ?? game.title}</span>
      </nav>

      <div className="grid gap-8 lg:grid-cols-12">
        {/* 主区域：沉浸模式下占满整行并按视口高度居中 */}
        <div className={immersive ? 'lg:col-span-12' : 'lg:col-span-8'}>
          <div className={cx(immersive && 'mx-auto max-w-[calc((100dvh-7rem)*16/9)]')}>
            <EmulatorPlayer
              key={game.slug}
              platform={platform}
              gameName={game.title}
              icon={game.icon}
              romUrl={rom.status === 'found' ? rom.url : undefined}
              romChecking={rom.status === 'checking'}
              backdrop={<GameCover game={game} ratio="wide" showTitle={false} showBadge={false} className="h-full w-full" />}
            />
          </div>

          {/* 标题与元信息 */}
          <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">{game.titleZh ?? game.title}</h1>
              {game.titleZh && <p className="mt-1 text-sm text-muted">{game.title}</p>}
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <Link to={`/games?platform=${platform.id}`}>
                  <Badge tone="brand" className="text-xs">
                    {platform.icon} {platform.name}
                  </Badge>
                </Link>
                {game.genres.map((id) => (
                  <Link key={id} to={`/games?genre=${id}`}>
                    <Badge className="text-xs">
                      {genreMap[id].icon} {genreMap[id].name}
                    </Badge>
                  </Link>
                ))}
                {rom.status === 'found' && <Badge tone="online" className="text-xs">☁️ 即点即玩</Badge>}
                {game.multiplayer && <Badge tone="online" className="text-xs">👥 支持联机</Badge>}
                {game.bodyControl && <Badge tone="coin" className="text-xs">🤸 体感友好</Badge>}
                <CoinBadge amount={game.coinReward} className="text-xs" />
              </div>
            </div>
            <div className="flex shrink-0 flex-col items-start gap-2 sm:items-end">
              <RatingLine rating={game.rating} count={game.ratingCount} />
              <span className="text-xs text-muted">🔥 {formatCount(game.plays)} 次游玩</span>
            </div>
          </div>

          {/* 动作按钮 */}
          <div className="mt-5 flex flex-wrap gap-2">
            {user ? (
              <Button variant={isFav ? 'primary' : 'secondary'} size="sm" onClick={() => toggleFavorite(game.slug)} aria-pressed={isFav}>
                {isFav ? '❤️ 已收藏' : '🤍 收藏'}
              </Button>
            ) : (
              <Button variant="secondary" size="sm" to={`/login?next=${encodeURIComponent(location.pathname)}`}>
                🤍 收藏
              </Button>
            )}
            <Button
              variant="secondary"
              size="sm"
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(window.location.href)
                  setCopied(true)
                } catch {
                  /* 剪贴板不可用时忽略 */
                }
              }}
            >
              {copied ? '✅ 链接已复制' : '🔗 分享'}
            </Button>
            {game.multiplayer && (
              <Button variant="secondary" size="sm" to="/games?multiplayer=1">
                👥 创建联机房间
              </Button>
            )}
            <Button variant="ghost" size="sm" to="/blog">
              🚩 反馈问题
            </Button>
          </div>

          {/* 简介 */}
          <section className="mt-8">
            <h2 className="text-lg font-bold">游戏简介</h2>
            <p className="mt-2 leading-relaxed text-muted">{game.description}</p>
            <dl className="mt-5 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
              <Meta label="发行年份" value={String(game.year)} />
              <Meta label="开发商" value={game.developer} to={`/games?developer=${encodeURIComponent(game.developer)}`} />
              <Meta label="玩家人数" value={formatPlayers(game.players)} />
              <Meta label="运行时" value={runtime ? `${runtime.name} · ${runtime.engineLabel(platform.id)}` : '暂不支持'} />
            </dl>
            {game.tags && game.tags.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-2">
                {game.tags.map((t) => (
                  <Link
                    key={t}
                    to={`/games?q=${encodeURIComponent(t)}`}
                    className="rounded-md border border-line px-2 py-1 text-xs text-muted transition hover:border-brand hover:text-fg"
                  >
                    #{t}
                  </Link>
                ))}
              </div>
            )}
          </section>

          {/* 操作说明 */}
          <section className="mt-8">
            <h2 className="text-lg font-bold">操作说明</h2>
            <p className="mt-1 text-sm text-muted">
              以下是默认键位，可在模拟器右上角的设置菜单中自定义；连接手柄后会自动识别。手机端会显示虚拟按键。
            </p>
            <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-5">
              {defaultKeymap.map((k) => (
                <div key={k.button} className="rounded-xl border border-line bg-surface px-3 py-2.5">
                  <p className="text-[11px] text-muted">{k.button}</p>
                  <p className="mt-1 font-mono text-sm font-semibold">{k.key}</p>
                </div>
              ))}
              <div className="rounded-xl border border-line bg-surface px-3 py-2.5">
                <p className="text-[11px] text-muted">快速存 / 读档</p>
                <p className="mt-1 font-mono text-sm font-semibold">菜单按钮</p>
              </div>
            </div>
          </section>
        </div>

        {/* 侧栏 */}
        <aside className={cx('space-y-8 lg:col-span-4', immersive && 'hidden')}>
          <div className="rounded-2xl border border-line bg-surface p-5">
            <div className="flex items-center gap-3">
              <span
                className="grid h-12 w-12 place-items-center rounded-xl text-2xl"
                style={{ background: `${platform.color}22`, border: `1px solid ${platform.color}55` }}
                aria-hidden
              >
                {platform.icon}
              </span>
              <div>
                <p className="font-bold">{platform.name}</p>
                <p className="text-xs text-muted">
                  {platform.manufacturer} · {platform.year}
                </p>
              </div>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-muted">{platform.description}</p>
            <Button to={`/games?platform=${platform.id}`} variant="secondary" size="sm" className="mt-4 w-full">
              浏览全部 {platform.shortName} 游戏
            </Button>
          </div>

          <div className="rounded-2xl border border-coin/30 bg-gradient-to-br from-coin/10 to-transparent p-5">
            <p className="text-pixel text-[11px] text-coin">G COIN</p>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              {game.coinReward > 0
                ? `通关本作或刷新个人最佳成绩可获得 ${game.coinReward} G 币${user ? '。' : '，登录后自动结算。'}`
                : '本作暂未开放 G 币奖励。'}
            </p>
            {user ? (
              <p className="mt-4 text-sm font-semibold text-coin">🪙 当前余额 {user.coins.toLocaleString('zh-CN')} G 币</p>
            ) : (
              <Button to={`/login?next=${encodeURIComponent(location.pathname)}`} variant="coin" size="sm" className="mt-4">
                登录领取
              </Button>
            )}
          </div>
        </aside>
      </div>

      {/* 相关游戏 */}
      {related.length > 0 && (
        <section className="mt-14">
          <SectionHeader title="你可能也喜欢" subtitle="同平台、同类型或同一开发商的作品" icon="💡" />
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-8">
            {related.map((g) => (
              <GameCard key={g.slug} game={g} />
            ))}
          </div>
        </section>
      )}
    </div>
  )
}

function Meta({ label, value, to }: { label: string; value: string; to?: string }) {
  return (
    <div className="rounded-xl border border-line bg-surface px-3 py-2.5">
      <dt className="text-[11px] text-muted">{label}</dt>
      <dd className="mt-1 truncate font-semibold">
        {to ? (
          <Link to={to} className="hover:text-brand-hover">
            {value}
          </Link>
        ) : (
          value
        )}
      </dd>
    </div>
  )
}
