import { HomeIntro } from '@/components/home/HomeIntro'
import { HomeBanner } from '@/components/home/HomeBanner'
import { FeaturedCarousel } from '@/components/home/FeaturedCarousel'
import {
  CoinSection,
  FaqSection,
  GenreGridSection,
  LatestSection,
  LiveSection,
  PlatformsSection,
  PopularSection,
  ToolsSection,
  TogetherSection,
  TopRatedSection,
} from '@/components/home/sections'
import { useDocumentTitle } from '@/lib/useDocumentTitle'

export function HomePage() {
  useDocumentTitle()
  return (
    <div className="space-y-10 py-8">
      <HomeIntro />
      <HomeBanner />
      <LiveSection />
      <PopularSection />
      <PlatformsSection />
      <LatestSection />
      <TogetherSection />
      <CoinSection />
      <TopRatedSection />
      <GenreGridSection />
      <FeaturedCarousel />
      <ToolsSection />
      <FaqSection />
    </div>
  )
}
