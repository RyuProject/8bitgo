/**
 * 游戏数据存储。
 *
 * 默认使用 src/data/games.ts 里的内置数据；在后台 (/admin) 做过修改后，
 * 完整的游戏列表会保存到 localStorage，前台与后台都从这里读取。
 * 「重置」即删除 localStorage 里的副本，恢复内置数据。
 *
 * 接入真实后端时，把 load / save 换成接口调用即可。
 */
import { useSyncExternalStore } from 'react'
import { games as builtinGames } from '@/data/games'
import type { Game } from '@/types'

export const STORAGE_KEY = '8bitgo.admin.games'

let cache: Game[] | null = null
const listeners = new Set<() => void>()

function isGame(x: unknown): x is Game {
  return (
    typeof x === 'object' &&
    x !== null &&
    typeof (x as Game).slug === 'string' &&
    typeof (x as Game).title === 'string' &&
    typeof (x as Game).platform === 'string' &&
    Array.isArray((x as Game).genres)
  )
}

function readStorage(): Game[] | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    const parsed: unknown = JSON.parse(raw)
    if (!Array.isArray(parsed) || !parsed.every(isGame)) return null
    return parsed
  } catch {
    return null
  }
}

/** 当前完整列表（含已下架的游戏） */
export function loadGames(): Game[] {
  if (!cache) cache = readStorage() ?? builtinGames
  return cache
}

/** 是否存在后台修改过的副本 */
export function hasLocalChanges(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEY) !== null
  } catch {
    return false
  }
}

function notify() {
  for (const l of listeners) l()
}

export function saveGames(list: Game[]) {
  cache = list
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list))
  } catch (err) {
    console.warn('保存到 localStorage 失败', err)
  }
  notify()
}

export function resetGames() {
  cache = builtinGames
  try {
    localStorage.removeItem(STORAGE_KEY)
  } catch {
    /* ignore */
  }
  notify()
}

export function upsertGame(game: Game) {
  const list = loadGames()
  const idx = list.findIndex((g) => g.slug === game.slug)
  const next = idx >= 0 ? list.map((g, i) => (i === idx ? game : g)) : [game, ...list]
  saveGames(next)
}

export function deleteGame(slug: string) {
  saveGames(loadGames().filter((g) => g.slug !== slug))
}

export function setGameHidden(slug: string, hidden: boolean) {
  saveGames(loadGames().map((g) => (g.slug === slug ? { ...g, hidden } : g)))
}

export function subscribe(listener: () => void) {
  listeners.add(listener)
  return () => {
    listeners.delete(listener)
  }
}

/** React 组件里订阅完整列表，后台改动后自动重渲染 */
export function useAllGames(): Game[] {
  return useSyncExternalStore(subscribe, loadGames, loadGames)
}

/** 导出为 JSON 字符串 */
export function exportGamesJson(): string {
  return JSON.stringify(loadGames(), null, 2)
}

/** 从 JSON 导入，返回导入的数量；格式不对会抛错 */
export function importGamesJson(json: string): number {
  const parsed: unknown = JSON.parse(json)
  if (!Array.isArray(parsed) || !parsed.every(isGame)) {
    throw new Error('JSON 格式不正确：需要一个游戏对象数组（至少包含 slug / title / platform / genres）')
  }
  saveGames(parsed)
  return parsed.length
}
