import { useRef, useState } from 'react'
import { STORAGE_KEY, exportGamesJson, hasLocalChanges, importGamesJson, resetGames, useAllGames } from '@/services/store'
import { Card, btnClass, inputClass } from './ui'
import { cx } from '@/lib/format'

export function AdminData() {
  const all = useAllGames()
  const [text, setText] = useState('')
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const local = hasLocalChanges()

  const download = () => {
    const blob = new Blob([exportGamesJson()], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `8bitgo-games-${new Date().toISOString().slice(0, 10)}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(exportGamesJson())
      setMsg({ ok: true, text: '已复制到剪贴板' })
    } catch {
      setMsg({ ok: false, text: '复制失败，请使用下载' })
    }
  }

  const doImport = (json: string) => {
    try {
      const n = importGamesJson(json)
      setMsg({ ok: true, text: `导入成功：${n} 款游戏` })
      setText('')
    } catch (err) {
      setMsg({ ok: false, text: err instanceof Error ? err.message : '导入失败' })
    }
  }

  const onFile = async (file?: File) => {
    if (!file) return
    doImport(await file.text())
    if (fileRef.current) fileRef.current.value = ''
  }

  const reset = () => {
    if (!window.confirm('确定重置？后台所做的全部修改将被清除，恢复为代码里的内置数据。')) return
    resetGames()
    setMsg({ ok: true, text: '已恢复为内置数据' })
  }

  let bytes = 0
  try {
    bytes = new Blob([localStorage.getItem(STORAGE_KEY) ?? '']).size
  } catch {
    /* ignore */
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold">数据</h1>
        <p className="mt-1 text-sm text-muted">
          后台的修改保存在当前浏览器的 localStorage（键：<code className="text-fg">{STORAGE_KEY}</code>），换浏览器或清除站点数据后会丢失。
          想长期保存请导出 JSON，替换到 <code className="text-fg">src/data/games.ts</code>。
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="当前状态">
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-muted">数据来源</dt>
              <dd className={cx('font-medium', local ? 'text-coin' : 'text-fg')}>{local ? '本地修改版' : '内置数据（src/data/games.ts）'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted">游戏数量</dt>
              <dd>
                {all.length} 款（{all.filter((g) => g.hidden).length} 款已下架）
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted">占用空间</dt>
              <dd>{local ? `${(bytes / 1024).toFixed(1)} KB` : '—'}</dd>
            </div>
          </dl>
          <div className="mt-4 flex flex-wrap gap-2">
            <button type="button" className={btnClass.primary} onClick={download}>
              ⬇ 下载 JSON
            </button>
            <button type="button" className={btnClass.secondary} onClick={copy}>
              复制 JSON
            </button>
            <button type="button" className={btnClass.danger} onClick={reset} disabled={!local}>
              重置为内置数据
            </button>
          </div>
        </Card>

        <Card title="导入 JSON">
          <p className="mb-2 text-xs text-muted">粘贴一个游戏数组（与导出格式一致），或选择 .json 文件。导入会整体替换当前列表。</p>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder='[{"slug":"...","title":"...","platform":"nes","genres":["action"], ...}]'
            className={cx(inputClass, 'h-40 resize-y py-2 font-mono text-xs')}
          />
          <div className="mt-3 flex flex-wrap gap-2">
            <button type="button" className={btnClass.primary} disabled={!text.trim()} onClick={() => doImport(text)}>
              导入粘贴内容
            </button>
            <button type="button" className={btnClass.secondary} onClick={() => fileRef.current?.click()}>
              选择 .json 文件
            </button>
            <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
          </div>
        </Card>
      </div>

      {msg && (
        <p role="status" className={cx('rounded-lg px-3 py-2 text-sm', msg.ok ? 'bg-online/15 text-online' : 'bg-live/15 text-red-300')}>
          {msg.text}
        </p>
      )}
    </div>
  )
}
