import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { Layout } from '@/components/layout/Layout'
import { HomePage } from '@/pages/HomePage'
import { GamesPage } from '@/pages/GamesPage'
import { GameDetailPage } from '@/pages/GameDetailPage'
import { PlayLocalPage } from '@/pages/PlayLocalPage'
import { DevelopersPage, GenresPage, PlatformsPage } from '@/pages/BrowsePages'
import { ComingSoonPage } from '@/pages/ComingSoonPage'
import { NotFoundPage } from '@/pages/NotFoundPage'
import { AdminLayout } from '@/admin/AdminLayout'
import { AdminOverview } from '@/admin/AdminOverview'
import { AdminGames } from '@/admin/AdminGames'
import { AdminData } from '@/admin/AdminData'

const COMING_SOON_ROUTES = [
  '/blog',
  '/login',
  '/apps',
  '/about',
  '/terms',
  '/privacy',
  '/tv',
]

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="/games" element={<GamesPage />} />
          <Route path="/games/:slug" element={<GameDetailPage />} />
          <Route path="/platforms" element={<PlatformsPage />} />
          <Route path="/genres" element={<GenresPage />} />
          <Route path="/developers" element={<DevelopersPage />} />
          <Route path="/play-local" element={<PlayLocalPage />} />
          {COMING_SOON_ROUTES.map((path) => (
            <Route key={path} path={path} element={<ComingSoonPage />} />
          ))}
          <Route path="*" element={<NotFoundPage />} />
        </Route>

        {/* 后台：独立外壳，不带前台侧边栏 */}
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<AdminOverview />} />
          <Route path="games" element={<AdminGames />} />
          <Route path="data" element={<AdminData />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
