import { Link } from 'react-router-dom'
import { getGenres } from '@/services/games'

/** 首页顶部：标题 + 一句话说明 + 类型快捷入口 */
export function HomeIntro() {
  const genres = getGenres().filter((g) => g.count > 0)

  return (
    <section className="container-x">
      <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">免费在线玩模拟器游戏</h1>
      <p className="mt-3 max-w-3xl text-base leading-relaxed text-muted">
        直接在浏览器中畅玩来自 GBA、NES、SNES、PS1、N64、世嘉 Genesis、街机等平台的经典复古游戏。无需下载。
      </p>

      <nav className="mt-5 flex flex-wrap gap-2" aria-label="按类型浏览">
        {genres.map((g) => (
          <Link
            key={g.id}
            to={`/games?genre=${g.id}`}
            className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-line bg-surface px-3 text-sm font-medium text-fg transition hover:border-brand/60 hover:bg-brand-soft"
          >
            <span aria-hidden>{g.icon}</span>
            {g.name}
          </Link>
        ))}
      </nav>
    </section>
  )
}
