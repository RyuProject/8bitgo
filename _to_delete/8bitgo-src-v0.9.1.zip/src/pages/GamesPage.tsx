import { useMemo, type ReactNode } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import type { GenreId, PlatformId, SortKey } from '@/types'
import { getGenre, getGenres, getPlatform, getPlatforms, queryGames } from '@/services/games'
import { cx } from '@/lib/format'
import { useDocumentTitle } from '@/lib/useDocumentTitle'
import { GameCard } from '@/components/game/GameCard'
import { Pagination } from '@/components/ui/Pagination'
import { Button } from '@/components/ui/Button'
import { FEATURES } from '@/config/features'

const SORTS: Array<{ key: SortKey; label: string }> = [
  { key: 'popular', label: '最热门' },
  { key: 'newest', label: '最新上线' },
  { key: 'rating', label: '评分最高' },
  { key: 'name', label: '名称 A-Z' },
]

/**
 * 游戏库页面。所有筛选条件都保存在 URL 查询参数里，方便分享与前进后退：
 *   /games?platform=gba&genre=rpg&q=zelda&sort=rating&multiplayer=1&coin=1&page=2
 */
export function GamesPage() {
  const [params, setParams] = useSearchParams()

  const q = params.get('q') ?? ''
  const platformId = (params.get('platform') as PlatformId | null) ?? undefined
  const genreId = (params.get('genre') as GenreId | null) ?? undefined
  const developer = params.get('developer') ?? undefined
  const multiplayer = params.get('multiplayer') === '1'
  const coin = params.get('coin') === '1'
  const sortParam = params.get('sort') as SortKey | null
  const sort: SortKey = sortParam && SORTS.some((s) => s.key === sortParam) ? sortParam : 'popular'
  const page = Math.max(1, Number(params.get('page') ?? 1) || 1)

  const platform = platformId ? getPlatform(platformId) : undefined
  const genre = genreId ? getGenre(genreId) : undefined

  const result = useMemo(
    () =>
      queryGames({
        q,
        platform: platform?.id,
        genre: genre?.id,
        developer,
        multiplayer,
        coin,
        sort: sortParam ?? undefined,
        page,
      }),
    [q, platform?.id, genre?.id, developer, multiplayer, coin, sortParam, page],
  )

  const title = q
    ? `搜索「${q}」`
    : developer
      ? `${developer} 的游戏`
      : platform && genre
        ? `${platform.name} ${genre.name}游戏`
        : platform
          ? `${platform.name} 游戏`
          : genre
            ? `${genre.name}游戏`
            : multiplayer
              ? '联机 / 双人游戏'
              : coin
                ? '可赢取 G 币的游戏'
                : '全部游戏'

  useDocumentTitle(title)

  const set = (key: string, value: string | null) => {
    const next = new URLSearchParams(params)
    if (value === null || value === '') next.delete(key)
    else next.set(key, value)
    if (key !== 'page') next.delete('page')
    setParams(next)
  }

  const hasFilters = Boolean(q || platformId || genreId || developer || multiplayer || coin)

  return (
    <div className="container-x py-8 sm:py-10">
      {/* 标题 */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <nav className="text-xs text-muted" aria-label="面包屑">
            <Link to="/" className="hover:text-fg">
              首页
            </Link>
            <span className="mx-1.5">/</span>
            <span className="text-fg">游戏库</span>
          </nav>
          <h1 className="mt-2 flex items-center gap-2 text-2xl font-extrabold tracking-tight sm:text-3xl">
            {platform && <span aria-hidden>{platform.icon}</span>}
            {title}
          </h1>
          <p className="mt-1 text-sm text-muted">
            {platform?.description ?? genre?.description ?? `共 ${result.total} 款游戏`}
          </p>
        </div>
        <label className="flex items-center gap-2 text-sm text-muted">
          排序
          <select
            value={sort}
            onChange={(e) => set('sort', e.target.value)}
            className="h-9 rounded-lg border border-line bg-surface px-3 text-sm text-fg focus:border-brand focus:outline-none"
          >
            {SORTS.map((s) => (
              <option key={s.key} value={s.key}>
                {s.label}
              </option>
            ))}
          </select>
        </label>
      </div>

      {/* 筛选 */}
      <div className="mt-6 space-y-3">
        <FilterRow label="平台">
          <FilterChip active={!platformId} onClick={() => set('platform', null)}>
            全部
          </FilterChip>
          {getPlatforms().map((p) => (
            <FilterChip
              key={p.id}
              active={platformId === p.id}
              onClick={() => set('platform', platformId === p.id ? null : p.id)}
              color={p.color}
            >
              {p.icon} {p.shortName}
              <span className="ml-1 opacity-60">{p.count}</span>
            </FilterChip>
          ))}
        </FilterRow>
        <FilterRow label="类型">
          <FilterChip active={!genreId} onClick={() => set('genre', null)}>
            全部
          </FilterChip>
          {getGenres().map((g) => (
            <FilterChip
              key={g.id}
              active={genreId === g.id}
              onClick={() => set('genre', genreId === g.id ? null : g.id)}
            >
              {g.icon} {g.name}
              <span className="ml-1 opacity-60">{g.count}</span>
            </FilterChip>
          ))}
        </FilterRow>
        <FilterRow label="特性">
          <FilterChip active={multiplayer} onClick={() => set('multiplayer', multiplayer ? null : '1')}>
            👥 联机 / 双人
          </FilterChip>
          {FEATURES.coins && (
            <FilterChip active={coin} onClick={() => set('coin', coin ? null : '1')}>
              🪙 赢取 G 币
            </FilterChip>
          )}
          {developer && (
            <FilterChip active onClick={() => set('developer', null)}>
              🏢 {developer} ✕
            </FilterChip>
          )}
          {q && (
            <FilterChip active onClick={() => set('q', null)}>
              🔍 {q} ✕
            </FilterChip>
          )}
          {hasFilters && (
            <button
              type="button"
              onClick={() => setParams(new URLSearchParams())}
              className="ml-1 text-xs text-muted underline-offset-2 hover:text-fg hover:underline"
            >
              清除全部
            </button>
          )}
        </FilterRow>
      </div>

      {/* 结果 */}
      <p className="mt-6 text-sm text-muted">
        共 <span className="font-semibold text-fg">{result.total}</span> 款游戏
        {result.totalPages > 1 && (
          <>
            ，第 {result.page} / {result.totalPages} 页
          </>
        )}
      </p>

      {result.items.length > 0 ? (
        <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {result.items.map((g) => (
            <GameCard key={g.slug} game={g} />
          ))}
        </div>
      ) : (
        <div className="mt-6 rounded-2xl border border-dashed border-line py-16 text-center">
          <p className="text-4xl" aria-hidden>
            👾
          </p>
          <p className="mt-3 font-semibold">没有找到符合条件的游戏</p>
          <p className="mt-1 text-sm text-muted">试试更换关键字或清除筛选条件</p>
          <Button variant="secondary" size="sm" className="mt-4" onClick={() => setParams(new URLSearchParams())}>
            清除筛选
          </Button>
        </div>
      )}

      <div className="mt-10">
        <Pagination page={result.page} totalPages={result.totalPages} onChange={(p) => set('page', String(p))} />
      </div>
    </div>
  )
}

function FilterRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-start gap-3">
      <span className="w-10 shrink-0 pt-1.5 text-xs font-semibold text-muted">{label}</span>
      <div className="flex flex-wrap gap-2">{children}</div>
    </div>
  )
}

function FilterChip({
  active,
  onClick,
  children,
  color,
}: {
  active: boolean
  onClick: () => void
  children: ReactNode
  color?: string
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cx(
        'inline-flex h-8 items-center rounded-lg border px-2.5 text-xs font-medium transition',
        active
          ? 'border-brand bg-brand text-white shadow-[0_6px_18px_-8px_rgba(139,92,246,0.9)]'
          : 'border-line bg-surface text-muted hover:border-line-strong hover:text-fg',
      )}
      style={active && color ? { background: color, borderColor: color } : undefined}
    >
      {children}
    </button>
  )
}
