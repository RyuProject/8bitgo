import { Link } from 'react-router-dom'
import { cx } from '@/lib/format'

export const SITE_NAME = import.meta.env.VITE_SITE_NAME ?? '8BitGo'

/**
 * 品牌字标：像素点阵还原，用 <path> 直接画方块，任意尺寸都不会糊。
 * viewBox 就是像素格数（77 x 20），高度给多少就渲染多大。
 */
export function LogoWordmark({ className, title }: { className?: string; title?: string }) {
  return (
    <svg viewBox="0 0 77 20" className={className} shapeRendering="crispEdges" role="img" aria-label={title ?? SITE_NAME}>
      <path fill="#141230" d="M2 0h10v1h-10z M15 0h11v1h-11z M29 0h6v1h-6z M36 0h13v1h-13z M52 0h9v1h-9z M65 0h10v1h-10z M11 1h1v1h-1z M15 1h1v19h-1z M29 1h1v19h-1z M34 1h1v19h-1z M36 1h1v7h-1z M47 1h2v7h-2z M51 1h1v2h-1z M60 1h1v2h-1z M65 1h1v2h-1z M74 1h1v2h-1z M0 2h2v1h-2z M12 2h2v1h-2z M26 2h2v1h-2z M50 2h1v17h-1z M61 2h2v1h-2z M64 2h1v17h-1z M75 2h1v17h-1z M0 3h1v16h-1z M13 3h1v16h-1z M27 3h1v16h-1z M62 3h1v16h-1z M76 3h1v16h-1z M6 6h2v1h-2z M20 6h2v1h-2z M37 7h3v1h-3z M44 7h3v1h-3z M55 7h3v1h-3z M69 7h2v6h-2z M1 8h1v1h-1z M12 8h1v1h-1z M26 8h1v1h-1z M39 8h1v12h-1z M44 8h1v12h-1z M55 8h1v5h-1z M5 12h4v1h-4z M20 12h3v1h-3z M56 12h2v1h-2z M1 17h1v3h-1z M12 17h1v3h-1z M26 17h1v3h-1z M51 17h1v3h-1z M60 17h2v3h-2z M65 17h1v3h-1z M74 17h1v3h-1z M11 18h1v2h-1z M2 19h9v1h-9z M16 19h10v1h-10z M30 19h4v1h-4z M40 19h4v1h-4z M52 19h8v1h-8z M66 19h8v1h-8z" />
      <path fill="#FDDC42" d="M2 1h9v4h-9z M16 1h10v4h-10z M30 1h4v15h-4z M37 1h10v4h-10z M52 1h8v4h-8z M66 1h8v4h-8z M11 2h1v14h-1z M1 3h1v5h-1z M12 3h1v5h-1z M26 3h1v5h-1z M51 3h1v12h-1z M60 3h2v4h-2z M65 3h1v12h-1z M74 3h1v12h-1z M2 5h3v11h-3z M9 5h2v11h-2z M16 5h4v11h-4z M23 5h3v11h-3z M40 5h4v11h-4z M52 5h3v11h-3z M58 5h2v2h-2z M66 5h3v11h-3z M71 5h3v11h-3z M5 7h4v4h-4z M20 7h3v4h-3z M56 8h6v3h-6z M1 9h1v6h-1z M12 9h1v6h-1z M26 9h1v6h-1z M58 11h4v4h-4z M5 13h4v3h-4z M20 13h3v3h-3z M55 13h3v3h-3z M69 13h2v3h-2z M58 15h2v1h-2z" />
      <path fill="#E62F25" d="M5 5h4v1h-4z M20 5h3v1h-3z M37 5h3v2h-3z M44 5h3v2h-3z M55 5h3v2h-3z M69 5h2v2h-2z M5 6h1v1h-1z M8 6h1v1h-1z M22 6h1v1h-1z M58 7h4v1h-4z M5 11h4v1h-4z M20 11h3v1h-3z M56 11h2v1h-2z M1 15h1v2h-1z M12 15h1v2h-1z M26 15h1v2h-1z M51 15h1v2h-1z M60 15h2v2h-2z M65 15h1v2h-1z M74 15h1v2h-1z M2 16h10v2h-10z M16 16h10v3h-10z M30 16h4v3h-4z M40 16h4v3h-4z M52 16h8v3h-8z M66 16h8v3h-8z M2 18h9v1h-9z" />
    </svg>
  )
}

/** 收起态 / favicon 用的单字符标（字标里的「8」） */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 14 20" className={className} shapeRendering="crispEdges" aria-hidden>
      <path fill="#141230" d="M2 0h10v1h-10z M11 1h1v1h-1z M0 2h2v1h-2z M12 2h2v1h-2z M0 3h1v16h-1z M13 3h1v16h-1z M6 6h2v1h-2z M1 8h1v1h-1z M12 8h1v1h-1z M5 12h4v1h-4z M1 17h1v3h-1z M12 17h1v3h-1z M11 18h1v2h-1z M2 19h9v1h-9z" />
      <path fill="#FDDC42" d="M2 1h9v4h-9z M11 2h1v14h-1z M1 3h1v5h-1z M12 3h1v5h-1z M2 5h3v11h-3z M9 5h2v11h-2z M5 7h4v4h-4z M1 9h1v6h-1z M12 9h1v6h-1z M5 13h4v3h-4z" />
      <path fill="#E62F25" d="M5 5h4v1h-4z M5 6h1v1h-1z M8 6h1v1h-1z M5 11h4v1h-4z M1 15h1v2h-1z M12 15h1v2h-1z M2 16h10v2h-10z M2 18h9v1h-9z" />
    </svg>
  )
}

export function Logo({ className, compact }: { className?: string; compact?: boolean }) {
  return (
    <Link
      to="/"
      className={cx('group inline-flex items-center transition hover:brightness-110', className)}
      aria-label={`${SITE_NAME} 首页`}
    >
      <LogoWordmark className={cx('h-6 w-auto', compact && 'lg:hidden')} title={SITE_NAME} />
      {compact && <LogoMark className="hidden h-7 w-auto lg:block" />}
    </Link>
  )
}
