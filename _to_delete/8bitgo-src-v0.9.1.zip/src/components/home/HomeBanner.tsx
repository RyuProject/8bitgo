import {
  useCallback,
  useId,
  useMemo,
  useRef,
  useState,
  type AnimationEvent,
  type CSSProperties,
  type KeyboardEvent,
} from "react";
import type { Game } from "@/types";
import { platformMap } from "@/data/platforms";
import { featured } from "@/data/featured";
import { getGamesBySlugs } from "@/services/games";
import { gradientFor } from "@/lib/gradients";
import { cx, formatCount } from "@/lib/format";
import { Button } from "@/components/ui/Button";
import { GameCover } from "@/components/game/GameCover";

interface Slide {
  game: Game;
  tagline: string;
}

/**
 * 首页 banner 位（参考 Epic 商城首页）：
 * 左边是幻灯片，右边是精选列表；点右边的游戏，左边就切到它。
 *
 * 自动轮播由右侧当前项的「进度填充」动画驱动：动画播完（animationend）就切下一张。
 * 鼠标悬停 / 键盘聚焦（focus-visible）时动画暂停，轮播也随之暂停，两者天然同步，不需要另外计时。
 * 轮播间隔在 index.css 的 --animate-hero-progress 里改。
 */
export function HomeBanner() {
  const slides = useMemo<Slide[]>(() => {
    const games = getGamesBySlugs(featured.map((f) => f.slug));
    return games.map((game) => ({
      game,
      tagline: featured.find((f) => f.slug === game.slug)?.tagline ?? "",
    }));
  }, []);

  const [index, setIndex] = useState(0);
  const tabRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const baseId = useId();
  const panelId = `${baseId}-panel`;
  const tabId = (i: number) => `${baseId}-tab-${i}`;

  const count = slides.length;
  const select = useCallback(
    (i: number) => setIndex(((i % count) + count) % count),
    [count],
  );

  const onProgressEnd = (e: AnimationEvent<HTMLSpanElement>) => {
    if (e.animationName === "hero-progress" && count > 1) select(index + 1);
  };

  const onKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    let target: number | null = null;
    if (e.key === "ArrowDown" || e.key === "ArrowRight") target = index + 1;
    else if (e.key === "ArrowUp" || e.key === "ArrowLeft") target = index - 1;
    else if (e.key === "Home") target = 0;
    else if (e.key === "End") target = count - 1;
    if (target === null) return;
    e.preventDefault();
    const next = ((target % count) + count) % count;
    select(next);
    tabRefs.current[next]?.focus();
  };

  if (count === 0) return null;

  return (
    <section
      className="container-x group/hero @container/hero"
      aria-roledescription="轮播"
      aria-label="精选游戏"
    >
      <div className="grid gap-3 @min-[860px]/hero:grid-cols-[minmax(0,1fr)_260px] @min-[860px]/hero:grid-rows-[320px] @min-[1040px]/hero:grid-cols-[minmax(0,1fr)_300px]">
        {/* 幻灯片 */}
        <div
          id={panelId}
          role="tabpanel"
          aria-labelledby={tabId(index)}
          className="@container relative min-h-[300px] overflow-hidden border-2 border-line-strong bg-surface @min-[860px]/hero:min-h-0"
        >
          {slides.map((s, i) => (
            <SlideView key={s.game.slug} slide={s} active={i === index} />
          ))}
        </div>

        {/* 右侧精选列表：xl 及以上竖排（缩略图 + 标题），更窄的屏幕变成一排 */}
        <div
          role="tablist"
          aria-orientation="vertical"
          aria-label="选择要展示的游戏"
          onKeyDown={onKeyDown}
          style={{ "--n": count } as CSSProperties}
          className="grid min-h-0 gap-1.5 border-2 border-line-strong bg-surface p-1.5 [grid-template-columns:repeat(var(--n),minmax(0,1fr))] @min-[860px]/hero:grid-cols-1 @min-[860px]/hero:[grid-template-rows:repeat(var(--n),minmax(0,1fr))]"
        >
          {slides.map((s, i) => {
            const active = i === index;
            const title = s.game.titleZh ?? s.game.title;
            return (
              <button
                key={s.game.slug}
                ref={(el) => {
                  tabRefs.current[i] = el;
                }}
                type="button"
                role="tab"
                id={tabId(i)}
                aria-selected={active}
                aria-controls={panelId}
                tabIndex={active ? 0 : -1}
                onClick={() => select(i)}
                title={title}
                className={cx(
                  "relative flex min-h-0 min-w-0 items-center justify-center gap-3 overflow-hidden px-2 py-1.5 text-left transition-colors @min-[860px]/hero:justify-start @min-[860px]/hero:px-3",
                  active ? "bg-white/10" : "bg-white/[0.04] hover:bg-white/10",
                )}
              >
                {active && count > 1 && (
                  <span
                    aria-hidden
                    onAnimationEnd={onProgressEnd}
                    className="animate-hero-progress pointer-events-none absolute inset-0 origin-left bg-white/10 group-hover/hero:[animation-play-state:paused] group-has-[:focus-visible]/hero:[animation-play-state:paused] motion-reduce:animate-none"
                  />
                )}
                <GameCover
                  game={s.game}
                  ratio="square"
                  showTitle={false}
                  showBadge={false}
                  iconSize="xs"
                  className={cx(
                    "relative h-10 w-10 shrink-0 border-2 sm:h-11 sm:w-11",
                    active ? "border-white/70" : "border-black/40",
                  )}
                />
                <span className="relative hidden min-w-0 flex-1 @md/hero:block">
                  <span
                    className={cx(
                      "line-clamp-2 text-sm font-semibold leading-snug",
                      active ? "text-white" : "text-muted",
                    )}
                  >
                    《{title}》
                  </span>
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function SlideView({ slide, active }: { slide: Slide; active: boolean }) {
  const { game, tagline } = slide;
  const platform = platformMap[game.platform];

  return (
    <article
      inert={!active}
      aria-hidden={!active}
      className={cx(
        "absolute inset-0 transition-opacity duration-500",
        active ? "opacity-100" : "pointer-events-none opacity-0",
      )}
      style={{ background: gradientFor(game.slug) }}
    >
      <div className="pixel-grid absolute inset-0 opacity-50" aria-hidden />
      <div
        className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/65 to-black/20"
        aria-hidden
      />

      <div className="relative flex h-full">
        {/* 左侧文案 */}
        <div
          className={cx(
            "flex min-w-0 flex-1 flex-col justify-center p-6 transition duration-500 sm:p-8",
            active ? "translate-y-0 opacity-100" : "translate-y-3 opacity-0",
          )}
        >
          <div className="max-w-xl">
            <p className="text-pixel text-[11px] font-semibold text-coin">
              {tagline}
            </p>
            <h2 className="mt-2 text-2xl font-extrabold leading-tight tracking-tight text-white sm:text-3xl">
              {game.titleZh ?? game.title}
            </h2>
            <p className="mt-1 truncate text-xs text-white/70">
              {game.title} · {platform.name} · {game.year} · {game.developer}
            </p>
            <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-white/85">
              {game.description}
            </p>
            <p className="mt-4 text-sm font-semibold text-white">
              免费{" "}
              <span className="font-normal text-white/60">
                · 无需下载 · 🔥 {formatCount(game.plays)} 次游玩
              </span>
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button to={`/games/${game.slug}`}>
                <span aria-hidden>▶</span> 立即游玩
              </Button>
              <Button to={`/games?platform=${platform.id}`} variant="secondary">
                更多 {platform.shortName} 游戏
              </Button>
            </div>
          </div>
        </div>

        {/* 右侧主视觉：大封面卡（幻灯片本身宽度 ≥ 560px 才显示） */}
        <div
          className="hidden w-2/5 shrink-0 items-center justify-center @min-[560px]:flex"
          aria-hidden
        >
          <div
            className={cx(
              "w-36 rotate-3 border-2 border-black/70 shadow-[6px_6px_0_0_rgba(0,0,0,0.55)] transition duration-700 @min-[720px]:w-40",
              active ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0",
            )}
          >
            <GameCover game={game} showTitle={false} iconSize="lg" />
          </div>
        </div>
      </div>
    </article>
  );
}
