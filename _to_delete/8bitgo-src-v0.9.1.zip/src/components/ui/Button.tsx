import type { ButtonHTMLAttributes, ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { cx } from '@/lib/format'

type Variant = 'primary' | 'secondary' | 'ghost' | 'coin' | 'danger'
type Size = 'sm' | 'md' | 'lg'

/* 8Bit 按钮：直角 + 右下硬阴影，按下时整体位移、阴影消失，像老游戏机的实体键 */
const base =
  'inline-flex items-center justify-center gap-2 font-semibold whitespace-nowrap select-none transition-[transform,box-shadow,background-color,color] duration-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-hover disabled:opacity-50 disabled:pointer-events-none'

const pressable = 'shadow-[3px_3px_0_0_rgba(0,0,0,0.7)] active:translate-x-[3px] active:translate-y-[3px] active:shadow-none'

const variants: Record<Variant, string> = {
  primary: `bg-brand text-white hover:bg-brand-hover ${pressable}`,
  secondary: `bg-surface-2 text-fg border-2 border-line-strong hover:bg-surface-3 hover:border-white/30 ${pressable}`,
  ghost: 'text-muted hover:bg-white/10 hover:text-fg',
  coin: `bg-coin text-black hover:brightness-110 ${pressable}`,
  danger: `bg-live text-white hover:brightness-110 ${pressable}`,
}

const sizes: Record<Size, string> = {
  sm: 'h-8 px-3 text-xs',
  md: 'h-10 px-4 text-sm',
  lg: 'h-12 px-6 text-base',
}

interface CommonProps {
  variant?: Variant
  size?: Size
  className?: string
  children: ReactNode
}

type ButtonProps = CommonProps & ButtonHTMLAttributes<HTMLButtonElement> & { to?: undefined }
type LinkProps = CommonProps & { to: string; target?: string; rel?: string; onClick?: () => void }

export function buttonClasses(variant: Variant = 'primary', size: Size = 'md', className?: string) {
  return cx(base, variants[variant], sizes[size], className)
}

export function Button(props: ButtonProps | LinkProps) {
  if (typeof props.to === 'string') {
    const { variant, size, className, children, to, target, rel, onClick } = props
    return (
      <Link to={to} target={target} rel={rel} onClick={onClick} className={buttonClasses(variant, size, className)}>
        {children}
      </Link>
    )
  }

  const { variant, size, className, children, ...rest } = props as ButtonProps
  return (
    <button type="button" className={buttonClasses(variant, size, className)} {...rest}>
      {children}
    </button>
  )
}
