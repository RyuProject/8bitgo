import type { Game } from '@/types'
import { platformMap } from '@/data/platforms'
import { gradientFor } from '@/lib/gradients'
import { cx } from '@/lib/format'

interface Props {
  game: Game
  /** 宽高比：竖版 3/4，横版 16/9，方形 1/1 */
  ratio?: 'portrait' | 'wide' | 'square'
  className?: string
  /** 是否显示标题（用于没有真实封面的程序化封面） */
  showTitle?: boolean
  iconSize?: 'sm' | 'md' | 'lg'
  /** 是否显示左上角平台角标 */
  showBadge?: boolean
  /** 右下角有其他角标时，为标题预留空间 */
  reserveBottomRight?: boolean
}

const ratios = {
  portrait: 'aspect-[3/4]',
  wide: 'aspect-video',
  square: 'aspect-square',
}

const iconSizes = {
  sm: 'text-4xl',
  md: 'text-5xl sm:text-6xl',
  lg: 'text-7xl sm:text-8xl',
}

/**
 * 游戏封面。若 game.cover 有真实图片则直接展示；
 * 否则用稳定的渐变 + emoji + 像素网格生成一张程序化封面。
 */
export function GameCover({
  game,
  ratio = 'portrait',
  className,
  showTitle = true,
  iconSize = 'md',
  showBadge = true,
  reserveBottomRight = false,
}: Props) {
  const platform = platformMap[game.platform]

  if (game.cover) {
    return (
      <div className={cx('relative overflow-hidden bg-surface-2', ratios[ratio], className)}>
        <img
          src={game.cover}
          alt={game.title}
          loading="lazy"
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
      </div>
    )
  }

  return (
    <div
      className={cx('relative overflow-hidden', ratios[ratio], className)}
      style={{ background: gradientFor(game.slug) }}
      role="img"
      aria-label={`${game.title} 封面`}
    >
      <div className="pixel-grid absolute inset-0 opacity-70" aria-hidden />
      <div
        className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.35),transparent_55%)]"
        aria-hidden
      />
      <div
        className={cx(
          'absolute inset-0 flex items-center justify-center drop-shadow-[0_6px_12px_rgba(0,0,0,0.45)] transition duration-500 group-hover:scale-110',
          iconSizes[iconSize],
          showTitle && ratio === 'portrait' && '-translate-y-3',
        )}
        aria-hidden
      >
        {game.icon}
      </div>
      {showTitle && (
        <div
          className={cx(
            'absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/50 to-transparent px-3 pb-2.5 pt-8',
            reserveBottomRight && 'pr-14',
          )}
        >
          <p className="line-clamp-2 text-[13px] font-bold leading-tight text-white drop-shadow">
            {game.title}
          </p>
        </div>
      )}
      {showBadge && (
        <span
          className="text-pixel absolute left-2 top-2 rounded bg-black/55 px-1.5 py-1 text-[10px] text-white backdrop-blur"
          style={{ borderLeft: `3px solid ${platform.color}` }}
        >
          {platform.shortName}
        </span>
      )}
    </div>
  )
}
