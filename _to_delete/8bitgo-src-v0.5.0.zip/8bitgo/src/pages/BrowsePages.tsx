import { Link } from 'react-router-dom'
import { getDevelopers, getGenres, getPlatforms } from '@/services/games'
import { platformMap } from '@/data/platforms'
import { useDocumentTitle } from '@/lib/useDocumentTitle'
import { PlatformCard } from '@/components/game/PlatformCard'
import { GameCover } from '@/components/game/GameCover'

function PageIntro({ eyebrow, title, desc }: { eyebrow: string; title: string; desc: string }) {
  return (
    <div className="max-w-2xl">
      <span className="text-pixel text-[11px] text-brand-hover">{eyebrow}</span>
      <h1 className="mt-2 text-3xl font-extrabold tracking-tight">{title}</h1>
      <p className="mt-3 leading-relaxed text-muted">{desc}</p>
    </div>
  )
}

/* ---------------- 平台 ---------------- */
export function PlatformsPage() {
  useDocumentTitle('游戏平台')
  const platforms = getPlatforms()
  return (
    <div className="container-x py-8 sm:py-10">
      <PageIntro
        eyebrow="PLATFORMS"
        title="游戏平台"
        desc={`共 ${platforms.length} 个平台。从 8 位红白机到 32 位 PlayStation，从掌机到街机，选一台你的童年主机。`}
      />
      <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
        {platforms.map((p) => (
          <PlatformCard key={p.id} platform={p} />
        ))}
      </div>
    </div>
  )
}

/* ---------------- 类型 ---------------- */
export function GenresPage() {
  useDocumentTitle('游戏类型')
  const genres = getGenres()
  return (
    <div className="container-x py-8 sm:py-10">
      <PageIntro eyebrow="GENRES" title="游戏类型" desc="按玩法找游戏：想动手、想动脑，还是想跟着节奏摇摆？" />
      <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
        {genres.map((g) => (
          <Link
            key={g.id}
            to={`/games?genre=${g.id}`}
            className="group card-hover rounded-card border border-line bg-surface p-5 hover:border-brand/60"
          >
            <span className="grid h-12 w-12 place-items-center rounded-xl bg-brand-soft text-2xl transition group-hover:scale-110" aria-hidden>
              {g.icon}
            </span>
            <h2 className="mt-4 text-lg font-bold">{g.name}</h2>
            <p className="mt-1 line-clamp-2 text-sm text-muted">{g.description}</p>
            <p className="mt-3 text-sm font-semibold text-brand-hover">{g.count} 款游戏 →</p>
          </Link>
        ))}
      </div>
    </div>
  )
}

/* ---------------- 开发商 ---------------- */
export function DevelopersPage() {
  useDocumentTitle('开发商')
  const developers = getDevelopers()
  return (
    <div className="container-x py-8 sm:py-10">
      <PageIntro eyebrow="DEVELOPERS" title="开发商" desc={`共 ${developers.length} 家制作公司。点击查看它们在站内的全部作品。`} />
      <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {developers.map((d) => (
          <Link
            key={d.name}
            to={`/games?developer=${encodeURIComponent(d.name)}`}
            className="group card-hover flex items-center gap-4 rounded-card border border-line bg-surface p-3 hover:border-brand/60"
          >
            <div className="w-16 shrink-0 overflow-hidden rounded-lg">
              <GameCover game={d.topGame} ratio="square" showTitle={false} iconSize="sm" />
            </div>
            <div className="min-w-0 flex-1">
              <h2 className="truncate font-bold">{d.name}</h2>
              <p className="mt-0.5 truncate text-xs text-muted">代表作：{d.topGame.titleZh ?? d.topGame.title}</p>
              <p className="mt-1.5 flex flex-wrap gap-1">
                {d.platforms.slice(0, 4).map((p) => (
                  <span key={p} className="rounded bg-white/5 px-1.5 py-0.5 text-[10px] text-muted">
                    {platformMap[p].shortName}
                  </span>
                ))}
              </p>
            </div>
            <span className="text-pixel shrink-0 text-[11px] text-brand-hover">{d.count} 款</span>
          </Link>
        ))}
      </div>
    </div>
  )
}
