import { useEffect, useState, type FormEvent } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { login, register, useCurrentUser, WELCOME_COINS } from '@/services/auth'
import { cx } from '@/lib/format'
import { useDocumentTitle } from '@/lib/useDocumentTitle'
import { Button } from '@/components/ui/Button'

type Mode = 'login' | 'register'

const inputClass =
  'h-11 w-full rounded-xl border border-line bg-surface-2 px-3 text-sm text-fg placeholder:text-dim transition focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30'

export function LoginPage() {
  const [params] = useSearchParams()
  const navigate = useNavigate()
  const user = useCurrentUser()
  const [mode, setMode] = useState<Mode>(params.get('mode') === 'register' ? 'register' : 'login')
  const [email, setEmail] = useState('')
  const [nickname, setNickname] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  useDocumentTitle(mode === 'login' ? '登录' : '注册')

  const next = params.get('next') || '/me'

  // 已登录直接跳走
  useEffect(() => {
    if (user) navigate(next, { replace: true })
  }, [user, next, navigate])

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    setError(null)
    setBusy(true)
    try {
      if (mode === 'login') await login(email, password)
      else await register({ email, nickname, password })
      navigate(next, { replace: true })
    } catch (err) {
      setError(err instanceof Error ? err.message : '操作失败')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="container-x flex min-h-[70vh] items-center justify-center py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 text-center">
          <span className="text-pixel text-[11px] text-brand-hover">PLAYER</span>
          <h1 className="mt-2 text-2xl font-extrabold">{mode === 'login' ? '欢迎回来' : '创建账号'}</h1>
          <p className="mt-1 text-sm text-muted">
            {mode === 'login' ? '登录后可以收藏游戏、查看最近浏览并累积 G 币。' : `注册即送 ${WELCOME_COINS} G 币，开始你的复古之旅。`}
          </p>
        </div>

        <div className="rounded-2xl border border-line bg-surface p-6">
          <div className="mb-5 grid grid-cols-2 rounded-xl bg-surface-2 p-1 text-sm">
            {(['login', 'register'] as Mode[]).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => {
                  setMode(m)
                  setError(null)
                }}
                className={cx('h-9 rounded-lg font-semibold transition', mode === m ? 'bg-brand text-white' : 'text-muted hover:text-fg')}
              >
                {m === 'login' ? '登录' : '注册'}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="space-y-3">
            <label className="block">
              <span className="mb-1 block text-xs text-muted">邮箱</span>
              <input type="email" required autoComplete="email" className={inputClass} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
            </label>
            {mode === 'register' && (
              <label className="block">
                <span className="mb-1 block text-xs text-muted">昵称</span>
                <input required minLength={2} maxLength={16} className={inputClass} value={nickname} onChange={(e) => setNickname(e.target.value)} placeholder="2–16 个字符" />
              </label>
            )}
            <label className="block">
              <span className="mb-1 block text-xs text-muted">密码</span>
              <input
                type="password"
                required
                minLength={6}
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                className={inputClass}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="至少 6 位"
              />
            </label>

            {error && (
              <p role="alert" className="rounded-lg bg-live/15 px-3 py-2 text-sm text-red-300">
                {error}
              </p>
            )}

            <Button size="lg" className="w-full" disabled={busy} type="submit">
              {busy ? '请稍候…' : mode === 'login' ? '登录' : '注册并登录'}
            </Button>
          </form>

          <p className="mt-4 text-center text-xs text-dim">
            账号数据保存在当前浏览器中，密码只保存哈希值。
            <Link to="/privacy" className="ml-1 underline hover:text-fg">
              隐私政策
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
