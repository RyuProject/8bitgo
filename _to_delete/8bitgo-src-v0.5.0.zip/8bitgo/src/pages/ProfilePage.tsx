import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { logout, updateProfile, useCurrentUser } from '@/services/auth'
import { getGamesBySlugs } from '@/services/games'
import { useAllGames } from '@/services/store'
import { cx } from '@/lib/format'
import { useDocumentTitle } from '@/lib/useDocumentTitle'
import { Button } from '@/components/ui/Button'
import { GameCard } from '@/components/game/GameCard'
import { SectionHeader } from '@/components/ui/SectionHeader'

const AVATARS = ['🕹️', '👾', '🎮', '🍄', '⭐', '🐉', '🦔', '🤖', '👻', '🐱', '🔥', '💎']

export function ProfilePage() {
  useDocumentTitle('个人中心')
  const user = useCurrentUser()
  const navigate = useNavigate()
  useAllGames()

  const [editing, setEditing] = useState(false)
  const [nickname, setNickname] = useState('')
  const [avatar, setAvatar] = useState('🕹️')
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!user) navigate('/login?next=/me', { replace: true })
  }, [user, navigate])

  useEffect(() => {
    if (user) {
      setNickname(user.nickname)
      setAvatar(user.avatar)
    }
  }, [user])

  if (!user) return null

  const favorites = getGamesBySlugs(user.favorites)
  const recent = getGamesBySlugs(user.recent)

  const save = () => {
    try {
      updateProfile({ nickname, avatar })
      setEditing(false)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : '保存失败')
    }
  }

  return (
    <div className="container-x space-y-10 py-8 sm:py-10">
      {/* 用户卡片 */}
      <section className="relative overflow-hidden rounded-card border border-line bg-surface p-6">
        <div className="pixel-grid absolute inset-0 opacity-30 [mask-image:linear-gradient(to_right,black,transparent)]" aria-hidden />
        <div className="relative flex flex-col gap-5 sm:flex-row sm:items-center">
          <span className="grid h-20 w-20 shrink-0 place-items-center rounded-2xl bg-brand-soft text-4xl" aria-hidden>
            {editing ? avatar : user.avatar}
          </span>
          <div className="min-w-0 flex-1">
            {editing ? (
              <div className="space-y-3">
                <input
                  value={nickname}
                  onChange={(e) => setNickname(e.target.value)}
                  maxLength={16}
                  className="h-10 w-full max-w-xs rounded-lg border border-line bg-surface-2 px-3 text-sm focus:border-brand focus:outline-none"
                  aria-label="昵称"
                />
                <div className="flex flex-wrap gap-1.5">
                  {AVATARS.map((a) => (
                    <button
                      key={a}
                      type="button"
                      onClick={() => setAvatar(a)}
                      aria-pressed={avatar === a}
                      className={cx('grid h-9 w-9 place-items-center rounded-lg border text-lg transition', avatar === a ? 'border-brand bg-brand-soft' : 'border-line hover:border-line-strong')}
                    >
                      {a}
                    </button>
                  ))}
                </div>
                {error && <p className="text-xs text-live">{error}</p>}
                <div className="flex gap-2">
                  <Button size="sm" onClick={save}>
                    保存
                  </Button>
                  <Button size="sm" variant="secondary" onClick={() => setEditing(false)}>
                    取消
                  </Button>
                </div>
              </div>
            ) : (
              <>
                <h1 className="text-2xl font-extrabold">{user.nickname}</h1>
                <p className="mt-1 text-sm text-muted">
                  {user.email} · {user.createdAt} 加入
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button size="sm" variant="secondary" onClick={() => setEditing(true)}>
                    ✏️ 编辑资料
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      logout()
                      navigate('/')
                    }}
                  >
                    退出登录
                  </Button>
                </div>
              </>
            )}
          </div>
          <dl className="grid shrink-0 grid-cols-3 gap-3 text-center sm:text-left">
            <div className="rounded-xl border border-coin/30 bg-coin-soft px-4 py-3">
              <dt className="text-[11px] text-muted">G 币</dt>
              <dd className="mt-1 text-xl font-semibold text-coin">🪙 {user.coins}</dd>
            </div>
            <div className="rounded-xl border border-line bg-surface-2 px-4 py-3">
              <dt className="text-[11px] text-muted">收藏</dt>
              <dd className="mt-1 text-xl font-semibold">{favorites.length}</dd>
            </div>
            <div className="rounded-xl border border-line bg-surface-2 px-4 py-3">
              <dt className="text-[11px] text-muted">最近浏览</dt>
              <dd className="mt-1 text-xl font-semibold">{recent.length}</dd>
            </div>
          </dl>
        </div>
      </section>

      <section>
        <SectionHeader title="我的收藏" subtitle="在游戏详情页点「收藏」即可加入" icon="❤️" />
        {favorites.length ? (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
            {favorites.map((g) => (
              <GameCard key={g.slug} game={g} />
            ))}
          </div>
        ) : (
          <Empty text="还没有收藏任何游戏" />
        )}
      </section>

      <section>
        <SectionHeader title="最近浏览" subtitle="最多保留 12 条" icon="🕘" />
        {recent.length ? (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
            {recent.map((g) => (
              <GameCard key={g.slug} game={g} />
            ))}
          </div>
        ) : (
          <Empty text="还没有浏览记录" />
        )}
      </section>
    </div>
  )
}

function Empty({ text }: { text: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-line py-10 text-center text-sm text-muted">
      {text}，
      <Link to="/games" className="text-brand-hover hover:underline">
        去游戏库逛逛 →
      </Link>
    </div>
  )
}
