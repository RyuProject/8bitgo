import { useState } from 'react'
import type { PlatformId } from '@/types'
import { platforms, platformMap } from '@/data/platforms'
import { cx } from '@/lib/format'
import { useDocumentTitle } from '@/lib/useDocumentTitle'
import { EmulatorPlayer } from '@/components/player/EmulatorPlayer'
import { defaultKeymap } from '@/lib/emulator'

const STEPS = [
  { n: '01', title: '选择平台', desc: '告诉我们 ROM 属于哪台主机，我们会加载对应的模拟器核心。' },
  { n: '02', title: '拖入 ROM 文件', desc: '支持 zip 压缩包。文件只在你的浏览器本地读取，不会上传到任何服务器。' },
  { n: '03', title: '开始游戏', desc: '首次加载核心需要几秒钟。随时可以存档、全屏或连接手柄。' },
]

export function PlayLocalPage() {
  useDocumentTitle('玩本地 ROM')
  const [platformId, setPlatformId] = useState<PlatformId>('nes')
  const platform = platformMap[platformId]
  const supported = platforms.filter((p) => p.core)
  const unsupported = platforms.filter((p) => !p.core)

  return (
    <div className="container-x py-8 sm:py-10">
      <div className="max-w-2xl">
        <span className="text-pixel text-[11px] text-brand-hover">LOCAL ROM</span>
        <h1 className="mt-2 text-3xl font-extrabold tracking-tight">玩本地游戏 ROM</h1>
        <p className="mt-3 leading-relaxed text-muted">
          手里有自己备份的卡带 ROM，或者自制 / 开源游戏？选择平台，把文件拖进来就能在浏览器里直接运行。
        </p>
      </div>

      <ol className="mt-8 grid gap-4 sm:grid-cols-3">
        {STEPS.map((s) => (
          <li key={s.n} className="rounded-2xl border border-line bg-surface p-5">
            <span className="text-pixel text-[10px] text-coin">{s.n}</span>
            <p className="mt-2 font-bold">{s.title}</p>
            <p className="mt-1 text-sm leading-relaxed text-muted">{s.desc}</p>
          </li>
        ))}
      </ol>

      <div className="mt-10 grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-4">
          <h2 className="text-base font-bold">1. 选择平台</h2>
          <div className="mt-3 grid grid-cols-2 gap-2">
            {supported.map((p) => (
              <button
                key={p.id}
                type="button"
                aria-pressed={platformId === p.id}
                onClick={() => setPlatformId(p.id)}
                className={cx(
                  'flex items-center gap-2 rounded-xl border px-3 py-2.5 text-left text-sm transition',
                  platformId === p.id
                    ? 'border-brand bg-brand-soft text-fg'
                    : 'border-line bg-surface text-muted hover:border-line-strong hover:text-fg',
                )}
              >
                <span aria-hidden>{p.icon}</span>
                <span className="min-w-0">
                  <span className="block truncate font-semibold">{p.shortName}</span>
                  <span className="block truncate text-[11px] opacity-70">{p.romExtensions.slice(0, 3).join(' ')}</span>
                </span>
              </button>
            ))}
          </div>
          {unsupported.length > 0 && (
            <p className="mt-3 text-xs text-dim">
              暂不支持：{unsupported.map((p) => p.name).join('、')}
            </p>
          )}

          <h2 className="mt-8 text-base font-bold">默认键位</h2>
          <div className="mt-3 grid grid-cols-3 gap-2">
            {defaultKeymap.map((k) => (
              <div key={k.button} className="rounded-lg border border-line bg-surface px-2.5 py-2">
                <p className="text-[10px] text-muted">{k.button}</p>
                <p className="font-mono text-xs font-semibold">{k.key}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-8">
          <h2 className="mb-3 text-base font-bold">2. 拖入 ROM 并开始</h2>
          <EmulatorPlayer key={platform.id} platform={platform} gameName={`${platform.name} ROM`} icon={platform.icon} />
          <p className="mt-3 text-xs leading-relaxed text-dim">
            请只运行你拥有合法备份权利的游戏，或自制 / 开源 ROM。8BitGo 不提供任何受版权保护的游戏文件。
          </p>
        </div>
      </div>
    </div>
  )
}
