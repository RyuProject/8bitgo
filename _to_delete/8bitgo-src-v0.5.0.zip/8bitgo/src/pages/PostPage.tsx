import { Link, useParams } from 'react-router-dom'
import { getPost, getPublishedPosts, readMinutes, useAllPosts } from '@/services/posts'
import { renderMarkdown } from '@/lib/markdown'
import { gradientFor } from '@/lib/gradients'
import { useDocumentTitle } from '@/lib/useDocumentTitle'
import { NotFoundPage } from './NotFoundPage'

export function PostPage() {
  const { slug = '' } = useParams<{ slug: string }>()
  useAllPosts()
  const post = getPost(slug)
  useDocumentTitle(post ? post.title : '文章不存在')

  if (!post) return <NotFoundPage message="这篇文章不存在，或者还没有发布。" />

  const more = getPublishedPosts()
    .filter((p) => p.slug !== post.slug)
    .slice(0, 3)

  return (
    <div className="container-x py-8 sm:py-10">
      <nav className="text-xs text-muted" aria-label="面包屑">
        <Link to="/" className="hover:text-fg">
          首页
        </Link>
        <span className="mx-1.5">/</span>
        <Link to="/blog" className="hover:text-fg">
          博客
        </Link>
        <span className="mx-1.5">/</span>
        <span className="text-fg">{post.title}</span>
      </nav>

      <article className="mx-auto mt-6 max-w-3xl">
        <div className="relative grid h-40 place-items-center overflow-hidden rounded-card text-7xl sm:h-52" style={{ background: gradientFor(post.slug) }} aria-hidden>
          <span className="pixel-grid absolute inset-0 opacity-60" />
          <span className="relative drop-shadow">{post.icon}</span>
        </div>

        <header className="mt-6">
          <div className="flex flex-wrap gap-1.5">
            {post.tags.map((t) => (
              <Link key={t} to={`/blog?tag=${encodeURIComponent(t)}`} className="rounded bg-brand-soft px-1.5 py-0.5 text-[11px] font-semibold text-brand-hover hover:underline">
                {t}
              </Link>
            ))}
          </div>
          <h1 className="mt-3 text-3xl font-extrabold leading-tight tracking-tight sm:text-4xl">{post.title}</h1>
          <p className="mt-3 text-sm text-muted">
            {post.author} · {post.date} · 约 {readMinutes(post.content)} 分钟阅读
          </p>
        </header>

        <div className="prose-pixel mt-8">{renderMarkdown(post.content)}</div>
      </article>

      {more.length > 0 && (
        <section className="mx-auto mt-14 max-w-3xl border-t border-line pt-8">
          <h2 className="text-lg font-bold">更多文章</h2>
          <ul className="mt-4 divide-y divide-line">
            {more.map((p) => (
              <li key={p.slug}>
                <Link to={`/blog/${p.slug}`} className="group flex items-center gap-3 py-3">
                  <span className="text-2xl" aria-hidden>
                    {p.icon}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-semibold group-hover:text-brand-hover">{p.title}</span>
                    <span className="block truncate text-xs text-muted">{p.excerpt}</span>
                  </span>
                  <span className="shrink-0 text-xs text-dim">{p.date}</span>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  )
}
