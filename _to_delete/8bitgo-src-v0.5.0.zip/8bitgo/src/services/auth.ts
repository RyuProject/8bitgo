/**
 * 用户与登录（纯前端实现）。
 *
 * - 用户列表保存在 localStorage（8bitgo.users），密码只保存「盐 + SHA-256 哈希」，不存明文。
 * - 登录态保存在 localStorage（8bitgo.session），仅记录用户 id。
 * - 这是给自用 / 演示准备的实现，同一浏览器内有效；上线时请换成真正的后端接口，
 *   把下面的 register / login / logout 改成 fetch 即可，组件不需要改。
 */
import { useSyncExternalStore } from 'react'
import type { PublicUser, User, UserStatus } from '@/types'
import { createLocalStore, randomId } from './localStore'

export const USERS_KEY = '8bitgo.users'
export const SESSION_KEY = '8bitgo.session'
export const WELCOME_COINS = 100

function isUser(x: unknown): x is User {
  const u = x as User
  return (
    typeof u === 'object' &&
    u !== null &&
    typeof u.id === 'string' &&
    typeof u.email === 'string' &&
    typeof u.nickname === 'string' &&
    typeof u.passwordHash === 'string' &&
    Array.isArray(u.favorites)
  )
}

export const usersStore = createLocalStore<User>({
  key: USERS_KEY,
  initial: [],
  getId: (u) => u.id,
  validate: isUser,
})

/* ---------------- 密码哈希 ---------------- */

async function sha256Hex(text: string): Promise<string> {
  const data = new TextEncoder().encode(text)
  const digest = await crypto.subtle.digest('SHA-256', data)
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('')
}

function makeSalt(): string {
  const bytes = new Uint8Array(16)
  crypto.getRandomValues(bytes)
  return [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('')
}

/* ---------------- 会话 ---------------- */

const sessionListeners = new Set<() => void>()

function readSessionId(): string | null {
  try {
    return localStorage.getItem(SESSION_KEY)
  } catch {
    return null
  }
}

function writeSessionId(id: string | null) {
  try {
    if (id) localStorage.setItem(SESSION_KEY, id)
    else localStorage.removeItem(SESSION_KEY)
  } catch {
    /* ignore */
  }
  for (const l of sessionListeners) l()
}

function subscribeSession(listener: () => void) {
  sessionListeners.add(listener)
  const unsubUsers = usersStore.subscribe(listener)
  const onStorage = (e: StorageEvent) => {
    if (e.key === SESSION_KEY || e.key === USERS_KEY) listener()
  }
  window.addEventListener('storage', onStorage)
  return () => {
    sessionListeners.delete(listener)
    unsubUsers()
    window.removeEventListener('storage', onStorage)
  }
}

export function toPublic(u: User): PublicUser {
  const { passwordHash: _h, salt: _s, ...rest } = u
  return rest
}

let publicCache: { id: string | null; user: User | null; value: PublicUser | null } = { id: null, user: null, value: null }

/** 当前登录用户（未登录或被封禁返回 null） */
export function getCurrentUser(): PublicUser | null {
  const id = readSessionId()
  const user = id ? (usersStore.find(id) ?? null) : null
  if (!user || user.status === 'banned') {
    publicCache = { id, user: null, value: null }
    return null
  }
  // 引用不变时复用同一对象，避免 useSyncExternalStore 无限重渲染
  if (publicCache.user !== user) publicCache = { id, user, value: toPublic(user) }
  return publicCache.value
}

export function useCurrentUser(): PublicUser | null {
  return useSyncExternalStore(subscribeSession, getCurrentUser, getCurrentUser)
}

/* ---------------- 注册 / 登录 / 退出 ---------------- */

export interface RegisterInput {
  email: string
  nickname: string
  password: string
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

export async function register({ email, nickname, password }: RegisterInput): Promise<PublicUser> {
  const e = email.trim().toLowerCase()
  const n = nickname.trim()
  if (!EMAIL_RE.test(e)) throw new Error('邮箱格式不正确')
  if (n.length < 2 || n.length > 16) throw new Error('昵称需要 2–16 个字符')
  if (password.length < 6) throw new Error('密码至少 6 位')
  if (usersStore.load().some((u) => u.email === e)) throw new Error('该邮箱已注册，请直接登录')

  const salt = makeSalt()
  const user: User = {
    id: randomId('u'),
    email: e,
    nickname: n,
    avatar: '🕹️',
    passwordHash: await sha256Hex(salt + password),
    salt,
    coins: WELCOME_COINS,
    role: 'user',
    status: 'active',
    createdAt: new Date().toISOString().slice(0, 10),
    favorites: [],
    recent: [],
  }
  usersStore.upsert(user)
  writeSessionId(user.id)
  return toPublic(user)
}

export async function login(email: string, password: string): Promise<PublicUser> {
  const e = email.trim().toLowerCase()
  const user = usersStore.load().find((u) => u.email === e)
  if (!user) throw new Error('邮箱或密码不正确')
  const hash = await sha256Hex(user.salt + password)
  if (hash !== user.passwordHash) throw new Error('邮箱或密码不正确')
  if (user.status === 'banned') throw new Error('该账号已被封禁，请联系管理员')
  writeSessionId(user.id)
  return toPublic(user)
}

export function logout() {
  writeSessionId(null)
}

/* ---------------- 当前用户的操作 ---------------- */

function requireUser(): User {
  const id = readSessionId()
  const user = id ? usersStore.find(id) : undefined
  if (!user) throw new Error('请先登录')
  return user
}

export function updateProfile(patch: { nickname?: string; avatar?: string }) {
  const user = requireUser()
  const nickname = patch.nickname?.trim()
  if (nickname !== undefined && (nickname.length < 2 || nickname.length > 16)) throw new Error('昵称需要 2–16 个字符')
  usersStore.update(user.id, {
    ...(nickname !== undefined ? { nickname } : {}),
    ...(patch.avatar ? { avatar: patch.avatar } : {}),
  })
}

export function toggleFavorite(slug: string): boolean {
  const user = requireUser()
  const has = user.favorites.includes(slug)
  usersStore.update(user.id, {
    favorites: has ? user.favorites.filter((s) => s !== slug) : [slug, ...user.favorites],
  })
  return !has
}

/** 记录最近浏览（未登录时静默忽略） */
export function recordRecent(slug: string) {
  const id = readSessionId()
  const user = id ? usersStore.find(id) : undefined
  if (!user) return
  const recent = [slug, ...user.recent.filter((s) => s !== slug)].slice(0, 12)
  if (recent.join() === user.recent.join()) return
  usersStore.update(user.id, { recent })
}

/* ---------------- 后台管理 ---------------- */

export function adminAdjustCoins(id: string, delta: number) {
  usersStore.update(id, (u) => ({ ...u, coins: Math.max(0, u.coins + delta) }))
}

export function adminSetStatus(id: string, status: UserStatus) {
  usersStore.update(id, { status })
  if (status === 'banned' && readSessionId() === id) writeSessionId(null)
}

export function adminDeleteUser(id: string) {
  usersStore.remove(id)
  if (readSessionId() === id) writeSessionId(null)
}

export function useAllUsers(): PublicUser[] {
  const users = usersStore.useAll()
  return users.map(toPublic)
}
