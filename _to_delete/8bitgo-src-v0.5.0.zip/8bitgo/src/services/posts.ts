import { posts as builtinPosts } from '@/data/posts'
import type { Post } from '@/types'
import { createLocalStore } from './localStore'

export const POSTS_KEY = '8bitgo.admin.posts'

function isPost(x: unknown): x is Post {
  const p = x as Post
  return (
    typeof p === 'object' &&
    p !== null &&
    typeof p.slug === 'string' &&
    typeof p.title === 'string' &&
    typeof p.content === 'string' &&
    typeof p.date === 'string'
  )
}

export const postsStore = createLocalStore<Post>({
  key: POSTS_KEY,
  initial: builtinPosts,
  getId: (p) => p.slug,
  validate: isPost,
})

const byDateDesc = (a: Post, b: Post) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0)

/** 前台可见的文章（已发布），按日期倒序 */
export function getPublishedPosts(): Post[] {
  return postsStore
    .load()
    .filter((p) => p.published)
    .sort(byDateDesc)
}

export function getPost(slug: string): Post | undefined {
  const p = postsStore.find(slug)
  return p && p.published ? p : undefined
}

export function getPostTags(): Array<{ tag: string; count: number }> {
  const map = new Map<string, number>()
  for (const p of getPublishedPosts()) for (const t of p.tags) map.set(t, (map.get(t) ?? 0) + 1)
  return [...map.entries()].map(([tag, count]) => ({ tag, count })).sort((a, b) => b.count - a.count)
}

/** 粗略阅读时长（分钟） */
export function readMinutes(content: string): number {
  return Math.max(1, Math.round(content.replace(/\s+/g, '').length / 400))
}

export function useAllPosts(): Post[] {
  return postsStore.useAll()
}
