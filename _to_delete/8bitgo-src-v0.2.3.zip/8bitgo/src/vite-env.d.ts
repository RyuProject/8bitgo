/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_EJS_PATH?: string
  readonly VITE_SITE_NAME?: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
