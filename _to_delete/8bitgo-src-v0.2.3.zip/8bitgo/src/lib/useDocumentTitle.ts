import { useEffect } from 'react'

const SITE = import.meta.env.VITE_SITE_NAME ?? '8BitGo'
const DEFAULT = `${SITE} — 免费在线玩复古模拟器游戏`

export function useDocumentTitle(title?: string) {
  useEffect(() => {
    document.title = title ? `${title} - ${SITE}` : DEFAULT
    return () => {
      document.title = DEFAULT
    }
  }, [title])
}
