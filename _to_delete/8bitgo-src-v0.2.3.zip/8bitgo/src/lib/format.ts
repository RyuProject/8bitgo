/** 12800 -> 1.3万；1200 -> 1200；13500000 -> 1350万 */
export function formatCount(n: number): string {
  if (n >= 1_0000_0000) return `${(n / 1_0000_0000).toFixed(1).replace(/\.0$/, '')}亿`
  if (n >= 1_0000) return `${(n / 1_0000).toFixed(1).replace(/\.0$/, '')}万`
  return n.toLocaleString('zh-CN')
}

export function formatRating(r: number): string {
  return r.toFixed(1)
}

export function formatPlayers(players: number): string {
  return players === 1 ? '单人' : `${players} 人`
}

/** 简单的字符串哈希，用于给封面挑选稳定的配色 */
export function hashString(str: string): number {
  let h = 2166136261
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return h >>> 0
}

export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(' ')
}
