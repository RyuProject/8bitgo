/**
 * EmulatorJS 集成。
 *
 * EmulatorJS 通过全局 window.EJS_* 变量读取配置，并在顶层作用域声明
 * `class EmulatorJS`，因此不能在同一个页面里反复注入（第二次会报
 * 「Identifier 'EmulatorJS' has already been declared」）。
 *
 * 这里的做法是把模拟器放进一个同源的 srcdoc iframe 中运行：
 *  - 每局游戏拥有独立的全局作用域，切换 ROM / 路由时直接移除 iframe，
 *    画面、声音、WebAssembly 内存都会随之释放；
 *  - React StrictMode 的二次挂载也不会产生重复实例；
 *  - ROM 以 blob: URL 交给模拟器，全程只在浏览器本地读取，不经过服务器。
 *
 * 默认从官方 CDN 加载资源。若需自托管，把 EmulatorJS 发行包中的 data/
 * 目录放到 public/emulatorjs/ 下，并在 .env 中设置 VITE_EJS_PATH=/emulatorjs/
 */

export const EJS_PATH: string = (() => {
  const p = import.meta.env.VITE_EJS_PATH || 'https://cdn.emulatorjs.org/stable/data/'
  return p.endsWith('/') ? p : `${p}/`
})()

export interface EmulatorOptions {
  /** EmulatorJS 核心 / 系统名，如 'nes'、'gba'、'psx' */
  core: string
  /** ROM 文件（或可直接访问的 URL） */
  game: File | string
  gameName: string
  color?: string
  language?: string
  volume?: number
  startOnLoaded?: boolean
  onReady?: () => void
  onStart?: () => void
  onError?: (message: string) => void
}

const FRAME_HTML = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  html, body { margin: 0; height: 100%; background: #0b0b0f; overflow: hidden; }
  #game { width: 100%; height: 100%; }
</style>
</head>
<body><div id="game"></div></body>
</html>`

/**
 * 在 container 内创建承载模拟器的 iframe，返回销毁函数。
 */
export function mountEmulator(container: HTMLElement, options: EmulatorOptions): () => void {
  const iframe = document.createElement('iframe')
  iframe.title = `${options.gameName} 模拟器`
  iframe.style.cssText = 'width:100%;height:100%;border:0;display:block;background:#0b0b0f'
  iframe.setAttribute('allow', 'fullscreen; gamepad; autoplay; camera; microphone; clipboard-write')
  iframe.srcdoc = FRAME_HTML

  let destroyed = false

  // 本地文件转成 blob: URL 交给模拟器（同源 iframe 可直接访问）；
  // gameName 使用原始文件名，这样解压 / 写入虚拟文件系统时能保留正确的扩展名
  const isFile = typeof options.game !== 'string'
  const gameUrl = isFile ? URL.createObjectURL(options.game as File) : (options.game as string)
  const gameName = isFile ? (options.game as File).name : options.gameName

  iframe.addEventListener('load', () => {
    if (destroyed) return
    const win = iframe.contentWindow as (Window & Record<string, unknown>) | null
    const doc = iframe.contentDocument
    if (!win || !doc) {
      options.onError?.('无法初始化模拟器容器')
      return
    }

    Object.assign(win, {
      EJS_player: '#game',
      EJS_core: options.core,
      EJS_gameUrl: gameUrl,
      EJS_gameName: gameName,
      EJS_pathtodata: EJS_PATH,
      EJS_color: options.color ?? '#8b5cf6',
      EJS_backgroundColor: '#0b0b0f',
      EJS_language: options.language ?? 'zh-CN',
      EJS_startOnLoaded: options.startOnLoaded ?? true,
      EJS_volume: options.volume ?? 0.6,
      EJS_ready: () => options.onReady?.(),
      EJS_onGameStart: () => options.onStart?.(),
    })

    const script = doc.createElement('script')
    script.src = `${EJS_PATH}loader.js`
    script.async = true
    script.onerror = () =>
      options.onError?.(
        `无法加载模拟器资源（${EJS_PATH}）。请检查网络连接，或在 .env 中配置自托管的 VITE_EJS_PATH。`,
      )
    doc.body.appendChild(script)
  })

  container.appendChild(iframe)

  return () => {
    destroyed = true
    try {
      // 先切到空白页以停止 WebAssembly 主循环与音频，再移除节点
      iframe.srcdoc = ''
      iframe.src = 'about:blank'
    } catch {
      /* ignore */
    }
    iframe.remove()
    if (isFile) URL.revokeObjectURL(gameUrl)
  }
}

/** 判断文件后缀是否在平台允许的 ROM 类型内 */
export function isRomFileAccepted(file: File, extensions: string[]): boolean {
  const name = file.name.toLowerCase()
  return extensions.some((ext) => name.endsWith(ext))
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

/** 默认键位（EmulatorJS 出厂设置，可在模拟器设置菜单中修改） */
export const defaultKeymap: Array<{ button: string; key: string }> = [
  { button: '方向键', key: '↑ ↓ ← →' },
  { button: 'A', key: 'Z' },
  { button: 'B', key: 'X' },
  { button: 'X', key: 'A' },
  { button: 'Y', key: 'S' },
  { button: 'L', key: 'Q' },
  { button: 'R', key: 'E' },
  { button: 'Start', key: 'Enter' },
  { button: 'Select', key: 'V' },
]
