import { useCallback, useEffect, useRef, useState, type DragEvent, type ReactNode } from 'react'
import type { Platform } from '@/types'
import { formatBytes, isRomFileAccepted, mountEmulator } from '@/lib/emulator'
import { cx } from '@/lib/format'
import { Button } from '@/components/ui/Button'
import { useShell } from '@/components/layout/ShellContext'

type Status = 'idle' | 'loading' | 'running' | 'error'

interface ActiveSession {
  id: number
  game: File | string
}

interface Props {
  platform: Platform
  gameName: string
  /** 空闲态背景（例如封面） */
  backdrop?: ReactNode
  /** 空闲态显示的图标 */
  icon?: string
  className?: string
  /** 若有可直接访问的 ROM URL（例如自制/开源游戏），可跳过上传 */
  romUrl?: string
}

/**
 * 模拟器播放器：
 *  idle    —— 显示封面与「选择 ROM 开始游戏」，支持拖拽
 *  loading —— 已选择文件，模拟器资源加载中
 *  running —— EmulatorJS 已就绪（运行在独立 iframe 内）
 */
export function EmulatorPlayer({ platform, gameName, backdrop, icon, className, romUrl }: Props) {
  const [status, setStatus] = useState<Status>('idle')
  const [file, setFile] = useState<File | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [dragging, setDragging] = useState(false)
  const [session, setSession] = useState<ActiveSession | null>(null)

  const hostRef = useRef<HTMLDivElement>(null)
  const frameRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const sessionCounter = useRef(0)

  const supported = Boolean(platform.core)
  const core = platform.core
  const { immersive, toggleImmersive } = useShell()

  // 会话变化时挂载 / 卸载模拟器 iframe
  useEffect(() => {
    const host = frameRef.current
    if (!session || !host || !core) return

    const destroy = mountEmulator(host, {
      core,
      game: session.game,
      gameName,
      onReady: () => setStatus('running'),
      onError: (message) => {
        setError(message)
        setStatus('error')
      },
    })
    return destroy
  }, [session, core, gameName])

  const start = useCallback(
    (picked: File | null) => {
      setError(null)
      let game: File | string | null = null
      if (picked) {
        if (!isRomFileAccepted(picked, platform.romExtensions)) {
          setError(`文件格式不支持。${platform.name} 支持：${platform.romExtensions.join('、')}`)
          return
        }
        setFile(picked)
        game = picked
      } else if (romUrl) {
        game = romUrl
      }
      if (!game) return
      sessionCounter.current += 1
      setSession({ id: sessionCounter.current, game })
      setStatus('loading')
    },
    [platform, romUrl],
  )

  const reset = () => {
    setSession(null)
    setStatus('idle')
    setFile(null)
    setError(null)
    if (inputRef.current) inputRef.current.value = ''
  }

  const onDrop = (e: DragEvent) => {
    e.preventDefault()
    setDragging(false)
    const dropped = e.dataTransfer.files?.[0]
    if (dropped) start(dropped)
  }

  const toggleFullscreen = () => {
    const el = hostRef.current
    if (!el) return
    if (document.fullscreenElement) void document.exitFullscreen()
    else void el.requestFullscreen?.()
  }

  const busy = status === 'loading' || status === 'running'

  return (
    <div className={cx('overflow-hidden rounded-2xl border border-line bg-black', className)}>
      {/* 画面区域 */}
      <div
        ref={hostRef}
        className={cx('relative aspect-video w-full bg-black', dragging && 'ring-2 ring-brand ring-inset')}
        onDragOver={(e) => {
          e.preventDefault()
          if (!busy) setDragging(true)
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
      >
        {/* EmulatorJS 挂载点：iframe 由 mountEmulator 注入，React 不管理其子节点 */}
        <div ref={frameRef} className={cx('absolute inset-0', busy ? 'block' : 'hidden')} />

        {!busy && (
          <div className="absolute inset-0">
            <div className="absolute inset-0 opacity-60 blur-sm">{backdrop}</div>
            <div className="scanlines absolute inset-0" aria-hidden />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-black/20" />

            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 px-6 text-center">
              {icon && (
                <span className="hidden text-6xl drop-shadow-[0_8px_16px_rgba(0,0,0,0.6)] sm:block sm:text-7xl" aria-hidden>
                  {icon}
                </span>
              )}
              {supported ? (
                <>
                  <Button size="lg" onClick={() => (romUrl ? start(null) : inputRef.current?.click())}>
                    <span aria-hidden>▶</span> {romUrl ? '开始游戏' : '选择 ROM 开始游戏'}
                  </Button>
                  <p className="max-w-md text-[11px] leading-relaxed text-white/70 sm:text-xs">
                    {romUrl ? (
                      <>模拟器将在浏览器内运行，首次加载需要几秒钟。</>
                    ) : (
                      <>
                        把 <span className="font-semibold text-white">{platform.name}</span> 的 ROM 文件拖到这里，
                        或点击按钮选择。文件只在你的浏览器本地读取，不会上传。
                        <br />
                        支持格式：{platform.romExtensions.join(' ')}
                      </>
                    )}
                  </p>
                </>
              ) : (
                <div className="max-w-md rounded-xl border border-line bg-black/60 p-4 text-sm text-white/80 backdrop-blur">
                  <p className="font-semibold text-white">该平台暂不支持在线运行</p>
                  <p className="mt-1 text-xs leading-relaxed">
                    {platform.name} 的浏览器运行时正在接入中，敬请期待。你可以先看看其他平台的游戏。
                  </p>
                </div>
              )}
              {error && (
                <p role="alert" className="max-w-md rounded-lg bg-live/20 px-3 py-2 text-xs text-red-200">
                  {error}
                </p>
              )}
            </div>
          </div>
        )}

        {status === 'loading' && (
          <div className="pointer-events-none absolute left-3 top-3 flex items-center gap-2 rounded-lg bg-black/70 px-3 py-1.5 text-xs text-white backdrop-blur">
            <span className="h-2 w-2 animate-ping rounded-full bg-brand-hover" />
            正在加载模拟器…
          </div>
        )}

        <input
          ref={inputRef}
          type="file"
          accept={platform.romExtensions.join(',')}
          className="hidden"
          onChange={(e) => start(e.target.files?.[0] ?? null)}
        />
      </div>

      {/* 工具栏 */}
      <div className="flex flex-wrap items-center gap-2 border-t border-line bg-surface px-3 py-2 text-xs">
        <span
          className={cx(
            'inline-flex items-center gap-1.5 rounded-md px-2 py-1 font-semibold',
            status === 'running'
              ? 'bg-online/15 text-online'
              : status === 'loading'
                ? 'bg-brand-soft text-brand-hover'
                : status === 'error'
                  ? 'bg-live/15 text-red-300'
                  : 'bg-white/5 text-muted',
          )}
        >
          <span className={cx('h-1.5 w-1.5 rounded-full', status === 'running' ? 'bg-online' : 'bg-current')} />
          {status === 'running' ? '运行中' : status === 'loading' ? '加载中' : status === 'error' ? '出错' : '未开始'}
        </span>
        {file && (
          <span className="truncate text-muted" title={file.name}>
            📄 {file.name} · {formatBytes(file.size)}
          </span>
        )}
        <span className="text-muted">核心：{core ?? '—'}</span>

        <div className="ml-auto flex items-center gap-1.5">
          {(busy || status === 'error') && (
            <Button variant="ghost" size="sm" onClick={reset}>
              ⏏ 更换 ROM
            </Button>
          )}
          {supported && (
            <>
              <Button
                variant={immersive ? 'primary' : 'secondary'}
                size="sm"
                onClick={toggleImmersive}
                title="隐藏侧边栏与顶栏，只保留游戏画面（Esc 退出）"
                aria-pressed={immersive}
              >
                {immersive ? '✕ 退出沉浸' : '◧ 沉浸模式'}
              </Button>
              <Button variant="secondary" size="sm" onClick={toggleFullscreen} title="浏览器全屏">
                ⛶ 全屏
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
