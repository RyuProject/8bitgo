import type { ButtonHTMLAttributes, ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { cx } from '@/lib/format'

type Variant = 'primary' | 'secondary' | 'ghost' | 'coin' | 'danger'
type Size = 'sm' | 'md' | 'lg'

const base =
  'inline-flex items-center justify-center gap-2 rounded-xl font-semibold whitespace-nowrap transition duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/70 disabled:opacity-50 disabled:pointer-events-none select-none'

const variants: Record<Variant, string> = {
  primary:
    'bg-brand text-white hover:bg-brand-hover shadow-[0_8px_24px_-8px_rgba(139,92,246,0.7)] active:translate-y-px',
  secondary:
    'bg-surface-2 text-fg border border-line-strong hover:bg-surface-3 hover:border-white/20 active:translate-y-px',
  ghost: 'text-muted hover:text-fg hover:bg-white/5',
  coin: 'bg-coin text-black hover:brightness-110 active:translate-y-px',
  danger: 'bg-live text-white hover:brightness-110',
}

const sizes: Record<Size, string> = {
  sm: 'h-8 px-3 text-xs',
  md: 'h-10 px-4 text-sm',
  lg: 'h-12 px-6 text-base',
}

interface CommonProps {
  variant?: Variant
  size?: Size
  className?: string
  children: ReactNode
}

type ButtonProps = CommonProps & ButtonHTMLAttributes<HTMLButtonElement> & { to?: undefined }
type LinkProps = CommonProps & { to: string; target?: string; rel?: string; onClick?: () => void }

export function buttonClasses(variant: Variant = 'primary', size: Size = 'md', className?: string) {
  return cx(base, variants[variant], sizes[size], className)
}

export function Button(props: ButtonProps | LinkProps) {
  if (typeof props.to === 'string') {
    const { variant, size, className, children, to, target, rel, onClick } = props
    return (
      <Link to={to} target={target} rel={rel} onClick={onClick} className={buttonClasses(variant, size, className)}>
        {children}
      </Link>
    )
  }

  const { variant, size, className, children, ...rest } = props as ButtonProps
  return (
    <button type="button" className={buttonClasses(variant, size, className)} {...rest}>
      {children}
    </button>
  )
}
