import { Link } from 'react-router-dom'
import { SectionHeader } from '@/components/ui/SectionHeader'
import { HScroll } from '@/components/ui/HScroll'
import { Accordion } from '@/components/ui/Accordion'
import { Button } from '@/components/ui/Button'
import { GameCard } from '@/components/game/GameCard'
import { GameCardWide } from '@/components/game/GameCardWide'
import { PlatformCard } from '@/components/game/PlatformCard'
import { StreamCard } from '@/components/game/StreamCard'
import {
  getCoinGames,
  getGamesByGenre,
  getLiveStreams,
  getMultiplayerGames,
  getNewestGames,
  getPlatforms,
  getPopularGames,
  getTopRatedGames,
} from '@/services/games'
import { genreMap } from '@/data/genres'
import { faq } from '@/data/faq'
import type { GenreId } from '@/types'

/* ---------------- 直播 ---------------- */
export function LiveSection() {
  const streams = getLiveStreams()
  return (
    <section className="container-x">
      <SectionHeader
        id="live"
        title="直播"
        subtitle={`${streams.length} 位主播正在直播复古游戏`}
        icon={<span className="inline-block h-2.5 w-2.5 rounded-full bg-live animate-blink" />}
        moreTo="/#live"
        moreLabel="全部直播"
      />
      <HScroll itemClassName="w-72 sm:w-80">
        {streams.map((s) => (
          <StreamCard key={s.id} stream={s} />
        ))}
      </HScroll>
    </section>
  )
}

/* ---------------- 最多人玩 ---------------- */
export function PopularSection() {
  const games = getPopularGames(12)
  return (
    <section className="container-x">
      <SectionHeader
        title="最多人玩的模拟器游戏"
        subtitle="按累计游玩次数排序"
        icon="🔥"
        moreTo="/games?sort=popular"
      />
      <HScroll>
        {games.map((g, i) => (
          <GameCard key={g.slug} game={g} rank={i + 1} />
        ))}
      </HScroll>
    </section>
  )
}

/* ---------------- 按平台 ---------------- */
export function PlatformsSection() {
  const platforms = getPlatforms().slice(0, 8)
  return (
    <section className="container-x">
      <SectionHeader title="按平台玩复古游戏" subtitle="从掌机到街机，挑一台你的童年主机" icon="🎮" moreTo="/platforms" />
      <HScroll itemClassName="w-52 sm:w-56">
        {platforms.map((p) => (
          <PlatformCard key={p.id} platform={p} className="h-full" />
        ))}
      </HScroll>
    </section>
  )
}

/* ---------------- 最新上线 ---------------- */
export function LatestSection() {
  const games = getNewestGames(10)
  return (
    <section className="container-x">
      <SectionHeader title="最新在线复古游戏" subtitle="每周持续更新" icon="✨" moreTo="/games?sort=newest" />
      <HScroll itemClassName="w-64 sm:w-72">
        {games.map((g, i) => (
          <GameCardWide key={g.slug} game={g} isNew={i < 3} />
        ))}
      </HScroll>
    </section>
  )
}

/* ---------------- 一起玩 ---------------- */
export function TogetherSection() {
  const games = getMultiplayerGames(12)
  return (
    <section className="container-x">
      <SectionHeader
        title="一起玩"
        subtitle="支持本地双人或在线联机的游戏，邀请好友加入房间"
        icon="👥"
        moreTo="/games?multiplayer=1"
      />
      <HScroll>
        {games.map((g) => (
          <GameCard key={g.slug} game={g} />
        ))}
      </HScroll>
    </section>
  )
}

/* ---------------- 赢取 G 币 ---------------- */
export function CoinSection() {
  const games = getCoinGames(12)
  return (
    <section className="container-x">
      <div className="rounded-3xl border border-coin/25 bg-gradient-to-br from-coin/10 via-transparent to-transparent p-5 sm:p-6">
        <SectionHeader
          title="通过游戏赢取 G 币"
          subtitle="通关、刷新纪录或完成每日任务即可获得 G 币，用于兑换主题与会员权益"
          icon="🪙"
          moreTo="/games?coin=1"
        />
        <HScroll bleed={false}>
          {games.map((g) => (
            <GameCard key={g.slug} game={g} />
          ))}
        </HScroll>
      </div>
    </section>
  )
}

/* ---------------- 评分最高 ---------------- */
export function TopRatedSection() {
  const games = getTopRatedGames(12)
  return (
    <section className="container-x">
      <SectionHeader title="评分最高的经典游戏" subtitle="来自玩家的真实评分" icon="⭐" moreTo="/games?sort=rating" />
      <HScroll>
        {games.map((g, i) => (
          <GameCard key={g.slug} game={g} rank={i + 1} />
        ))}
      </HScroll>
    </section>
  )
}

/* ---------------- 分类网格 ---------------- */
const GENRE_ROWS: GenreId[] = ['action', 'strategy', 'rpg', 'music', 'sports', 'puzzle']

export function GenreGridSection() {
  return (
    <section className="container-x space-y-10">
      <SectionHeader title="按类型探索" subtitle="每个类型挑出最受欢迎的六款" icon="🧭" moreTo="/genres" />
      {GENRE_ROWS.map((id) => {
        const genre = genreMap[id]
        const games = getGamesByGenre(id, 6)
        if (!games.length) return null
        return (
          <div key={id}>
            <div className="mb-3 flex items-center justify-between">
              <h3 className="flex items-center gap-2 text-lg font-bold">
                <span aria-hidden>{genre.icon}</span>
                {genre.name}
              </h3>
              <Link to={`/games?genre=${id}`} className="text-sm text-muted hover:text-brand-hover">
                更多{genre.name}游戏 →
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 2xl:grid-cols-6">
              {games.map((g) => (
                <GameCard key={g.slug} game={g} />
              ))}
            </div>
          </div>
        )
      })}
    </section>
  )
}

/* ---------------- 工具与扩展 ---------------- */
const TOOLS = [
  {
    icon: '🤸',
    tag: 'Pose Control',
    title: '体感控制器',
    desc: '打开摄像头，用挥手、跳跃、下蹲代替按键。无需任何外设，在客厅里就能全身投入。',
    to: '/apps',
    cta: '了解体感玩法',
  },
  {
    icon: '🎙️',
    tag: 'Voice Control',
    title: '语音控制器',
    desc: '说出「跳」「开火」「暂停」即可操作游戏，适合无障碍场景，也适合解放双手的懒人模式。',
    to: '/apps',
    cta: '试试语音操作',
  },
  {
    icon: '🎬',
    tag: 'AI Video',
    title: 'AI 视频剪辑',
    desc: '一键录制游戏过程，AI 自动挑出高光时刻剪成短视频，配好字幕直接分享到社交平台。',
    to: '/apps',
    cta: '录制我的高光',
  },
]

export function ToolsSection() {
  return (
    <section className="container-x">
      <SectionHeader title="工具与扩展" subtitle="不只是模拟器：让复古游戏玩出新花样" icon="🧰" />
      <div className="grid gap-4 md:grid-cols-3">
        {TOOLS.map((t) => (
          <article
            key={t.title}
            className="group relative overflow-hidden rounded-card border border-line bg-surface p-6 transition hover:border-brand/60"
          >
            <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-brand/15 blur-3xl transition group-hover:bg-brand/30" aria-hidden />
            <div className="relative">
              <span className="text-pixel text-[8px] text-brand-hover">{t.tag}</span>
              <div className="mt-3 flex items-center gap-3">
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-brand-soft text-2xl" aria-hidden>
                  {t.icon}
                </span>
                <h3 className="text-lg font-bold">{t.title}</h3>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-muted">{t.desc}</p>
              <Button to={t.to} variant="secondary" size="sm" className="mt-5">
                {t.cta} →
              </Button>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}

/* ---------------- FAQ ---------------- */
export function FaqSection() {
  return (
    <section className="container-x">
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-4">
          <SectionHeader title="在线模拟器游戏常见问题" subtitle="关于付费、下载、平台与存档" icon="❓" />
          <p className="text-sm leading-relaxed text-muted">
            没找到答案？加入我们的 Discord 社区，或者在博客中查看更详细的教程。
          </p>
          <div className="mt-4 flex gap-2">
            <Button to="/blog" variant="secondary" size="sm">
              阅读博客
            </Button>
            <Button to="/about" variant="ghost" size="sm">
              关于我们
            </Button>
          </div>
        </div>
        <div className="lg:col-span-8">
          <Accordion items={faq} />
        </div>
      </div>
    </section>
  )
}
