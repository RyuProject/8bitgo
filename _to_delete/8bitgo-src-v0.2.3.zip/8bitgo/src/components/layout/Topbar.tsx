import { useEffect, useState, type FormEvent } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { cx } from '@/lib/format'
import { Button } from '@/components/ui/Button'
import { useShell } from './ShellContext'
import { Logo } from './Logo'

/**
 * 顶栏：移动端菜单按钮 + 搜索 + 快捷操作（玩本地 ROM / G 币 / 通知 / 登录）
 */
export function Topbar() {
  const { setMobileOpen, immersive } = useShell()
  const [searchOpen, setSearchOpen] = useState(false)

  if (immersive) return null

  return (
    <header className="sticky top-0 z-30 border-b border-line bg-bg/80 backdrop-blur-xl">
      <div className="flex h-16 items-center gap-3 px-4 sm:px-6 lg:px-8">
        {/* 移动端：菜单 + Logo */}
        <button
          type="button"
          onClick={() => setMobileOpen(true)}
          aria-label="打开菜单"
          className="grid h-9 w-9 shrink-0 place-items-center rounded-lg text-fg hover:bg-white/10 lg:hidden"
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
            <path d="M4 7h16M4 12h16M4 17h16" />
          </svg>
        </button>
        <Logo className="lg:hidden" />

        {/* 搜索 */}
        <SearchBox className="hidden flex-1 md:block md:max-w-xl" />

        <div className="ml-auto flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSearchOpen((v) => !v)}
            aria-label="搜索"
            aria-expanded={searchOpen}
            className="grid h-9 w-9 place-items-center rounded-lg text-muted hover:bg-white/10 hover:text-fg md:hidden"
          >
            <SearchIcon />
          </button>

          <Button to="/play-local" variant="secondary" size="sm" className="hidden sm:inline-flex">
            <span aria-hidden>📂</span> 玩本地 ROM
          </Button>

          <Link
            to="/login"
            title="G 币余额（登录后累积）"
            className="hidden h-9 items-center gap-1.5 rounded-lg border border-coin/30 bg-coin-soft px-3 text-xs font-semibold text-coin transition hover:border-coin/60 sm:inline-flex"
          >
            <span aria-hidden>🪙</span> 0 G币
          </Link>

          <Link
            to="/login"
            aria-label="通知"
            title="通知"
            className="relative hidden h-9 w-9 place-items-center rounded-lg text-muted transition hover:bg-white/10 hover:text-fg sm:grid"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
              <path d="M6 16V11a6 6 0 1112 0v5l2 2H4l2-2z" />
              <path d="M10 20a2 2 0 004 0" />
            </svg>
            <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-live" aria-hidden />
          </Link>

          <Button to="/login" size="sm">
            登录
          </Button>
        </div>
      </div>

      {/* 移动端展开的搜索行 */}
      <div
        className={cx(
          'grid overflow-hidden transition-[grid-template-rows] duration-300 md:hidden',
          searchOpen ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]',
        )}
      >
        <div className="min-h-0">
          <div className="border-t border-line px-4 py-3">
            <SearchBox full onSubmitted={() => setSearchOpen(false)} />
          </div>
        </div>
      </div>
    </header>
  )
}

function SearchBox({ className, full, onSubmitted }: { className?: string; full?: boolean; onSubmitted?: () => void }) {
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const [value, setValue] = useState(params.get('q') ?? '')

  useEffect(() => {
    setValue(params.get('q') ?? '')
  }, [params])

  const submit = (e: FormEvent) => {
    e.preventDefault()
    const q = value.trim()
    navigate(q ? `/games?q=${encodeURIComponent(q)}` : '/games')
    onSubmitted?.()
  }

  return (
    <form onSubmit={submit} role="search" className={cx('relative', className)}>
      <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" aria-hidden>
        <SearchIcon />
      </span>
      <input
        type="search"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="搜索游戏、平台、开发商…"
        aria-label="搜索游戏"
        className={cx(
          'h-10 rounded-xl border border-line bg-surface pl-10 pr-16 text-sm text-fg placeholder:text-dim transition focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30',
          full ? 'w-full' : 'w-full',
        )}
      />
      <kbd className="pointer-events-none absolute right-3 top-1/2 hidden -translate-y-1/2 rounded border border-line px-1.5 py-0.5 text-[10px] text-dim md:block">
        Enter
      </kbd>
    </form>
  )
}

function SearchIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
      <circle cx="11" cy="11" r="7" />
      <path d="M20 20l-3.5-3.5" />
    </svg>
  )
}
