import { Button } from '@/components/ui/Button'
import { useDocumentTitle } from '@/lib/useDocumentTitle'

export function NotFoundPage({ message }: { message?: string }) {
  useDocumentTitle('页面不存在')
  return (
    <div className="container-x flex min-h-[60vh] flex-col items-center justify-center py-20 text-center">
      <p className="text-pixel text-4xl text-brand-hover sm:text-6xl">404</p>
      <p className="mt-6 text-xl font-bold">GAME OVER</p>
      <p className="mt-2 max-w-md text-sm text-muted">{message ?? '你要找的页面不存在，或者已经被移动到别处。'}</p>
      <div className="mt-8 flex gap-3">
        <Button to="/">回到首页</Button>
        <Button to="/games" variant="secondary">
          浏览游戏库
        </Button>
      </div>
    </div>
  )
}
