/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_EJS_PATH?: string
  readonly VITE_SITE_NAME?: string
  readonly VITE_ADMIN_KEY?: string
  readonly VITE_ROM_BASE_URL?: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
