import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import type { Game } from '@/types'
import { gamesStore, useAllGames } from '@/services/store'
import {
  conventionalKeys,
  getRomBase,
  getRomToken,
  listRomObjects,
  romUrlForKey,
  setRomBase,
  setRomToken,
  slugFromKey,
  subscribeRomConfig,
  type RomObject,
} from '@/services/roms'
import { platformMap } from '@/data/platforms'
import { cx, formatCount } from '@/lib/format'
import { slugify } from './GameForm'
import { Card, Field, Stat, btnClass, inputClass } from './ui'

function formatBytes(n: number) {
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`
  return `${(n / 1024 / 1024).toFixed(1)} MB`
}

/** 给一个对象 key 找最匹配的游戏 */
function matchGame(key: string, games: Game[]): Game | undefined {
  const guess = slugFromKey(key)
  const folder = key.includes('/') ? key.split('/')[0] : ''
  const candidates = games.filter((g) => g.slug === guess || slugify(g.title) === guess || slugify(g.titleZh ?? '') === guess)
  if (candidates.length === 0) return undefined
  if (candidates.length === 1) return candidates[0]
  return candidates.find((g) => g.platform === folder) ?? candidates[0]
}

export function AdminRoms() {
  const games = useAllGames()
  const [base, setBase] = useState(getRomBase())
  const [token, setToken] = useState(getRomToken())
  const [savedMsg, setSavedMsg] = useState<string | null>(null)
  const [ping, setPing] = useState<{ ok: boolean; text: string } | null>(null)
  const [objects, setObjects] = useState<RomObject[] | null>(null)
  const [loading, setLoading] = useState(false)
  const [listError, setListError] = useState<string | null>(null)
  const [filter, setFilter] = useState('')

  useEffect(() => subscribeRomConfig(() => setBase(getRomBase())), [])

  const bound = games.filter((g) => g.rom)
  const byRom = useMemo(() => new Map(bound.map((g) => [g.rom!, g])), [bound])

  const saveConfig = () => {
    setRomBase(base)
    setRomToken(token)
    setSavedMsg('已保存（根地址存于 localStorage，口令存于 sessionStorage）')
    window.setTimeout(() => setSavedMsg(null), 2500)
  }

  const testConnection = async () => {
    const b = base.trim().replace(/\/+$/, '')
    if (!b) return setPing({ ok: false, text: '请先填写根地址' })
    if (/r2\.cloudflarestorage\.com/i.test(b)) {
      return setPing({ ok: false, text: '这是 R2 的 S3 API 地址，需要签名请求，浏览器无法直接访问。请部署 worker/ 里的 Worker，或开启桶的公开访问域名。' })
    }
    setPing(null)
    try {
      const res = await fetch(`${b}/ping`, { cache: 'no-store' })
      if (res.ok) {
        const data = (await res.json().catch(() => null)) as { service?: string } | null
        if (data?.service === '8bitgo-roms') return setPing({ ok: true, text: 'Worker 在线，支持列表接口与 Range 请求。' })
      }
      // 不是 Worker：尝试探测一个已绑定或约定路径的对象
      const sample = bound[0]?.rom ?? (games[0] ? conventionalKeys(games[0])[0] : '')
      if (sample) {
        const r = await fetch(romUrlForKey(sample, b), { method: 'HEAD' })
        if (r.ok) return setPing({ ok: true, text: `可以访问（示例对象 ${sample} 返回 ${r.status}）。这不是 Worker，列表功能不可用，需手动填写 ROM key。` })
        return setPing({ ok: false, text: `根地址可达，但示例对象 ${sample} 返回 ${r.status}。请确认文件路径或 CORS 配置。` })
      }
      setPing({ ok: false, text: `根地址响应 ${res.status}，但不是本项目的 Worker。` })
    } catch (err) {
      setPing({ ok: false, text: `无法访问：${err instanceof Error ? err.message : '网络错误'}（常见原因：CORS 未配置或地址错误）` })
    }
  }

  const loadList = async () => {
    setLoading(true)
    setListError(null)
    try {
      setRomBase(base)
      setRomToken(token)
      const list = await listRomObjects()
      setObjects(list)
    } catch (err) {
      setListError(err instanceof Error ? err.message : '列表失败')
    } finally {
      setLoading(false)
    }
  }

  const bind = (slug: string, key: string | undefined) => gamesStore.update(slug, { rom: key })

  const autoMatch = () => {
    if (!objects) return
    let n = 0
    for (const o of objects) {
      if (byRom.has(o.key)) continue
      const g = matchGame(o.key, games)
      if (g && !g.rom) {
        bind(g.slug, o.key)
        n++
      }
    }
    setSavedMsg(n ? `自动匹配并绑定了 ${n} 款游戏` : '没有可自动匹配的新文件')
    window.setTimeout(() => setSavedMsg(null), 3000)
  }

  const visibleObjects = useMemo(() => {
    if (!objects) return []
    const needle = filter.trim().toLowerCase()
    return objects.filter((o) => !needle || o.key.toLowerCase().includes(needle))
  }, [objects, filter])

  const totalSize = objects?.reduce((s, o) => s + o.size, 0) ?? 0

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold">ROM 存储</h1>
        <p className="mt-1 text-sm text-muted">
          把 Cloudflare R2 里的 ROM 接到网站上。前台只需要一个可公开 GET 的根地址；游戏绑定了 key 之后，详情页会直接显示「开始游戏」。
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="已绑定 ROM 的游戏" value={bound.length} sub={`共 ${games.length} 款`} />
        <Stat label="存储根地址" value={base ? '已配置' : '未配置'} sub={base || '在下方填写'} />
        <Stat label="桶内文件" value={objects ? objects.length : '—'} sub={objects ? formatBytes(totalSize) : '点击「列出文件」'} />
        <Stat label="约定路径" value="<platform>/<slug>.zip" sub="按此命名可免绑定自动识别" />
      </div>

      <Card title="连接配置">
        <div className="grid gap-3 lg:grid-cols-[2fr_1fr]">
          <Field label="根地址（Worker 地址或 R2 公开域名，末尾不带斜杠）" hint="S3 API 地址（*.r2.cloudflarestorage.com）需要签名，不能直接用">
            <input className={inputClass} value={base} onChange={(e) => setBase(e.target.value)} placeholder="https://8bitgo-roms.your-name.workers.dev" />
          </Field>
          <Field label="Worker 列表口令（ADMIN_TOKEN）" hint="仅列文件时需要，存于 sessionStorage">
            <input type="password" className={inputClass} value={token} onChange={(e) => setToken(e.target.value)} placeholder="wrangler secret put ADMIN_TOKEN" />
          </Field>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <button type="button" className={btnClass.primary} onClick={saveConfig}>
            保存配置
          </button>
          <button type="button" className={btnClass.secondary} onClick={testConnection}>
            测试连接
          </button>
          <button type="button" className={btnClass.secondary} onClick={loadList} disabled={loading || !base.trim()}>
            {loading ? '读取中…' : '列出文件（需 Worker）'}
          </button>
          {savedMsg && <span className="text-xs text-online">{savedMsg}</span>}
        </div>
        {ping && <p className={cx('mt-3 rounded-lg px-3 py-2 text-sm', ping.ok ? 'bg-online/15 text-online' : 'bg-live/15 text-red-300')}>{ping.text}</p>}
        {listError && <p className="mt-3 rounded-lg bg-live/15 px-3 py-2 text-sm text-red-300">{listError}</p>}
      </Card>

      {objects && (
        <Card
          title={`桶内文件（${objects.length}）`}
          extra={
            <div className="flex items-center gap-2">
              <input type="search" value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="筛选 key…" className={cx(inputClass, 'h-8 w-48 text-xs')} />
              <button type="button" className={cx(btnClass.small, 'bg-brand text-white hover:bg-brand-hover')} onClick={autoMatch}>
                自动匹配未绑定的
              </button>
            </div>
          }
        >
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-sm">
              <thead className="text-left text-xs text-muted">
                <tr>
                  <th className="pb-2 font-medium">文件</th>
                  <th className="pb-2 font-medium">大小</th>
                  <th className="pb-2 font-medium">绑定到</th>
                  <th className="pb-2 text-right font-medium">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {visibleObjects.map((o) => {
                  const boundGame = byRom.get(o.key)
                  const suggestion = boundGame ? undefined : matchGame(o.key, games)
                  return (
                    <ObjectRow key={o.key} object={o} games={games} boundGame={boundGame} suggestion={suggestion} onBind={bind} />
                  )
                })}
                {visibleObjects.length === 0 && (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-muted">
                      {objects.length === 0 ? '桶是空的' : '没有匹配的文件'}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <Card title={`已绑定的游戏（${bound.length}）`} extra={<Link to="/admin/games" className="text-xs text-brand-hover hover:underline">在游戏编辑里也可填写 →</Link>}>
        {bound.length === 0 ? (
          <p className="text-sm text-muted">还没有游戏绑定 ROM。列出文件后点「自动匹配」，或在游戏编辑弹窗里填写「ROM 文件」。</p>
        ) : (
          <ul className="divide-y divide-line">
            {bound.map((g) => (
              <li key={g.slug} className="flex items-center gap-3 py-2 text-sm">
                <span aria-hidden>{g.icon}</span>
                <span className="min-w-0 flex-1">
                  <span className="font-medium">{g.titleZh ?? g.title}</span>
                  <span className="ml-2 text-xs text-muted">{platformMap[g.platform]?.shortName}</span>
                  <span className="block truncate font-mono text-xs text-dim">{g.rom}</span>
                </span>
                <a href={romUrlForKey(g.rom!)} target="_blank" rel="noreferrer" className={cx(btnClass.small, 'text-muted hover:bg-white/10 hover:text-fg')}>
                  打开
                </a>
                <button type="button" className={cx(btnClass.small, 'text-red-300 hover:bg-live/15')} onClick={() => bind(g.slug, undefined)}>
                  解绑
                </button>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card title="怎么把 R2 接进来">
        <ol className="list-decimal space-y-2 pl-5 text-sm text-muted">
          <li>
            推荐：部署本项目 <code className="text-fg">worker/</code> 目录里的 Cloudflare Worker（`cd worker && npx wrangler deploy`），它会把桶里的文件以带 CORS 与 Range 的方式提供出来，并附带列表接口。
          </li>
          <li>或者在 Cloudflare 控制台给桶开启公开访问（r2.dev 或自定义域名），并在桶的 CORS 策略里允许你的站点来源（GET、HEAD）。</li>
          <li>把得到的地址填到上面的「根地址」并保存，也可以写进 <code className="text-fg">.env</code> 的 <code className="text-fg">VITE_ROM_BASE_URL</code>。</li>
          <li>
            文件按 <code className="text-fg">&lt;platform&gt;/&lt;slug&gt;.zip</code> 命名（如 <code className="text-fg">nes/contra.zip</code>）会被前台自动识别；其他命名用「列出文件 → 自动匹配 / 手动绑定」。
          </li>
        </ol>
        <p className="mt-3 text-xs text-dim">
          游玩量最高的几款：{games
            .slice()
            .sort((a, b) => b.plays - a.plays)
            .slice(0, 3)
            .map((g) => `${g.platform}/${g.slug}.zip（${formatCount(g.plays)}）`)
            .join('、')}
        </p>
      </Card>
    </div>
  )
}

function ObjectRow({
  object,
  games,
  boundGame,
  suggestion,
  onBind,
}: {
  object: RomObject
  games: Game[]
  boundGame?: Game
  suggestion?: Game
  onBind: (slug: string, key: string | undefined) => void
}) {
  const [selected, setSelected] = useState(suggestion?.slug ?? '')
  return (
    <tr className="hover:bg-white/[0.03]">
      <td className="py-2 pr-3 font-mono text-xs">{object.key}</td>
      <td className="py-2 pr-3 tabular-nums text-muted">{formatBytes(object.size)}</td>
      <td className="py-2 pr-3">
        {boundGame ? (
          <span className="rounded bg-online/15 px-1.5 py-0.5 text-xs text-online">
            {boundGame.icon} {boundGame.titleZh ?? boundGame.title}
          </span>
        ) : (
          <select className={cx(inputClass, 'h-8 w-64 text-xs')} value={selected} onChange={(e) => setSelected(e.target.value)}>
            <option value="">{suggestion ? '— 建议：' + (suggestion.titleZh ?? suggestion.title) + ' —' : '— 选择游戏 —'}</option>
            {games.map((g) => (
              <option key={g.slug} value={g.slug}>
                {platformMap[g.platform]?.shortName} · {g.titleZh ?? g.title}
              </option>
            ))}
          </select>
        )}
      </td>
      <td className="py-2 text-right">
        {boundGame ? (
          <button type="button" className={cx(btnClass.small, 'text-red-300 hover:bg-live/15')} onClick={() => onBind(boundGame.slug, undefined)}>
            解绑
          </button>
        ) : (
          <button
            type="button"
            className={cx(btnClass.small, 'text-brand-hover hover:bg-brand-soft')}
            disabled={!selected && !suggestion}
            onClick={() => onBind(selected || suggestion!.slug, object.key)}
          >
            绑定
          </button>
        )}
      </td>
    </tr>
  )
}
