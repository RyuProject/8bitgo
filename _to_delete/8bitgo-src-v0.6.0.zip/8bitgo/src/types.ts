/** 平台（主机）标识，同时也是 EmulatorJS 核心映射的键 */
export type PlatformId =
  | 'psx'
  | 'arcade'
  | 'n64'
  | 'nes'
  | 'snes'
  | 'nds'
  | 'gba'
  | 'gb'
  | 'segaMD'
  | 'dos'
  | 'ws'
  | 'flash'
  | 'java'

export type GenreId =
  | 'action'
  | 'fighting'
  | 'shooter'
  | 'platformer'
  | 'adventure'
  | 'rpg'
  | 'strategy'
  | 'racing'
  | 'sports'
  | 'music'
  | 'puzzle'
  | 'card'

export interface Platform {
  id: PlatformId
  /** 完整名称 */
  name: string
  /** 卡片上的短名 */
  shortName: string
  /** 中文别名 */
  nameZh: string
  manufacturer: string
  year: number
  /** EmulatorJS 核心名；为 null 表示暂不支持在线运行 */
  core: string | null
  /** 接受的 ROM 文件后缀 */
  romExtensions: string[]
  /** 封面主色调 */
  color: string
  icon: string
  description: string
}

export interface Genre {
  id: GenreId
  name: string
  icon: string
  description: string
}

export interface Game {
  slug: string
  title: string
  /** 中文译名（可选） */
  titleZh?: string
  platform: PlatformId
  genres: GenreId[]
  year: number
  developer: string
  /** 0 - 5 */
  rating: number
  ratingCount: number
  plays: number
  /** 最大玩家数 */
  players: 1 | 2 | 3 | 4
  /** 是否支持联机同玩 */
  multiplayer: boolean
  /** 通关或达成成就可获得的 G 币，0 表示不参与 */
  coinReward: number
  /** 封面上展示的 emoji */
  icon: string
  /** 若有真实封面图可填写 URL，留空则使用程序生成封面 */
  cover?: string
  description: string
  tags?: string[]
  /** 上线日期，用于「最新」排序 */
  addedAt: string
  /** 体感控制友好 */
  bodyControl?: boolean
  /** 后台下架：前台不展示 */
  hidden?: boolean
  /** ROM 在对象存储中的 key（如 nes/contra.zip）或完整 URL；留空则按约定路径探测 */
  rom?: string
}

export interface LiveStream {
  id: string
  streamer: string
  title: string
  gameSlug: string
  viewers: number
  startedAt: string
}

export interface FaqItem {
  q: string
  a: string
}

export type SortKey = 'popular' | 'newest' | 'rating' | 'name'

export interface GameQuery {
  q?: string
  platform?: PlatformId
  genre?: GenreId
  developer?: string
  multiplayer?: boolean
  coin?: boolean
  sort?: SortKey
  page?: number
  pageSize?: number
}

/* ---------------- 用户 ---------------- */
export type UserRole = 'user' | 'admin'
export type UserStatus = 'active' | 'banned'

export interface User {
  id: string
  email: string
  nickname: string
  /** 头像 emoji */
  avatar: string
  /** SHA-256(salt + password) 的十六进制 */
  passwordHash: string
  salt: string
  coins: number
  role: UserRole
  status: UserStatus
  createdAt: string
  /** 收藏的游戏 slug */
  favorites: string[]
  /** 最近浏览的游戏 slug（最新在前，最多 12 个） */
  recent: string[]
}

/** 对外暴露的用户信息（不含密码相关字段） */
export type PublicUser = Omit<User, 'passwordHash' | 'salt'>

/* ---------------- 博客 ---------------- */
export interface Post {
  slug: string
  title: string
  excerpt: string
  /** 正文：支持简化 Markdown（## 标题、- 列表、> 引用、**加粗**、`代码`、[链接](url)） */
  content: string
  /** 封面 emoji */
  icon: string
  tags: string[]
  author: string
  /** YYYY-MM-DD */
  date: string
  published: boolean
}
