/**
 * ROM 存储（Cloudflare R2 等对象存储）。
 *
 * 前台只需要一个「可公开 GET 的根地址」（ROM_BASE）：
 *   - 通过本项目 worker/ 目录里的 Cloudflare Worker 暴露（推荐，自带 CORS / Range / 列表接口），或
 *   - R2 的公开访问域名（r2.dev 或自定义域名，需在桶上配置 CORS）。
 * S3 API 地址（*.r2.cloudflarestorage.com）需要签名请求，不能直接给浏览器用。
 *
 * 根地址来源优先级：后台里保存的运行时配置 > .env 里的 VITE_ROM_BASE_URL。
 * 游戏与 ROM 的对应关系：
 *   1. game.rom 明确指定（对象 key，如 nes/contra.zip，或完整 URL）
 *   2. 未指定时按约定路径探测：<platform>/<slug>.<平台支持的后缀>
 */
import { useEffect, useState } from 'react'
import type { Game } from '@/types'
import { platformMap } from '@/data/platforms'

export const ROM_BASE_KEY = '8bitgo.rom.base'
export const ROM_TOKEN_KEY = '8bitgo.rom.token'

const listeners = new Set<() => void>()

export function getRomBase(): string {
  let override = ''
  try {
    override = localStorage.getItem(ROM_BASE_KEY) ?? ''
  } catch {
    /* ignore */
  }
  const base = (override || import.meta.env.VITE_ROM_BASE_URL || '').trim()
  return base.replace(/\/+$/, '')
}

export function setRomBase(base: string) {
  try {
    if (base.trim()) localStorage.setItem(ROM_BASE_KEY, base.trim())
    else localStorage.removeItem(ROM_BASE_KEY)
  } catch {
    /* ignore */
  }
  probeCache.clear()
  for (const l of listeners) l()
}

export function getRomToken(): string {
  try {
    return sessionStorage.getItem(ROM_TOKEN_KEY) ?? ''
  } catch {
    return ''
  }
}

export function setRomToken(token: string) {
  try {
    if (token) sessionStorage.setItem(ROM_TOKEN_KEY, token)
    else sessionStorage.removeItem(ROM_TOKEN_KEY)
  } catch {
    /* ignore */
  }
}

export function subscribeRomConfig(listener: () => void) {
  listeners.add(listener)
  return () => {
    listeners.delete(listener)
  }
}

/** 把对象 key 拼成可访问的 URL（每段单独编码，保留斜杠） */
export function romUrlForKey(key: string, base = getRomBase()): string {
  if (/^https?:\/\//i.test(key)) return key
  const path = key
    .replace(/^\/+/, '')
    .split('/')
    .map((seg) => encodeURIComponent(seg))
    .join('/')
  return base ? `${base}/${path}` : ''
}

/** 游戏明确绑定了 ROM 时返回其 URL，否则返回空串 */
export function explicitRomUrl(game: Game): string {
  return game.rom ? romUrlForKey(game.rom) : ''
}

/** 约定路径候选：<platform>/<slug>.<ext>，按平台支持的后缀依次尝试 */
export function conventionalKeys(game: Game): string[] {
  const exts = platformMap[game.platform]?.romExtensions ?? ['.zip']
  const ordered = ['.zip', ...exts.filter((e) => e !== '.zip')]
  return ordered.map((ext) => `${game.platform}/${game.slug}${ext}`)
}

const probeCache = new Map<string, Promise<boolean>>()

/** HEAD 探测某个 URL 是否存在（带超时，结果缓存） */
export function probeUrl(url: string, timeoutMs = 4000): Promise<boolean> {
  const cached = probeCache.get(url)
  if (cached) return cached
  const p = (async () => {
    const ctrl = new AbortController()
    const timer = window.setTimeout(() => ctrl.abort(), timeoutMs)
    try {
      const res = await fetch(url, { method: 'HEAD', signal: ctrl.signal })
      return res.ok
    } catch {
      return false
    } finally {
      window.clearTimeout(timer)
    }
  })()
  probeCache.set(url, p)
  return p
}

export interface RomResolution {
  status: 'idle' | 'checking' | 'found' | 'missing'
  url: string
  /** 命中的 key（约定路径探测时有值） */
  key?: string
}

/**
 * 解析某款游戏可直接播放的 ROM 地址。
 * 明确绑定 → 立即可用；否则在配置了存储根地址时按约定路径探测。
 */
export function useRomUrl(game: Game | undefined): RomResolution {
  const [state, setState] = useState<RomResolution>({ status: 'idle', url: '' })

  useEffect(() => {
    if (!game) return
    const explicit = explicitRomUrl(game)
    if (explicit) {
      setState({ status: 'found', url: explicit, key: game.rom })
      return
    }
    const base = getRomBase()
    if (!base || !platformMap[game.platform]?.core) {
      setState({ status: 'missing', url: '' })
      return
    }

    let cancelled = false
    setState({ status: 'checking', url: '' })
    ;(async () => {
      for (const key of conventionalKeys(game)) {
        const url = romUrlForKey(key, base)
        if (await probeUrl(url)) {
          if (!cancelled) setState({ status: 'found', url, key })
          return
        }
      }
      if (!cancelled) setState({ status: 'missing', url: '' })
    })()

    return () => {
      cancelled = true
    }
  }, [game])

  return state
}

/* ---------------- Worker 列表接口（后台用） ---------------- */

export interface RomObject {
  key: string
  size: number
  uploaded?: string
}

/**
 * 通过 Worker 的 /list 接口列出桶内文件（需要部署 worker/ 并配置 ADMIN_TOKEN）。
 */
export async function listRomObjects(prefix = ''): Promise<RomObject[]> {
  const base = getRomBase()
  if (!base) throw new Error('尚未配置 ROM 存储根地址')
  const token = getRomToken()
  const out: RomObject[] = []
  let cursor = ''
  for (let i = 0; i < 50; i++) {
    const url = new URL(`${base}/list`)
    if (prefix) url.searchParams.set('prefix', prefix)
    if (cursor) url.searchParams.set('cursor', cursor)
    const res = await fetch(url.toString(), { headers: token ? { Authorization: `Bearer ${token}` } : {} })
    if (res.status === 401 || res.status === 403) throw new Error('列表接口拒绝访问：请检查 Worker 的 ADMIN_TOKEN 是否与这里填写的一致')
    if (res.status === 404) throw new Error('根地址下没有 /list 接口：列表功能需要部署本项目 worker/ 目录里的 Cloudflare Worker')
    if (!res.ok) throw new Error(`列表接口返回 ${res.status}`)
    const data = (await res.json()) as { objects?: RomObject[]; cursor?: string; truncated?: boolean }
    out.push(...(data.objects ?? []))
    if (!data.truncated || !data.cursor) break
    cursor = data.cursor
  }
  return out
}

/** 根据文件名猜测对应的游戏 slug：nes/super-mario-bros.zip -> super-mario-bros */
export function slugFromKey(key: string): string {
  const file = key.split('/').pop() ?? key
  return file
    .replace(/\.(zip|7z|nes|unf|fds|sfc|smc|fig|gba|gbc|gb|z64|n64|v64|md|gen|bin|smd|nds|ws|wsc|cue|iso|img|pbp|chd|exe|com)$/i, '')
    .toLowerCase()
    .replace(/[\s_]+/g, '-')
}
