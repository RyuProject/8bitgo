import { Button } from '@/components/ui/Button'
import { GameCover } from '@/components/game/GameCover'
import { getGamesBySlugs } from '@/services/games'
import { cx } from '@/lib/format'

/** 横幅里漂浮展示的封面 */
const HERO_GAMES = ['the-king-of-fighters-97', 'super-mario-world', 'pokemon-emerald']

/** 首页 banner 位：标题 + 类型快捷入口之下的主横幅 */
export function HomeBanner() {
  return (
    <section className="container-x" aria-label="首页横幅">
      <Banner />
    </section>
  )
}

function Banner({ className }: { className?: string }) {
  const heroGames = getGamesBySlugs(HERO_GAMES)

  return (
    <div
      className={cx(
        'relative overflow-hidden border-2 border-line-strong bg-gradient-to-br from-brand/35 via-surface to-[#0d1526]',
        className,
      )}
    >
      <div className="pixel-grid absolute inset-0 opacity-40 [mask-image:linear-gradient(to_right,black,transparent)]" aria-hidden />

      <div className="relative flex min-h-[220px] items-center justify-between gap-6 p-6 sm:p-8">
        <div className="max-w-lg">
          <span className="text-pixel inline-flex items-center gap-2 border-2 border-brand/60 bg-brand-soft px-3 py-1 text-[11px] font-semibold text-brand-hover">
            <span aria-hidden>🕹️</span> 无需下载 · 打开浏览器直接玩
          </span>
          <h2 className="mt-3 text-2xl font-extrabold leading-tight tracking-tight sm:text-3xl lg:text-4xl">
            插上卡带
            <br />
            <span className="whitespace-nowrap bg-gradient-to-r from-coin via-[#ff9a3c] to-live bg-clip-text text-transparent">
              立刻开玩
            </span>
          </h2>
          <p className="mt-2 max-w-md text-sm leading-relaxed text-muted">
            选好游戏点开就能玩，随时即时存档、接手柄。也可以把自己收藏的 ROM 拖进来，
            全程在浏览器本地运行，不会上传。
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            <Button to="/games">
              <span aria-hidden>▶</span> 开始游玩
            </Button>
            <Button to="/play-local" variant="secondary">
              <span aria-hidden>📂</span> 上传本地 ROM
            </Button>
          </div>
        </div>

        {/* 漂浮的封面 */}
        <div className="relative hidden h-44 w-56 shrink-0 md:block" aria-hidden>
          {heroGames.map((g, i) => (
            <div
              key={g.slug}
              className="animate-float absolute w-24 overflow-hidden border-2 border-black/70 shadow-[4px_4px_0_0_rgba(0,0,0,0.6)]"
              style={{
                left: `${[0, 50, 25][i]}%`,
                top: `${[10, 0, 30][i]}%`,
                transform: `rotate(${[-8, 6, -3][i]}deg)`,
                animationDelay: `${i * 1.3}s`,
                zIndex: [1, 2, 3][i],
              }}
            >
              <GameCover game={g} iconSize="sm" showTitle={false} />
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
