import type { ReactNode } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { cx } from '@/lib/format'
import { getRandomGame } from '@/services/games'
import { useCurrentUser } from '@/services/auth'
import { useShell } from './ShellContext'
import { Logo } from './Logo'
import { communityLinks, libraryNav, mainNav, type NavLinkItem } from './nav'
import { SocialIcon } from './SocialIcon'

export const SIDEBAR_WIDTH = 240
export const SIDEBAR_COLLAPSED_WIDTH = 72

/**
 * 左侧导航栏。
 *  - lg 及以上：固定在左侧，可折叠成图标栏
 *  - lg 以下：作为抽屉从左侧滑出，带遮罩
 */
export function Sidebar() {
  const { collapsed, toggleCollapsed, mobileOpen, setMobileOpen, immersive } = useShell()
  const user = useCurrentUser()

  return (
    <>
      {/* 移动端遮罩 */}
      <div
        aria-hidden
        onClick={() => setMobileOpen(false)}
        className={cx(
          'fixed inset-0 z-40 bg-black/60 backdrop-blur-sm transition-opacity lg:hidden',
          mobileOpen ? 'opacity-100' : 'pointer-events-none opacity-0',
        )}
      />

      <aside
        aria-label="侧边导航"
        className={cx(
          'fixed inset-y-0 left-0 z-50 flex w-60 flex-col border-r border-line bg-surface transition-[transform,width] duration-300 ease-out',
          // 移动端：抽屉（始终 240px）；桌面端：常驻，可折叠为 72px 图标栏；沉浸模式下整体移出
          mobileOpen ? 'translate-x-0' : cx('-translate-x-full', !immersive && 'lg:translate-x-0'),
          collapsed && 'lg:w-[72px]',
        )}
        data-collapsed={collapsed ? 'true' : 'false'}
      >

        {/* 顶部：Logo + 折叠按钮 */}
        <div className={cx('flex h-16 shrink-0 items-center border-b border-line px-3', collapsed ? 'lg:justify-center' : 'justify-between')}>
          <Logo className={cx(collapsed && 'lg:[&>span:last-child]:hidden')} />
          <button
            type="button"
            onClick={() => setMobileOpen(false)}
            aria-label="关闭菜单"
            className="grid h-8 w-8 place-items-center rounded-lg text-muted hover:bg-white/10 hover:text-fg lg:hidden"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
          {!collapsed && (
            <button
              type="button"
              onClick={toggleCollapsed}
              aria-label="折叠侧边栏"
              title="折叠侧边栏"
              className="hidden h-8 w-8 place-items-center rounded-lg text-muted hover:bg-white/10 hover:text-fg lg:grid"
            >
              <ChevronIcon dir="left" />
            </button>
          )}
        </div>

        {/* 可滚动导航区 */}
        <nav className="scrollbar-none flex-1 overflow-y-auto px-2 py-3">
          <RandomGameButton collapsed={collapsed} />
          <CommunityBox collapsed={collapsed} />

          <NavGroup title="导航" collapsed={collapsed}>
            {mainNav.map((item) => (
              <NavItem key={item.to} item={item} collapsed={collapsed} />
            ))}
          </NavGroup>

          <NavGroup title="游戏库" collapsed={collapsed}>
            {libraryNav.map((item) => (
              <NavItem key={item.to} item={item} collapsed={collapsed} />
            ))}
          </NavGroup>
        </nav>

        {/* 底部：用户 */}
        <div className="shrink-0 border-t border-line p-2">
          <Link
            to={user ? '/me' : '/login'}
            onClick={() => setMobileOpen(false)}
            className={cx(
              'flex items-center gap-3 rounded-xl px-2 py-2 transition hover:bg-white/5',
              collapsed && 'lg:justify-center lg:px-0',
            )}
            title={user ? '个人中心' : '登录 / 注册'}
          >
            <span
              className={cx(
                'grid h-8 w-8 shrink-0 place-items-center rounded-full text-sm',
                user ? 'bg-brand-soft' : 'bg-gradient-to-br from-surface-3 to-surface-2',
              )}
              aria-hidden
            >
              {user ? user.avatar : '👤'}
            </span>
            <span className={cx('min-w-0', collapsed && 'lg:hidden')}>
              <span className="block truncate text-sm font-semibold">{user ? user.nickname : '登录 / 注册'}</span>
              <span className="block truncate text-[11px] text-muted">
                {user ? `🪙 ${user.coins.toLocaleString('zh-CN')} G 币` : '🪙 登录后累积 G 币'}
              </span>
            </span>
          </Link>

          {collapsed ? (
            <button
              type="button"
              onClick={toggleCollapsed}
              aria-label="展开侧边栏"
              title="展开侧边栏"
              className="mt-1 hidden h-9 w-full place-items-center rounded-lg text-muted hover:bg-white/10 hover:text-fg lg:grid"
            >
              <ChevronIcon dir="right" />
            </button>
          ) : (
            <p className="text-pixel mt-2 px-2 text-[10px] text-dim">v0.8.1 · DASHBOARD</p>
          )}
        </div>
      </aside>
    </>
  )
}

/** 随机跳转到一款可在线运行的游戏 */
function RandomGameButton({ collapsed }: { collapsed: boolean }) {
  const navigate = useNavigate()
  const location = useLocation()
  const { setMobileOpen } = useShell()

  const play = () => {
    const current = location.pathname.startsWith('/games/') ? location.pathname.split('/')[2] : undefined
    const game = getRandomGame(current)
    setMobileOpen(false)
    navigate(`/games/${game.slug}`)
  }

  return (
    <button
      type="button"
      onClick={play}
      title="随机玩一个游戏"
      className={cx(
        'group relative mb-3 flex h-10 w-full items-center gap-3 rounded-xl bg-brand px-3 text-sm font-semibold text-white shadow-[0_8px_24px_-8px_rgba(139,92,246,0.7)] transition hover:bg-brand-hover active:translate-y-px',
        collapsed && 'lg:justify-center lg:px-0',
      )}
    >
      <span className="text-base transition group-hover:rotate-12" aria-hidden>
        🎲
      </span>
      <span className={cx(collapsed && 'lg:hidden')}>随机玩一个游戏</span>
      {collapsed && (
        <span
          role="tooltip"
          className="pointer-events-none absolute left-full top-1/2 z-50 ml-2 hidden -translate-y-1/2 whitespace-nowrap rounded-md border border-line bg-surface-3 px-2 py-1 text-xs font-normal text-fg opacity-0 shadow-xl transition group-hover:opacity-100 lg:block"
        >
          随机玩一个游戏
        </span>
      )}
    </button>
  )
}

/**
 * 玩家社区卡片：标题嵌在边框上，一行社交图标。
 * 桌面折叠态没有横向空间，改为竖排图标并带悬浮提示。
 */
function CommunityBox({ collapsed }: { collapsed: boolean }) {
  return (
    <>
      {/* 展开态 / 移动端抽屉 */}
      <fieldset className={cx('mb-4 rounded-xl border border-line-strong px-3 pb-3 pt-2', collapsed && 'lg:hidden')}>
        <legend className="px-1.5 text-xs font-semibold text-fg">玩家社区</legend>
        <div className="flex items-center justify-between">
          {communityLinks.map((c) => (
            <a
              key={c.id}
              href={c.href}
              target="_blank"
              rel="noreferrer"
              aria-label={c.label}
              title={c.label}
              className="grid h-9 w-9 place-items-center rounded-lg text-muted transition hover:bg-white/10 hover:text-fg"
            >
              <SocialIcon id={c.id} />
            </a>
          ))}
        </div>
      </fieldset>

      {/* 桌面折叠态：竖排图标 */}
      <ul className={cx('mb-3 hidden space-y-0.5 border-b border-line pb-3', collapsed && 'lg:block')} aria-label="玩家社区">
        {communityLinks.map((c) => (
          <li key={c.id}>
            <a
              href={c.href}
              target="_blank"
              rel="noreferrer"
              aria-label={c.label}
              title={c.label}
              className="group relative flex h-9 items-center justify-center rounded-lg text-muted transition hover:bg-white/5 hover:text-fg"
            >
              <SocialIcon id={c.id} size={20} />
              <span
                role="tooltip"
                className="pointer-events-none absolute left-full top-1/2 z-50 ml-2 -translate-y-1/2 whitespace-nowrap rounded-md border border-line bg-surface-3 px-2 py-1 text-xs text-fg opacity-0 shadow-xl transition group-hover:opacity-100"
              >
                {c.label}
              </span>
            </a>
          </li>
        ))}
      </ul>
    </>
  )
}

function NavGroup({ title, collapsed, children }: { title: string; collapsed: boolean; children: ReactNode }) {
  return (
    <div className="mb-3">
      <p
        className={cx(
          'text-pixel mb-1.5 px-3 text-[10px] uppercase tracking-wider text-dim',
          collapsed && 'lg:sr-only',
        )}
      >
        {title}
      </p>
      <div className={cx('mb-2 hidden h-px bg-line', collapsed && 'lg:block')} aria-hidden />
      <ul className="space-y-0.5">{children}</ul>
    </div>
  )
}

function NavItem({
  item,
  collapsed,
  trailing,
  muted,
}: {
  item: NavLinkItem
  collapsed: boolean
  trailing?: ReactNode
  muted?: boolean
}) {
  const location = useLocation()
  const { setMobileOpen } = useShell()

  const [path, search] = item.to.split('?')
  const isHash = item.to.includes('#')
  const active = item.external || item.disabled
    ? false
    : item.exact
      ? location.pathname === path && (search ? location.search === `?${search}` : location.search === '') && !isHash
      : !isHash && location.pathname.startsWith(path) && path !== '/'

  const className = cx(
    'group relative flex h-9 items-center gap-3 rounded-lg px-3 text-sm transition',
    collapsed && 'lg:justify-center lg:px-0',
    item.disabled
      ? 'cursor-not-allowed text-dim opacity-60'
      : active
        ? 'bg-brand-soft font-semibold text-fg'
        : muted
          ? 'text-dim hover:bg-white/5 hover:text-muted'
          : 'text-muted hover:bg-white/5 hover:text-fg',
  )

  const content = (
    <>
      {active && <span className="absolute inset-y-1.5 left-0 w-0.5 rounded-full bg-brand" aria-hidden />}
      <span className="relative grid h-6 w-6 shrink-0 place-items-center text-base leading-none" aria-hidden>
        {item.icon}
      </span>
      <span className={cx('min-w-0 flex-1 truncate', collapsed && 'lg:hidden')}>{item.label}</span>
      {item.badge && (
        <span
          className={cx(
            'whitespace-nowrap rounded px-1 py-0.5 text-[9px] font-bold uppercase leading-none',
            item.disabled ? 'border border-line-strong text-dim' : 'bg-live text-white',
            collapsed && 'lg:hidden',
          )}
        >
          {item.badge}
        </span>
      )}
      {trailing && <span className={cx(collapsed && 'lg:hidden')}>{trailing}</span>}

      {/* 折叠态悬浮提示 */}
      {collapsed && (
        <span
          role="tooltip"
          className="pointer-events-none absolute left-full top-1/2 z-50 ml-2 hidden -translate-y-1/2 whitespace-nowrap rounded-md border border-line bg-surface-3 px-2 py-1 text-xs text-fg opacity-0 shadow-xl transition group-hover:opacity-100 lg:block"
        >
          {item.label}
          {item.disabled && <span className="ml-1 text-dim">· 即将上线</span>}
        </span>
      )}
    </>
  )

  return (
    <li>
      {item.disabled ? (
        <span className={className} aria-disabled="true" title={collapsed ? `${item.label}（即将上线）` : '即将上线'}>
          {content}
        </span>
      ) : item.external ? (
        <a href={item.to} target="_blank" rel="noreferrer" className={className} title={collapsed ? item.label : undefined}>
          {content}
        </a>
      ) : (
        <Link to={item.to} className={className} onClick={() => setMobileOpen(false)} title={collapsed ? item.label : undefined}>
          {content}
        </Link>
      )}
    </li>
  )
}

function ChevronIcon({ dir }: { dir: 'left' | 'right' }) {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden>
      {dir === 'left' ? <path d="M15 5l-7 7 7 7" /> : <path d="M9 5l7 7-7 7" />}
    </svg>
  )
}
